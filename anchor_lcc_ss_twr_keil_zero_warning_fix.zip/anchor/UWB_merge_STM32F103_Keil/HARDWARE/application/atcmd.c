#include "atcmd.h"
#include "stdio.h"
#include "string.h"
#include "rtc.h"
#include "delay.h"
#include "device_info.h"
#include "hw_config.h"
#include "usart.h"
#include "instance.h"
#include "iwdg.h"
#include "adc.h"
#include "led.h"


u8 SendBuff[200];
u8 n = 0; //SendBuff index
u8 USB_RxBuff[30];
void Load_Set_from_U(u8* RXbuff);
uint8_t lis3dh_id = 0x33;

void Display_Searching(void)
{
	int n =0;
	n+=	sprintf((char*)&SendBuff[n], ">> Searching Anchors & Tags...\r\n");
	printf("%s",SendBuff);
	USB_TxWrite(SendBuff, n);	
}

void Display_ATCMDInfo(void)
{
	int n =0;
	n = sprintf((char*)&SendBuff[0],   " ---------------------------------------\r\n");	
	n+= sprintf((char*)&SendBuff[n],   "|   Please configure the module...      |\r\n");	
	n+=	sprintf((char*)&SendBuff[n],   "|   AT+QSET                             |\r\n");
	n+=	sprintf((char*)&SendBuff[n],   " ---------------------------------------\r\n");
	printf("%s",SendBuff);
	USB_TxWrite(SendBuff, n);	

}


void Display_UWBInfo(void)
{	
	int n =0;
	n+= sprintf((char*)&SendBuff[n],   "\r\n\r\n\r\n\r\n>> COPYRIGHT 2019 YCHIOT LTD\r\n\r\n");
	n+=	sprintf((char*)&SendBuff[n],   ">> SW Version:   1.9.4.4-MESH\r\n");
	n+=	sprintf((char*)&SendBuff[n],   ">> Build Time:   2019/05/04\r\n>> Merge Stack:  TDMA Mesh/UWB Network\r\n");
	n+=	sprintf((char*)&SendBuff[n],   ">> MCU UniqueID: %08x-%08x-%08x\r\n",*(vu32*)(0x1ffff7e8),*(vu32*)(0x1ffff7ec),*(vu32*)(0x1ffff7f0) );
	n+=	sprintf((char*)&SendBuff[n],   ">> Start Number: %d\r\n",sys_para.start_count );
	n+=	sprintf((char*)&SendBuff[n],   ">> Baudrate:     460800bps\r\n");

	printf("%s",SendBuff);
	USB_TxWrite(SendBuff, n);	

	n =0;
	if( sys_para.mode == 0x01)
		n+=	sprintf((char*)&SendBuff[n], ">> Role Config:  Tag %d (AutoDiscovery)\r\n", sys_para.uwbid);
	else if( sys_para.mode == 0x00)
		n+=	sprintf((char*)&SendBuff[n], ">> Role Config:  Anchor %d (AutoDiscovery)\r\n", sys_para.uwbid);	
	
	if( sys_para.datarate == 0x02  )
		n+=	sprintf((char*)&SendBuff[n], ">> UWB DataRate: 6.81Mpbs\r\n");
	else if( sys_para.datarate == 0x00  )
		n+=	sprintf((char*)&SendBuff[n], ">> UWB DataRate: 110Kpbs\r\n");
	
	if( sys_para.channel == 0x05  )
		n+=	sprintf((char*)&SendBuff[n], ">> UWB Channel:  5\r\n");
	else if( sys_para.channel == 0x02  )
		n+=	sprintf((char*)&SendBuff[n], ">> UWB Channel:  2\r\n");

	if( sys_para.lowpower == 0x02  )
		n+=	sprintf((char*)&SendBuff[n], ">> UWB Lowpower: Enable\r\n");
	else if( sys_para.lowpower == 0x00 )
		n+=	sprintf((char*)&SendBuff[n], ">> UWB Lowpower: Disable\r\n");
	
	if(lis3dh_id == 0x33)
		n+=	sprintf((char*)&SendBuff[n], ">> G-Sensor:     Enable\r\n\r\n");
	else if(lis3dh_id != 0x33)
		n+=	sprintf((char*)&SendBuff[n], ">> G-Sensor:     Disable\r\n\r\n");
	
	printf("%s",SendBuff);
	USB_TxWrite(SendBuff, n);	
	
}

u8 Check_cmd(u8* RXbuff)
{
//	u8 i=0;
  if(strstr((char *)RXbuff,"AT+VER?") != NULL)
			return VERS;		
	if(strstr((char *)RXbuff,"AT+INF?") != NULL)
			return INFO;	
	if(strstr((char *)RXbuff,"AT+BAT?") != NULL)
			return BATT;	
	
	if(strstr((char *)RXbuff,"AT+SLEP") != NULL)
			return SLEP;		
	if(strstr((char *)RXbuff,"AT+TEST") != NULL)
			return TEST;	
	
	if(strstr((char *)RXbuff,"AT+STAR") != NULL)
			return STAR;	
	if(strstr((char *)RXbuff,"AT+RSET") != NULL)
			return RSET;	

	if(strstr((char *)RXbuff,"deca$") != NULL)
			return DECA;

	if(strstr((char *)RXbuff,"AT+LPOW") != NULL)
	{
			return LPOW;
	}		
	
	if(strstr((char *)RXbuff,"AT+QSET=") != NULL)
	{
//		int i;
//		printf("%x %x %x",RXbuff[12],RXbuff[13],RXbuff[14]);
		if(RXbuff[8] == 'F' || RXbuff[8] == 'S' )
			if(RXbuff[9] == '2' || RXbuff[9] == '5')
				if(RXbuff[10] == '-')	
					if(RXbuff[11] == 'A' || RXbuff[11] == 'T')
					{
						if(RXbuff[12] <='9' && RXbuff[12] >='0' &&  RXbuff[13] <='9' && RXbuff[13] >='0' )
						{
								if(RXbuff[11] == 'A' && RXbuff[13] >= '4')
									return EROR;
								return QSET;
						}						
						
//						if(RXbuff[12] <='9' && RXbuff[12] >='0')
//						{
//								if(RXbuff[11] == 'A' && RXbuff[12] >= '4')
//									return EROR;
//								return QSET;
//						}
					}				
	}
	return EROR;
}

void Process_USART_ATCMD(void)
{
	u8 usart_cmd_value=0;	
	u8 i=0;

//  u_len = USART_RX_STA&0x3f;
	if(USART_RX_STA&0x8000)	   //жǷ
	{	
		USART_RX_STA = 0;
		usart_cmd_value = Check_cmd(USART_RX_BUF);				
	
		if(usart_cmd_value ==INFO)//AT+INF?	
		{
			Display_UWBInfo();//Show UWB parameters
			memset(USART_RX_BUF,0,30);// Clear the buffer		
//			USART_RX_STA = 0;					
		}				
		if(usart_cmd_value ==BATT)//AT+BAT?	
		{
			unsigned int batt_mv = Get_Battery_mV();
			unsigned int batt_pct = Get_Battery_Percent_Int(batt_mv);
			n =	sprintf((char*)&SendBuff[0], "\r\n>> Battery: %u.%03uV (%u%%)\r\n", batt_mv / 1000U, batt_mv % 1000U, batt_pct);
			printf("%s\r\n",SendBuff);
						
//			if(BQ_CHG == 0)
//				printf(">> NOT FULL POWER\r\n\r\n");
//			if(BQ_CHG == 1)
//				printf(">> FULL POWER\r\n\r\n");
			
			memset(USART_RX_BUF,0,30);// Clear the buffer		
		}				
		if(usart_cmd_value ==DECA)
		{
			for(i=0;i<10;i++)
				printf("%s",buff_version);
			memset(USART_RX_BUF,0,30);// Clear the buffer
			//USART_RX_STA = 0;				
		}
		
		if(usart_cmd_value ==SLEP)//AT+SLEP  
		{
			n =	sprintf((char*)&SendBuff[0],"OK+SLEP\r\n");
			printf("%s\r\n",SendBuff);
			memset(USART_RX_BUF,0,30);// Clear the buffer	
			RTC_Enter_StandbyMode(5);//Set as sleep mode
		}			
		if(usart_cmd_value ==TEST) //AT+TEST
		{
			n =	sprintf((char*)&SendBuff[0],"OK+TEST\r\n");
			printf("%s\r\n",SendBuff);
			memset(USART_RX_BUF,0,30);// Clear the buffer	
			configure_continuous_txspectrum_mode();//continuous spectrum test mode
		}		
		if(usart_cmd_value ==STAR)//AT+STAR
		{
			n =	sprintf((char*)&SendBuff[0],"OK+STAR\r\n");
			printf("%s\r\n",SendBuff);
			memset(USART_RX_BUF,0,30);// Clear the buffer	
			NVIC_SystemReset();//restart stm32		 	
		}	
		if(usart_cmd_value ==RSET)//AT+STAR
		{
			n =	sprintf((char*)&SendBuff[0],"OK+RSET\r\n");
			printf("%s\r\n",SendBuff);
			memset(USART_RX_BUF,0,30);// Clear the buffer	
			FLAH_BUFF0[0] = 0x0000;	
			My_STMFLASH_Write();//дFlash
			NVIC_SystemReset(); //λ			
		}	
		if(usart_cmd_value ==LPOW)//AT+TIME
		{
			n =	sprintf((char*)&SendBuff[0],"OK+LPOW\r\n");
			printf("%s\r\n",SendBuff);

			if(USART_RX_BUF[8]=='2')
			{
				FLAH_BUFF0[13] = 0x0002;
				n =	sprintf((char*)&SendBuff[0],"OK+LPOW=2\r\n");
				printf("%s\r\n",SendBuff);
			}				
			if(USART_RX_BUF[8]=='0')
			{
				FLAH_BUFF0[13] = 0x0000;	
				n =	sprintf((char*)&SendBuff[0],"OK+LPOW=0\r\n");
				printf("%s\r\n",SendBuff);
			}
			
			memset(USART_RX_BUF,0,30);// Clear the buffer	

			My_STMFLASH_Write();//дFlash
			NVIC_SystemReset(); //λ			
		}	
		
		if(usart_cmd_value==QSET)
		{
			n =	sprintf((char*)&SendBuff[0],"OK+QSET\r\n");
			printf("%s\r\n",SendBuff);
			Load_Set_from_U(USART_RX_BUF);			
			Sleep(200);
			memset(USART_RX_BUF,0,30);// Clear the buffer	

			My_STMFLASH_Write();//дFlash
			Display_UWBInfo();		
			Sleep(200);	
			NVIC_SystemReset(); //λ
		}		
	}
}

void Process_USB_ATCMD(void)
{
	u8 len=0;	
	int i=0;
	u8 usb_cmd_value=0;
	
	len = USB_RxRead(USB_RxBuff, sizeof(USB_RxBuff));	
	
	if( len >0 )
	{
		usb_cmd_value = Check_cmd(USB_RxBuff);		
		
		if(usb_cmd_value ==INFO)//AT+INF?	
		{
			Display_UWBInfo();//Show UWB parameters
			memset(USB_RxBuff,0,30);// Clear the buffer				
		}				
		if(usb_cmd_value ==BATT)//AT+BAT?	
		{
		  unsigned int batt_mv = Get_Battery_mV();
		  unsigned int batt_pct = Get_Battery_Percent_Int(batt_mv);
			n =	sprintf((char*)&SendBuff[0], "\r\n>> Battery: %u.%03uV (%u%%)\r\n", batt_mv / 1000U, batt_mv % 1000U, batt_pct);
	
//			if(BQ_CHG == 0)
//				n +=	sprintf((char*)&SendBuff[n], ">> NOT FULL POWER\r\n");
//			if(BQ_CHG == 1)
//				n +=	sprintf((char*)&SendBuff[n], ">> FULL POWER\r\n\r\n");

			USB_TxWrite(SendBuff, n);
			
			//Show Battery percentage
			memset(USB_RxBuff,0,50);// Clear the buffer				
		}				
		if(usb_cmd_value ==DECA)
		{
			for(i=0;i<10;i++)
				USB_TxWrite(buff_version, 17);	
			memset(USB_RxBuff,0,30);// Clear the buffer			
		}
		
		if(usb_cmd_value ==SLEP)//AT+SLEP  
		{
			n =	sprintf((char*)&SendBuff[0],"OK+SLEP\r\n");
			USB_TxWrite(SendBuff, n);

			memset(USB_RxBuff,0,30);// Clear the buffer	
			RTC_Enter_StandbyMode(5);//Set as sleep mode
		}			
		if(usb_cmd_value ==TEST) //AT+TEST
		{
			n =	sprintf((char*)&SendBuff[0],"OK+TEST\r\n");
			USB_TxWrite(SendBuff, n);

			memset(USB_RxBuff,0,30);// Clear the buffer	
			configure_continuous_txspectrum_mode();//continuous spectrum test mode
		}		
		if(usb_cmd_value ==STAR)//AT+STAR
		{
			n =	sprintf((char*)&SendBuff[0],"OK+STAR\r\n");
			USB_TxWrite(SendBuff, n);

			memset(USB_RxBuff,0,30);// Clear the buffer	
			NVIC_SystemReset();//restart stm32		 	
		}	
		if(usb_cmd_value ==RSET)//AT+RSET
		{
			n =	sprintf((char*)&SendBuff[0],"OK+RSET\r\n");
			USB_TxWrite(SendBuff, n);

			memset(USB_RxBuff,0,30);// Clear the buffer	
			FLAH_BUFF0[0] = 0x0000;	
			My_STMFLASH_Write();//дFlash
			NVIC_SystemReset(); //λ			
		}	
		if(usb_cmd_value ==LPOW)//AT+TIME
		{
			n =	sprintf((char*)&SendBuff[0],"OK+LPOW\r\n");
			USB_TxWrite(SendBuff, n);

			if(USB_RxBuff[8]=='2')
			{
				FLAH_BUFF0[13] = 0x0002;	
				n =	sprintf((char*)&SendBuff[0],"OK+LPOW=2\r\n");
				USB_TxWrite(SendBuff, n);				
			}
			if(USB_RxBuff[8]=='0')
			{
				FLAH_BUFF0[13] = 0x0000;
				n =	sprintf((char*)&SendBuff[0],"OK+LPOW=0\r\n");
				USB_TxWrite(SendBuff, n);
			}				
			
			memset(USB_RxBuff,0,30);// Clear the buffer	

			My_STMFLASH_Write();//дFlash
			NVIC_SystemReset(); //λ			
		}		
	
		if(Check_cmd(USB_RxBuff)==QSET)
		{
			n =	sprintf((char*)&SendBuff[0],"OK+QSET\r\n");
			USB_TxWrite(SendBuff, n);	
			Load_Set_from_U(USB_RxBuff);			
			Sleep(200);
			memset(USB_RxBuff,0,30);// Clear the buffer	

			My_STMFLASH_Write();//дFlash
			
			Display_UWBInfo();	
			Sleep(200);			
			NVIC_SystemReset(); //λ
		}		
	}
}


void Load_Set_from_U(u8* RXbuff)
{
	if(RXbuff[8] == 'F')
		sys_para.datarate = 0x02;
	else if(RXbuff[8] == 'S')
		sys_para.datarate = 0x00;

	if(RXbuff[9] == '5')
		sys_para.channel =0x05;
	else if(RXbuff[9] == '2')
		sys_para.channel =0x02;

	if(RXbuff[11] == 'A')
		sys_para.mode = 0x00;
	else if(RXbuff[11] == 'T')
		sys_para.mode = 0x01;
	
	sys_para.uwbid = ((RXbuff[12]-'0')*10 + (RXbuff[13]-'0'));// Load Address
	
	FLAH_BUFF0[0] = 0xAAAA;	
	FLAH_BUFF0[2] = sys_para.mode;
	FLAH_BUFF0[3] = sys_para.channel;
	FLAH_BUFF0[4] = sys_para.datarate;		
	FLAH_BUFF0[9] = sys_para.uwbid;
}

void Process_ATCMD(void)
{
	Process_USB_ATCMD();
	Process_USART_ATCMD();
}
