/*! ----------------------------------------------------------------------------
 *  @file    instance.c
 *  @brief   DecaWave application level message exchange for ranging demo
 *
 * @attention
 *
 * Copyright 2013 (c) DecaWave Ltd, Dublin, Ireland.
 *
 * All rights reserved.
 *
 * @author DecaWave
 */
#include "compiler.h"
#include "port.h"
#include "deca_device_api.h"
#include "deca_spi.h"
#include "deca_regs.h"


#include "lib.h"
#include "instance.h"

#if defined(__CC_ARM)
#pragma diag_suppress 177
#endif

extern void usb_run(void);
extern uint32 USB_TxWrite(uint8 *buffter, uint32 writeLen);
extern int usb_init(void);
extern void usb_printconfig(int, uint8*, int);
extern void send_usbmessage(uint8*, int);
 
 volatile uint64 dbg_cnt_anch_report = 0;
  volatile uint64 dbg_cnt_anch_report1 = 0;
	 volatile uint64 dbg_cnt_anch_report2 = 0;
  volatile uint64 dbg_cnt_anch_report3 = 0;
	 volatile uint64 dbg_cnt_anch_report4 = 0;
  volatile uint64 dbg_cnt_anch_report5 = 0;
	 volatile uint64 dbg_cnt_anch_report6 = 0;
  volatile double dbg_cnt_anch_report7 = 0;
	
// -------------------------------------------------------------------------------------------------------------------

// -------------------------------------------------------------------------------------------------------------------
//      Data Definitions
// -------------------------------------------------------------------------------------------------------------------

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// NOTE: the maximum RX timeout is ~ 65ms
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


// -------------------------------------------------------------------------------------------------------------------
// Functions
// -------------------------------------------------------------------------------------------------------------------



static uint16 mesh_get_short_addr_by_index(instance_data_t *inst, uint8 index)
{
	uint16 shortAddr = 0;

	if(index < inst->uwbListLen)
	{
		memcpy(&shortAddr, &inst->uwbList[index][0], sizeof(uint16));
	}

	return shortAddr;
}

static int mesh_find_index_by_short_addr(instance_data_t *inst, uint16 shortAddr)
{
	for(int i = 0; i < inst->uwbListLen; i++)
	{
		uint16 candidate = 0;
		memcpy(&candidate, &inst->uwbList[i][0], sizeof(uint16));
		if(candidate == shortAddr)
		{
			return i;
		}
	}

	return -1;
}
/**
 * @brief ӵǰ豸ھбѡڵ̵ַѡСЧ̵ַΪڵ㣩
 * @param inst ʵָ룬洢豸Ϣھбڵַ
 * @return ѡڵ̵ַ
 */
static uint16 mesh_select_master_short_addr(instance_data_t *inst)
{
	// ʼڵ̵ַĬʹ豸UWB̵ַ
	uint16 masterShortAddr = inst->uwbShortAdd;
	 // ȡTDMAṹָ루TDMAʱֶַUWBͨʱ϶
	struct TDMAHandler *tdma = tdma_get_local_structure_ptr();
 // UWBھб1ʼ0豸
	for(int i = 1; i < inst->uwbListLen; i++)
	{
		 // ȡǰӦھӵ
		uint8 connectionType = tdma->uwbListTDMAInfo[i].connectionType;
		 // Чھͣͨھӡھӡ˫ھ
		if(connectionType == UWB_LIST_NEIGHBOR ||
		   connectionType == UWB_LIST_HIDDEN ||
		   connectionType == UWB_LIST_TWICE_HIDDEN)
		{
			// бȡھӵUWB̵ַ
			uint16 candidate = mesh_get_short_addr_by_index(inst, (uint8)i);
			// ɸѡ̵ַЧ0ұȵǰڵַС
			if(candidate != 0 && candidate < masterShortAddr)
			{
				// ڵ̵ַΪСĺѡַ
				masterShortAddr = candidate;
			}
		}
	}
// ѡڵ̵ַ浽ʵ
	inst->meshMasterShortAddr = masterShortAddr;
	// ѡڵ̵ַ
	return masterShortAddr;
}

static uint8 mesh_is_master(instance_data_t *inst)
{
	return (mesh_select_master_short_addr(inst) == inst->uwbShortAdd) ? TRUE : FALSE;
}


#define SS_LCC_Q26_SCALE                    67108864.0
#define SS_LCC_MIN                          0.999
#define SS_LCC_MAX                          1.001
#define SS_LCC_CSR_R                        1.0e-12
#define SS_LCC_CFR_R                        4.0e-12
#define SS_LCC_PROC_LCC                     1.0e-16
#define SS_LCC_PROC_DRIFT                   1.0e-20
#define SS_LCC_DEFAULT_DT_SEC               0.05

static double ss_lcc_clip(double v)
{
    if(v < SS_LCC_MIN || v > SS_LCC_MAX)
    {
        return 1.0;
    }
    return v;
}

static int32 ss_double_to_q26(double v)
{
    v = ss_lcc_clip(v);
    return (int32)(v * SS_LCC_Q26_SCALE);
}

static double ss_q26_to_double(int32 q26)
{
    return ((double)q26) / SS_LCC_Q26_SCALE;
}

static double ss_dt_to_sec(uint64 dt)
{
    return ((double)dt) * DWT_TIME_UNITS;
}

static void ss_lcc_kf_predict(instance_data_t *inst, uint8 idx, double dtSeconds)
{
    double p00;
    double p01;
    double p10;
    double p11;

    if(idx >= UWB_LIST_SIZE)
    {
        return;
    }

    if(inst->lccValid[idx] == FALSE)
    {
        inst->lccX[idx] = 1.0;
        inst->lccDrift[idx] = 0.0;
        inst->lccP00[idx] = 1.0e-8;
        inst->lccP01[idx] = 0.0;
        inst->lccP10[idx] = 0.0;
        inst->lccP11[idx] = 1.0e-12;
        inst->lccValid[idx] = TRUE;
    }

    if(dtSeconds <= 0.0 || dtSeconds > 10.0)
    {
        dtSeconds = SS_LCC_DEFAULT_DT_SEC;
    }

    inst->lccX[idx] = ss_lcc_clip(inst->lccX[idx] + (dtSeconds * inst->lccDrift[idx]));

    p00 = inst->lccP00[idx] + dtSeconds * (inst->lccP10[idx] + inst->lccP01[idx]) + (dtSeconds * dtSeconds * inst->lccP11[idx]) + SS_LCC_PROC_LCC;
    p01 = inst->lccP01[idx] + dtSeconds * inst->lccP11[idx];
    p10 = inst->lccP10[idx] + dtSeconds * inst->lccP11[idx];
    p11 = inst->lccP11[idx] + SS_LCC_PROC_DRIFT;

    inst->lccP00[idx] = p00;
    inst->lccP01[idx] = p01;
    inst->lccP10[idx] = p10;
    inst->lccP11[idx] = p11;
}

static void ss_lcc_kf_update_scalar(instance_data_t *inst, uint8 idx, double z, double r)
{
    double y;
    double s;
    double k0;
    double k1;
    double p00;
    double p01;
    double p10;
    double p11;

    if(idx >= UWB_LIST_SIZE || z < SS_LCC_MIN || z > SS_LCC_MAX)
    {
        return;
    }

    if(r <= 0.0)
    {
        r = SS_LCC_CFR_R;
    }

    p00 = inst->lccP00[idx];
    p01 = inst->lccP01[idx];
    p10 = inst->lccP10[idx];
    p11 = inst->lccP11[idx];

    s = p00 + r;
    if(s <= 1.0e-30)
    {
        return;
    }

    y = z - inst->lccX[idx];
    k0 = p00 / s;
    k1 = p10 / s;

    inst->lccX[idx] = ss_lcc_clip(inst->lccX[idx] + (k0 * y));
    inst->lccDrift[idx] = inst->lccDrift[idx] + (k1 * y);

    inst->lccP00[idx] = (1.0 - k0) * p00;
    inst->lccP01[idx] = (1.0 - k0) * p01;
    inst->lccP10[idx] = p10 - (k1 * p00);
    inst->lccP11[idx] = p11 - (k1 * p01);
}

static double ss_lcc_kf_update(instance_data_t *inst, uint8 idx, double dtSeconds, const double *z, const double *r, uint8 count)
{
    uint8 i;

    ss_lcc_kf_predict(inst, idx, dtSeconds);

    for(i = 0; i < count; i++)
    {
        ss_lcc_kf_update_scalar(inst, idx, z[i], r[i]);
    }

    if(idx >= UWB_LIST_SIZE || inst->lccValid[idx] == FALSE)
    {
        return 1.0;
    }

    return ss_lcc_clip(inst->lccX[idx]);
}

#define MESH_COORD_EXP_NUM                 3
#define MESH_COORD_EXP_DEN                 10

static int32 mesh_round_double_to_int32(double v)
{
    if(v >= 0.0)
    {
        return (int32)(v + 0.5);
    }

    return (int32)(v - 0.5);
}

static int32 mesh_exp_smooth_i32(int32 oldValue, int32 newValue)
{
    int32 num;

    num = (MESH_COORD_EXP_NUM * newValue) + ((MESH_COORD_EXP_DEN - MESH_COORD_EXP_NUM) * oldValue);
    if(num >= 0)
    {
        return (num + (MESH_COORD_EXP_DEN / 2)) / MESH_COORD_EXP_DEN;
    }

    return (num - (MESH_COORD_EXP_DEN / 2)) / MESH_COORD_EXP_DEN;
}

static void mesh_store_coord_exp_smooth(instance_data_t *inst, int index, double x, double y, double z)
{
    int32 xm;
    int32 ym;
    int32 zm;

    if(inst == 0 || index < 0 || index >= UWB_LIST_SIZE)
    {
        return;
    }

    xm = mesh_round_double_to_int32(x);
    ym = mesh_round_double_to_int32(y);
    zm = mesh_round_double_to_int32(z);

    if(inst->coordExpValid[index] != TRUE)
    {
        inst->meshNodeCache[index].relPosMm[0] = xm;
        inst->meshNodeCache[index].relPosMm[1] = ym;
        inst->meshNodeCache[index].relPosMm[2] = zm;
        inst->coordExpValid[index] = TRUE;
    }
    else
    {
        inst->meshNodeCache[index].relPosMm[0] = mesh_exp_smooth_i32(inst->meshNodeCache[index].relPosMm[0], xm);
        inst->meshNodeCache[index].relPosMm[1] = mesh_exp_smooth_i32(inst->meshNodeCache[index].relPosMm[1], ym);
        inst->meshNodeCache[index].relPosMm[2] = mesh_exp_smooth_i32(inst->meshNodeCache[index].relPosMm[2], zm);
    }
}

static void mesh_debug_emit_line(const char *line)
{
	if(line == NULL)
	{
		return;
	}

	printf("%s", line);
	USB_TxWrite((uint8 *)line, (uint32)strlen(line));
}

// ⲿõĽӿ
static int debug_append_addr_hex(char *line, int index, const uint8 *addr, uint8 addrByteSize)
{
	int i;

	if(line == NULL || addr == NULL || addrByteSize == 0)
	{
		return index;
	}

	for(i = (int)addrByteSize - 1; i >= 0; i--)
	{
		index += sprintf(&line[index], "%02X", addr[i]);
	}

	return index;
}

static int debug_append_data_hex(char *line, int index, const uint8 *data, uint16 length)
{
	uint16 i;

	if(line == NULL || data == NULL)
	{
		return index;
	}

	for(i = 0; i < length; i++)
	{
		index += sprintf(&line[index], "%02X", data[i]);
		if(i != (uint16)(length - 1))
		{
			line[index++] = ' ';
			line[index] = 0;
		}
	}

	return index;
}

static void debug_usb_print_received_report(instance_data_t *inst, const uint8 *srcAddr, const uint8 *messageData)
{
	char line[320] = {0};
	uint16 reportLength;
	int index = 0;

	if(inst == NULL || srcAddr == NULL || messageData == NULL)
	{
		return;
	}

	reportLength = (uint16)(1U + REPORT_DISTANCE_FIELD_LEN + sizeof(double) + inst->addrByteSize + REPORT_TIMING_BLOCK_LEN + REPORT_LCC_FIELD_LEN + REPORT_COORD_BLOCK_LEN);

	index += sprintf(&line[index], "rx_report src=");
	index = debug_append_addr_hex(line, index, srcAddr, inst->addrByteSize);
	index += sprintf(&line[index], " peer=");
	index = debug_append_addr_hex(line, index, &messageData[REPORT_ADDR], inst->addrByteSize);
	index += sprintf(&line[index], " len=%u data=", (unsigned int)reportLength);
	index = debug_append_data_hex(line, index, messageData, reportLength);
	index += sprintf(&line[index], "\r\n");

	USB_TxWrite((uint8 *)line, (uint32)index);
}

void debug_print_line(char *line)
{
    mesh_debug_emit_line(line);
}

/**
 * @brief  ʱӡMeshڵ״̬Ϣרã
 * @param  inst: 豸ʵָ룬Meshڵ㻺Ϣ
 * @return ޷ֵ
 * @note   ÿ500msӡһΣʵʱ鿴ڵꡢCSRЧԵ״̬
 */
static void mesh_debug_report_results(instance_data_t *inst)
{
	// ӡַ
	char line[160];
	// ȡǰϵͳʱ䣨룩
	uint32 nowMs = portGetTickCnt();
	// ¼һδӡʱ䣨̬ȫֻʼһΣ
	static uint32 lastPrintMs = 0;

	// ָ밲ȫ
	if(inst == NULL)
	{
		return;
	}

	// ӡƵʿƣһδӡ500msֱ˳
	if((nowMs - lastPrintMs) < 500U)
	{
		return;
	}

	// һδӡʱΪǰʱ
	lastPrintMs = nowMs;

    // ==============================================
    // ֧1ǰ豸ǡڵMaster
    // ӡԼ + дӽڵꡢCSRϢ
    // ==============================================
	if(mesh_is_master(inst) == TRUE)
	{
		// ӡڵϢַX/Y/ZꡢCSRֵ
		int len = sprintf(line,
					  "MESH MASTER=%u SELF X=%ld Y=%ld Z=%ld CSR_Q16=%ld\r\n",
					  (unsigned int)inst->uwbShortAdd,          // ̵ַ
					  (long)inst->meshNodeCache[0].relPosMm[0],  // X(mm)
					  (long)inst->meshNodeCache[0].relPosMm[1],  // Y(mm)
					  (long)inst->meshNodeCache[0].relPosMm[2],  // Z(mm)
					  (long)inst->meshNodeCache[0].csrQ16);      // ʱƫCSR(Q16ʽ)

		// ʹӡ
		if(len > 0)
		{
			mesh_debug_emit_line(line);
		}

		// дӽڵ㣨1ʼ0ڵ㣩
		for(int idx = 1; idx < inst->uwbListLen && idx < UWB_LIST_SIZE; idx++)
		{
			// ȡǰڵ㻺
			mesh_node_cache_t *cache = &inst->meshNodeCache[idx];

			// ڵЧ
			if(cache->valid != TRUE)
			{
				continue;
			}

			// ӡӽڵϢַCSRЧԡЧԡꡢCSR
			len = sprintf(line,
					   "MESH NODE=%u CSR_VALID=%u POS_VALID=%u X=%ld Y=%ld Z=%ld CSR_Q16=%ld\r\n",
					   (unsigned int)cache->nodeShortAddr,       // ڵ̵ַ
					   (unsigned int)cache->csrValid,            // CSRǷЧ
					   (unsigned int)cache->positionValid,       // ǷЧ
					   (long)cache->relPosMm[0],                 // X(mm)
					   (long)cache->relPosMm[1],                 // Y(mm)
					   (long)cache->relPosMm[2],                 // Z(mm)
					   (long)cache->csrQ16);                     // CSRֵ(Q16)
			if(len > 0)
			{
				mesh_debug_emit_line(line);
			}
		}
	}
	// ==============================================
    // ֧2ǰ豸ǡӽڵ㡿
    // ֻӡԼϢڵȡꡢCSR
    // ==============================================
	else
	{
		// ȡڵ㻺
		mesh_node_cache_t *selfCache = &inst->meshNodeCache[0];

		// ӡӽڵϢַڵַCSR/ЧԡꡢCSR
		int len = sprintf(line,
					  "MESH SELF=%u MASTER=%u CSR_VALID=%u POS_VALID=%u X=%ld Y=%ld Z=%ld CSR_Q16=%ld\r\n",
					  (unsigned int)inst->uwbShortAdd,           // ַ
					  (unsigned int)inst->meshMasterShortAddr,   // ڵַ
					  (unsigned int)selfCache->csrValid,         // CSRЧ־
					  (unsigned int)selfCache->positionValid,    // Ч־
					  (long)selfCache->relPosMm[0],              // X
					  (long)selfCache->relPosMm[1],              // Y
					  (long)selfCache->relPosMm[2],              // Z
					  (long)selfCache->csrQ16);                  // CSRֵ

		if(len > 0)
		{
			mesh_debug_emit_line(line);
		}
	}



}

static __attribute__((unused)) uint64 mesh_read_uwb_systime40(void)
{
	uint8 sys_time_arr[5] = {0, 0, 0, 0, 0};
	uint64 sys_time = 0;

	dwt_readsystime(sys_time_arr);
	sys_time = (uint64)sys_time_arr[0]
			   + ((uint64)sys_time_arr[1] << 8)
			   + ((uint64)sys_time_arr[2] << 16)
			   + ((uint64)sys_time_arr[3] << 24)
			   + ((uint64)sys_time_arr[4] << 32);

	return sys_time & MASK_40BIT;
}

static void mesh_write_transport_header(uint8 *buffer,
							uint8 reportType,
							uint16 originId,
							uint16 finalDestId,
							uint16 subjectId,
							uint8 packetSeq,
							uint8 hopsLeft,
							uint8 totalChunks,
							uint8 chunkIndex,
							uint8 flags,
							uint8 payloadLength)
{
	buffer[FCODE] = RTLS_DEMO_MSG_RNG_REPORT;
	buffer[REPORT_MSG_TYPE] = reportType;
	memcpy(&buffer[REPORT_ORIGIN_ID], &originId, sizeof(uint16));
	memcpy(&buffer[REPORT_FINAL_DEST_ID], &finalDestId, sizeof(uint16));
	memcpy(&buffer[REPORT_SUBJECT_ID], &subjectId, sizeof(uint16));
	buffer[REPORT_PACKET_SEQ] = packetSeq;
	buffer[REPORT_HOPS_LEFT] = hopsLeft;
	buffer[REPORT_TOTAL_CHUNKS] = totalChunks;
	buffer[REPORT_CHUNK_INDEX] = chunkIndex;
	buffer[REPORT_FLAGS] = flags;
	buffer[REPORT_PAYLOAD_LENGTH] = payloadLength;
}
// ###########################################################################
// mesh_collect_sorted_neighbors
// ܣռЧھӽڵ㡿ʱС
// 
//   neighborIndex[]   ЧھӵĽڵб
//   neighborTs[]      Ӧڵʱ
//   *neighborCount    ҵЧھ
// ###########################################################################
static void mesh_collect_sorted_neighbors(instance_data_t *inst,// 豸ʵ״̬á棩
							 uint8 *neighborIndex,// ھӽڵ
							 uint64 *neighborTs,// ھӽڵӦʱ
							 uint8 *neighborCount)// Чھӵ
{
	// ȡ TDMA Ƚṹ壨ʱ϶ھб
	struct TDMAHandler *tdma = tdma_get_local_structure_ptr();
	// ؼ¼ǰҵٸЧھ
	uint8 count = 0;
 // ===================== һ豸ռЧھ =====================
    //  i=1 ʼi=0 Լ
    // 豸б + ھֵ
	for(int i = 1; i < inst->uwbListLen && count < UWB_LIST_SIZE; i++)
	{
		// ж
        // 1. 豸ǡھӽڵ㡿(UWB_LIST_NEIGHBOR)
        // 2. յ INFO ϢʱΪ 0
		if(tdma->uwbListTDMAInfo[i].connectionType == UWB_LIST_NEIGHBOR && inst->infoMsgRxTimestamp[i] != 0)
		{
			// ھӵġ
			neighborIndex[count] = (uint8)i;
			 // ھӵġϢʱֻ42λUWB ʱ׼
			neighborTs[count] = inst->infoMsgRxTimestamp[i] & MASK_42BIT;
			 // ҵһ +1
			count++;
		}
	}
// ===================== ڶð  ʱС =====================
    // ˭ʱСԽյϢԽǰ
	for(int i = 0; i < count; i++)
	{
		for(int j = i + 1; j < count; j++)
		{
			 // ǰʱ >   λ
			if(neighborTs[i] > neighborTs[j])
			{
				// ʱ
				uint64 tsTmp = neighborTs[i];
				// ӦĽڵ
				uint8 idxTmp = neighborIndex[i];
				neighborTs[i] = neighborTs[j];
				neighborIndex[i] = neighborIndex[j];
				neighborTs[j] = tsTmp;
				neighborIndex[j] = idxTmp;
			}
		}
	}
// ===================== Чھ =====================
	*neighborCount = count;
}


typedef struct
{
	uint8 used;
	double x;
	double y;
} mesh_loc_solution_t;

static double mesh_abs_double(double value)
{
	return (value < 0.0) ? -value : value;
}

static double mesh_sqrt_double(double value)
{
	double x = 0.0;
	double last = 0.0;
	int iter = 0;

	if(value <= 0.0)
	{
		return 0.0;
	}

	x = (value > 1.0) ? value : 1.0;
	for(iter = 0; iter < 16; iter++)
	{
		last = x;
		x = 0.5 * (x + (value / x));
		if(mesh_abs_double(x - last) < 1.0e-6)
		{
			break;
		}
	}

	return x;
}

static double mesh_q16_to_double(int32 q16)
{
	return ((double)q16) / 65536.0;
}

static int32 mesh_double_to_q16(double value)
{
	if(value > 32767.0)
	{
		value = 32767.0;
		}
	else if(value < -32768.0)
	{
		value = -32768.0;
	}
	return (int32)(value * 65536.0);
}


static uint8 mesh_dloc_is_master_id(instance_data_t *inst, uint16 shortAddr)
{
    return (shortAddr == mesh_select_master_short_addr(inst)) ? TRUE : FALSE;
}

static int mesh_dloc_rank_by_short_addr(instance_data_t *inst, uint16 shortAddr)
{
    int rank = 0;
    int found = FALSE;

    for(int i = 0; i < inst->uwbListLen && i < UWB_LIST_SIZE; i++)
    {
        uint16 candidate = mesh_get_short_addr_by_index(inst, (uint8)i);
        if(candidate == shortAddr)
        {
            found = TRUE;
        }
        if(candidate != 0 && candidate < shortAddr)
        {
            rank++;
        }
    }

    return (found == TRUE) ? rank : -1;
}

static int mesh_dloc_find_rank_index(instance_data_t *inst, int targetRank)
{
    for(int i = 0; i < inst->uwbListLen && i < UWB_LIST_SIZE; i++)
    {
        uint16 candidate = mesh_get_short_addr_by_index(inst, (uint8)i);
        if(candidate != 0 && mesh_dloc_rank_by_short_addr(inst, candidate) == targetRank)
        {
            return i;
        }
    }
    return -1;
}

static uint8 mesh_dloc_coord_valid_for_index(instance_data_t *inst, int index)
{
    mesh_node_cache_t *cache;
    uint16 shortAddr;

    if(index < 0 || index >= UWB_LIST_SIZE)
    {
        return FALSE;
    }

    cache = &inst->meshNodeCache[index];
    if(cache->positionValid != TRUE)
    {
        return FALSE;
    }

    shortAddr = (index == 0) ? inst->uwbShortAdd : cache->nodeShortAddr;
    if(mesh_dloc_is_master_id(inst, shortAddr) == TRUE)
    {
        return TRUE;
    }

    return (cache->relPosMm[0] != 0 || cache->relPosMm[1] != 0 || cache->relPosMm[2] != 0) ? TRUE : FALSE;
}

static void mesh_dloc_store_self(instance_data_t *inst, double x, double y)
{
    mesh_node_cache_t *selfCache = &inst->meshNodeCache[0];

    selfCache->valid = TRUE;
    selfCache->nodeShortAddr = inst->uwbShortAdd;
    selfCache->positionValid = TRUE;
    mesh_store_coord_exp_smooth(inst, 0, x, y, 0.0);
    selfCache->lastUpdateMs = portGetTickCnt();
}
/**********************************************************************
 * �������ܣ�����¼�������ֵ��
 * ���ã��� A�ڵ� �� B�ڵ� ֮��Ĳ���������ף����浽������
 * �������ж�λ������/����/α���ԣ���ԭʼ������Դ
 * ������
 *  inst   - ģ��ʵ��
 *  indexA - �ڵ�A�������������վ��
 *  indexB - �ڵ�B�������������ǩ��
 *  rangeMm - ���������λ������
 **********************************************************************/
static void mesh_dloc_note_range_mm(instance_data_t *inst, int indexA, int indexB, int32 rangeMm)
{
	// ===================== 1. �Ϸ��Լ�� =====================
    // �������Խ�� ���� A��B��ͬһ���ڵ� �� ֱ�ӷ��أ�������
    if(indexA < 0 || indexB < 0 || indexA >= UWB_LIST_SIZE || indexB >= UWB_LIST_SIZE || indexA == indexB)
    {
        return;
    }
		// ������ֵ��Ч����0���򳬳������ �� ����
    if(rangeMm <= 0 || rangeMm > (int32)MESH_LOC_MAX_DISTANCE_MM)
    {
        return;
    }
// ===================== 2. ���������� =====================
    // ������˫��ģ�A��B = B��A�������������򶼴�
    inst->dlocRangeMm[indexA][indexB] = rangeMm;
    inst->dlocRangeMm[indexB][indexA] = rangeMm;
		// �����������Ч����λʱ���ȡ�����־��
    inst->dlocRangeValid[indexA][indexB] = TRUE;
    inst->dlocRangeValid[indexB][indexA] = TRUE;
}
/**********************************************************************
 * �������ܣ�������Զ�˽ڵ����꡿
 * ���ã����յ��ġ���վ���꡿���浽���ؽڵ㻺����
 * ���壺��ǩ֪����ÿ����վ�������������������Щ��������λ
 * ������
 *   inst  ��ģ��ʵ��
 *   index ����վ�ڽڵ��б��е�����
 *   x,y,z ����վ���������꣨��λ��mm��
 **********************************************************************/
static void mesh_dloc_update_remote_coord(instance_data_t *inst, int index, int32 x, int32 y, int32 z)
{
    mesh_node_cache_t *cache; // �ڵ㻺��ָ�루�洢���ꡢ״̬��
    uint16 shortAddr;// ��վ�Ķ̵�ַ��UWB ��ַ��
// ��ȫ��飺����Խ��ֱ�ӷ���
    if(index < 0 || index >= UWB_LIST_SIZE)
    {
        return;
    }
 // �õ���Ӧ�����Ľڵ㻺��
    cache = &inst->meshNodeCache[index];
		// ����������ȡ�û�վ��UWB�̵�ַ
    shortAddr = mesh_get_short_addr_by_index(inst, (uint8)index);
		 // ��Ǹû�վ������Ч�����ã�
    cache->valid = TRUE;
		// �����վ��ַ
    cache->nodeShortAddr = shortAddr;
/**********************************************************************
     * �ؼ��߼���
     * ���������վ��master�����������겻��ȫ0������ʵλ�ã�
     * �Ͱ�������뻺�棬�����������Ч
     **********************************************************************/
    if(mesh_dloc_is_master_id(inst, shortAddr) == TRUE || x != 0 || y != 0 || z != 0)
    {
			 // ���������Ч����λʱ��ʹ��������꣩
        cache->positionValid = TRUE;
			// ===================== �����ģ������վ���꡿ =====================
        cache->relPosMm[0] = x;
        cache->relPosMm[1] = y;
        cache->relPosMm[2] = z;
        cache->lastUpdateMs = portGetTickCnt();
    }
}

static uint8 mesh_dloc_solve_by_two(instance_data_t *inst, int ref0, int ref1, double *x, double *y)
{
    double x0, y0, x1, y1, d01, r0, r1, a, h2, h, ux, uy;

    if(x == NULL || y == NULL || ref0 < 0 || ref1 < 0)
    {
        return FALSE;
    }
    if(mesh_dloc_coord_valid_for_index(inst, ref0) != TRUE || mesh_dloc_coord_valid_for_index(inst, ref1) != TRUE)
    {
        return FALSE;
    }
    if(inst->dlocRangeValid[0][ref0] != TRUE || inst->dlocRangeValid[0][ref1] != TRUE)
    {
        return FALSE;
    }

    x0 = (double)inst->meshNodeCache[ref0].relPosMm[0];
    y0 = (double)inst->meshNodeCache[ref0].relPosMm[1];
    x1 = (double)inst->meshNodeCache[ref1].relPosMm[0];
    y1 = (double)inst->meshNodeCache[ref1].relPosMm[1];
    r0 = (double)inst->dlocRangeMm[0][ref0];
    r1 = (double)inst->dlocRangeMm[0][ref1];
    d01 = mesh_sqrt_double(((x1 - x0) * (x1 - x0)) + ((y1 - y0) * (y1 - y0)));
    if(d01 <= MESH_LOC_EPSILON)
    {
        return FALSE;
    }

    a = ((r0 * r0) - (r1 * r1) + (d01 * d01)) / (2.0 * d01);
    h2 = (r0 * r0) - (a * a);
    if(h2 < 0.0)
    {
        h2 = 0.0;
    }
    h = mesh_sqrt_double(h2);
    ux = (x1 - x0) / d01;
    uy = (y1 - y0) / d01;
    *x = x0 + (a * ux) - (h * uy);
    *y = y0 + (a * uy) + (h * ux);
    return TRUE;
}

static uint8 mesh_dloc_solve_by_three(instance_data_t *inst, int a0, int a1, int a2, double *x, double *y)
{
    double x0, y0, x1, y1, x2, y2, r0, r1, r2;
    double A, B, C, D, E, F, det;

    if(x == NULL || y == NULL)
    {
        return FALSE;
    }
    if(mesh_dloc_coord_valid_for_index(inst, a0) != TRUE || mesh_dloc_coord_valid_for_index(inst, a1) != TRUE || mesh_dloc_coord_valid_for_index(inst, a2) != TRUE)
    {
        return FALSE;
    }
    if(inst->dlocRangeValid[0][a0] != TRUE || inst->dlocRangeValid[0][a1] != TRUE || inst->dlocRangeValid[0][a2] != TRUE)
    {
        return FALSE;
    }

    x0 = (double)inst->meshNodeCache[a0].relPosMm[0];
    y0 = (double)inst->meshNodeCache[a0].relPosMm[1];
    x1 = (double)inst->meshNodeCache[a1].relPosMm[0];
    y1 = (double)inst->meshNodeCache[a1].relPosMm[1];
    x2 = (double)inst->meshNodeCache[a2].relPosMm[0];
    y2 = (double)inst->meshNodeCache[a2].relPosMm[1];
    r0 = (double)inst->dlocRangeMm[0][a0];
    r1 = (double)inst->dlocRangeMm[0][a1];
    r2 = (double)inst->dlocRangeMm[0][a2];

    A = 2.0 * (x1 - x0);
    B = 2.0 * (y1 - y0);
    C = (r0 * r0) - (r1 * r1) - (x0 * x0) + (x1 * x1) - (y0 * y0) + (y1 * y1);
    D = 2.0 * (x2 - x0);
    E = 2.0 * (y2 - y0);
    F = (r0 * r0) - (r2 * r2) - (x0 * x0) + (x2 * x2) - (y0 * y0) + (y2 * y2);
    det = (A * E) - (B * D);
    if(mesh_abs_double(det) <= 1.0e-6)
    {
        return FALSE;
    }

    *x = ((C * E) - (B * F)) / det;
    *y = ((A * F) - (C * D)) / det;
    return TRUE;
}
/**********************************************************************
 * �������ܣ����ڵ�������λ����ڡ�
 * ���ã����������ȼ���rank = 0/1/2/3+�����Զ�ѡ���Ӧ�Ķ�λ�㷨
 *       ������Լ������겢����
 * ��ȫ��Ӧ������Ĺ���
 *    rank0 (���ڵ�)     �� (0,0)
 *    rank1 (�����ڵ�)   �� (����, 0)
 *    rank2 (�δνڵ�)   �� ���㶨λѡ�Ͻ�
 *    rank3+ (�����ڵ�)  �� ���㶨λΨһ��
 **********************************************************************/
static void mesh_dloc_update_self_position(instance_data_t *inst)
{
    uint16 selfId = inst->uwbShortAdd;// ����UWB��ַ
    int selfRank = mesh_dloc_rank_by_short_addr(inst, selfId);// ��ȡ�����ȼ���0��/1����/2�δ�/3+
    int masterIndex = mesh_dloc_find_rank_index(inst, 0); // �ҵ�����վ(rank0)����
    int secondIndex = mesh_dloc_find_rank_index(inst, 1);// �ҵ�������վ(rank1)����
    double x = 0.0; // ����������
    double y = 0.0;
// ===================== ����վ(rank0) ǿ������ (0,0) =====================
    if(masterIndex >= 0)
    {
			// ������վ����д�뱾�ػ��棺�̶� (0,0,0)
        mesh_dloc_update_remote_coord(inst, masterIndex, 0, 0, 0);
    }
 // ===================== �ȼ� 0�����ڵ㣨ԭ�㣩=====================
    if(selfRank == 0)
    {
			// ���ڵ�����д����(0, 0)
        mesh_dloc_store_self(inst, 0.0, 0.0);
        return;
    }
// ===================== �ȼ� 1�������ڵ㣨X���ϣ�=====================
    if(selfRank == 1)
    {
			// �����ڵ����x = �����ڵ���룬y = 0
        if(masterIndex >= 0 && inst->dlocRangeValid[0][masterIndex] == TRUE)
        {
					// ���� = (�������ڵ�, 0)
            mesh_dloc_store_self(inst, (double)inst->dlocRangeMm[0][masterIndex], 0.0);
        }
        return;
    }
// ===================== �ȼ� 2���δνڵ㣨���㶨λ��=====================
    if(selfRank == 2)
    {
			// �� rank0 + rank1 ������վ �� ���㶨λ
        if(masterIndex >= 0 && secondIndex >= 0 && mesh_dloc_solve_by_two(inst, masterIndex, secondIndex, &x, &y) == TRUE)
        {
					 // ���ɹ� �� ��������
            mesh_dloc_store_self(inst, x, y);
        }
        return;
    }
// ===================== �ȼ� 3�����ϣ����㶨λ��������3����Ч��վ��=====================
    // ����������ϣ�Ѱ������ 3 ����������Ч + ������Ч���Ļ�վ
    for(int i = 0; i < inst->uwbListLen && i < UWB_LIST_SIZE; i++)
    {
			// ���������ڵ�/������Ч/������Ч�Ļ�վ
        if(i == 0 || mesh_dloc_coord_valid_for_index(inst, i) != TRUE || inst->dlocRangeValid[0][i] != TRUE)
        {
            continue;
        }
        for(int j = i + 1; j < inst->uwbListLen && j < UWB_LIST_SIZE; j++)
        {
            if(j == 0 || mesh_dloc_coord_valid_for_index(inst, j) != TRUE || inst->dlocRangeValid[0][j] != TRUE)
            {
                continue;
            }
            for(int k = j + 1; k < inst->uwbListLen && k < UWB_LIST_SIZE; k++)
            {
                if(k == 0 || mesh_dloc_coord_valid_for_index(inst, k) != TRUE || inst->dlocRangeValid[0][k] != TRUE)
                {
                    continue;
                }
								// ===================== ���ģ����㶨λ��� =====================
                if(mesh_dloc_solve_by_three(inst, i, j, k, &x, &y) == TRUE)
                {
                    mesh_dloc_store_self(inst, x, y); // ���Ψһ���� �� ����
                    return;
                }
            }
        }
    }
}

static uint8 mesh_get_node_tx_pair(instance_data_t *inst, int index, uint64 *previousTxTs, uint64 *currentTxTs)
{
	if(previousTxTs == NULL || currentTxTs == NULL)
	{
		return FALSE;
	}

	if(index == 0)
	{
		*previousTxTs = inst->meshNodeCache[index].currentTxTs & MASK_42BIT;
		*currentTxTs = inst->infoMsgTxTimestampCurrent & MASK_42BIT;
	}
	else if(index > 0 && index < UWB_LIST_SIZE && inst->meshNodeCache[index].valid)
	{
		*previousTxTs = inst->meshNodeCache[index].previousTxTs & MASK_42BIT;
		*currentTxTs = inst->meshNodeCache[index].currentTxTs & MASK_42BIT;
	}
	else
	{
		return FALSE;
	}

	return (*previousTxTs != 0 && *currentTxTs != 0) ? TRUE : FALSE;
}
/**********************************************************************
* ܣȡսڵ㡿ӡͽڵ㡿յϢʱ
* ڲ
*     inst           ģʵָ
*     receiverIndex  սڵ0ʾؽڵ㣩
*     transmitterIndexͽڵ
*     rxTs           ڴŻȡĽʱ
* ֵTRUE=ɹȡЧʱFALSE=ȡʧ
**********************************************************************/
static uint8 mesh_get_node_rx_from_neighbor(instance_data_t *inst, int receiverIndex, int transmitterIndex, uint64 *rxTs)
{
	// 1. ָϷԼ飺ָֹ뵼³
	if(rxTs == NULL)
	{
		return FALSE;
	}
	// 2. ڵϷԼ飺շڵΪҲܳб󳤶
	if(receiverIndex < 0 || transmitterIndex < 0 || receiverIndex >= UWB_LIST_SIZE || transmitterIndex >= UWB_LIST_SIZE)
	{
		return FALSE;
	}
// 3. սڵǱؽڵ㣨receiverIndex=0أ
	if(receiverIndex == 0)
	{
		// 鷢ͽڵЧұرĸ÷ͽڵʱΪ0
		if(transmitterIndex < inst->uwbListLen && inst->infoMsgRxTimestamp[transmitterIndex] != 0)
		{
			// ȡʱֻ42λUWBӲʱΪ42bit
			*rxTs = inst->meshNodeCache[receiverIndex].neighborRxTs[transmitterIndex] & MASK_42BIT;
			return TRUE;
		}
		// ͽڵЧ or ʱΪ0  ȡʧ
		return FALSE;
	}
// 4. սڵԶ̽ڵ㣬ӽڵ㻺жȡӦھӵĽʱ
	// սڵ㻺ЧҸýڵĶӦھҲЧ
	if(inst->meshNodeCache[receiverIndex].valid && inst->meshNodeCache[receiverIndex].neighborValid[transmitterIndex])
	{
		// ȡھӽʱֻ42λ
		*rxTs = inst->meshNodeCache[receiverIndex].neighborRxTs[transmitterIndex] & MASK_42BIT;
		// ʱΪ0򷵻سɹΪ0򷵻ʧ
		return (*rxTs != 0) ? TRUE : FALSE;
	}
// 5.   ȡʧ
	return FALSE;
}
// ###########################################################################
// mesh_refresh_local_cache_from_runtime
// ܣˢ¡ؽڵ㣨Լ Mesh 
// ãѵǰʱʵʱϢʱַ״̬µ meshNodeCache[0]
// ###########################################################################
static void mesh_refresh_local_cache_from_runtime(instance_data_t *inst,uint64 currentTxTs,uint64 previousTxTs)
{
	// ȡ0Žڵ = 豸ԼĻָ
	// meshNodeCache[0] ̶űؽڵϢ
	mesh_node_cache_t *selfCache = &inst->meshNodeCache[0];
	int i = 0;
// ===================== 1. ýڵ״̬ =====================
	// Ǳڵ㻺Ч
	selfCache->valid = TRUE;
	// ñڵĶ̵ַ16λַ
	selfCache->nodeShortAddr = inst->uwbShortAdd;
	// ===================== 2. ʱͬMesh ʱӺģ =====================
	// ǰϢʱ42λUWB ׼ʱ
	// һηϢʱ
	selfCache->previousTxTs = previousTxTs & MASK_42BIT;
	selfCache->currentTxTs = currentTxTs & MASK_42BIT;
//	// ڵʱ = ǰʱԼڵʱ
//	selfCache->masterRxTs = selfCache->currentTxTs;
//	// һڵʱ
//	selfCache->previousMasterRxTs = selfCache->previousTxTs;
	// ===================== 3. CSR ʱƫ =====================
	// CSR ʱУֵЧ
	selfCache->csrValid = TRUE;
	// ؽڵԼ CSR ĬΪ 1.0Q16 ʽ
	// ΪԼҪУԼʱ
	selfCache->csrQ16 = MESH_LOC_Q16_ONE;
	// ===================== 4. λ =====================
	// λЧ
	selfCache->positionValid = TRUE;
	// Լ꣨X,Y,ZȫΪ 0
	// ڵ/ؽڵϵԭ (0,0,0)
	selfCache->relPosMm[0] = 0;
	selfCache->relPosMm[1] = 0;
	selfCache->relPosMm[2] = 0;
	// ¼ʱ䣨ϵͳǰ
	selfCache->lastUpdateMs = portGetTickCnt();
	// ===================== 5. ھ״̬ =====================
	// ھӵ valid ־ȫ 0
	memset(&selfCache->neighborValid[0], 0, sizeof(selfCache->neighborValid));
	// ھӵĽʱ 0
	memset(&selfCache->neighborRxTs[0], 0, sizeof(selfCache->neighborRxTs));
// ===================== 6. ¼Чھ =====================
	// 豸1ʼ0Լ
	for(i = 1; i < inst->uwbListLen && i < UWB_LIST_SIZE; i++)
	{
		// յýڵ INFO Ϣʱ0
		if(inst->infoMsgRxTimestamp[i] != 0)
		{
			// ǸھЧ
			selfCache->neighborValid[i] = TRUE;
			// ھϢĽʱ
			selfCache->neighborRxTs[i] = inst->infoMsgRxTimestamp[i] & MASK_42BIT;
		}
	}
}
/**********************************************************************
 * ܣ㡾οڵ㡿ڡĿڵ㡿 CSR ʱƯƱ
 *           нڵ CSR ڵ(0)
 *           ˺Ƶ ӽڵ ֮ʱƫ
 * 
 *      inst        豸ʵ
 *      refIndex    οڵ
 *      targetIndex Ŀڵ
 *      csrQ16       CSR ֵQ16ʽ
 * أTRUE ɹ / FALSE ʧ
 **********************************************************************/
static uint8 mesh_get_csr_q16_between(instance_data_t *inst, int refIndex, int targetIndex, int32 *csrQ16)
{
	// οڵ  ڵ ʱƯ
	double refToMaster = 1.0;
	// Ŀڵ  ڵ ʱƯ
	double targetToMaster = 1.0;
// ָΪգֱӷʧ
	if(csrQ16 == NULL)
	{
		return FALSE;
	}
	// ڵԽ磬ʧ
	if(refIndex < 0 || targetIndex < 0 || refIndex >= UWB_LIST_SIZE || targetIndex >= UWB_LIST_SIZE)
	{
		return FALSE;
	}
	// οڵ = Ŀڵ  ʱƯ = 1.0Q16ʽ
	if(refIndex == targetIndex)
	{
		*csrQ16 = MESH_LOC_Q16_ONE;
		return TRUE;
	}
	// ===================== ȡοڵ ڵ CSR =====================
	// οڵ㲻ڵ(0)ЧCSRЧ
	if(refIndex != 0)
	{
		if(inst->meshNodeCache[refIndex].valid != TRUE || inst->meshNodeCache[refIndex].csrValid != TRUE)
		{
			return FALSE;
		}
		// Q16ʽתΪ
		refToMaster = mesh_q16_to_double(inst->meshNodeCache[refIndex].csrQ16);
	}
	// ===================== ȡĿڵ ڵ CSR =====================
	// Ŀڵ㲻ڵ(0)ЧCSRЧ
	if(targetIndex != 0)
	{
		if(inst->meshNodeCache[targetIndex].valid != TRUE || inst->meshNodeCache[targetIndex].csrValid != TRUE)
		{
			return FALSE;
		}
		// Q16ʽתΪ
		targetToMaster = mesh_q16_to_double(inst->meshNodeCache[targetIndex].csrQ16) * 65536.0;
	}
	// ֹ0
	if(targetToMaster <= MESH_LOC_EPSILON)
	{
		return FALSE;
	}
// ===================== Ĺʽ =====================
	// οڵ  Ŀڵ ʱƯ
	// ref  target = (ref  master) / (target  master)
	*csrQ16 = mesh_double_to_q16(refToMaster / targetToMaster);
	// ɹ
	return TRUE;
}
/**********************************************************************
 * ܣUWBڵ֮ġֱ߾롿(λ mm)
 * ԭ˫ʱ䷨(TWR) + CSRʱƯƲ
 * ˵
 *      inst      豸ʵָ
 *      indexA    ڵA
 *      indexB    ڵB
 *      distanceMm ľ(mm)
 * ֵTRUEɹFALSEʧ
 **********************************************************************/
static uint8 mesh_compute_pairwise_distance_mm(instance_data_t *inst, int indexA, int indexB, double *distanceMm, uint64 currentTxTs,uint64 previousTxTs)
{
	mesh_node_cache_t *cache = &inst->meshNodeCache[indexB];
	int first = indexA;
	int second = indexB;
	// ڵġһ/Ρʱ
	uint64 firstTxPrev = previousTxTs;
	(void)firstTxPrev;
	uint64 firstTxcur = currentTxTs;
	uint64 secondTxPrev = 0;
	uint64 secondTxCur = 0;
	// ʱAյBʱ䡢BյAʱ䣩
	uint64 secondRxAtFirst = 0;
	uint64 firstRxAtSecond = 0;
	// ڵ㱾صʱ
	uint64 dtAtFirst = 0;
	uint64 dtAtSecond = 0;
	// ʱƯƲֵCSR
	int32 csrFirstOverSecondQ16 = 0;
	(void)csrFirstOverSecondQ16;
	double csrFirstOverSecond = 0.0;
	// ռ
	double tofDtu = 0.0;// ʱ䣨DTUλ
	double mm = 0.0;// վ루ף
// ===================== ϷԼ =====================
	// ָΪ  ʧ
	if(distanceMm == NULL)
	{
		return FALSE;
	}
	// Ч  ԼԼ  ʧ
	if(first < 0 || second < 0 || first >= UWB_LIST_SIZE || second >= UWB_LIST_SIZE || first == second)
	{
		return FALSE;
	}
	// ͳһ˳򣺱֤ first < second
	if(first > second)
	{
		first = indexB;
		second = indexA;
	}
	// ===================== ȡеʱ =====================
	// ȡڵABηʱ
	if(!mesh_get_node_tx_pair(inst, second, &secondTxPrev, &secondTxCur))
	{
		return FALSE;
	}
	// ȡʱ
	// secondRxAtFirst = ڵfirstյڵsecondʱ
	// firstRxAtSecond = ڵsecondյڵfirstʱ
	if(!mesh_get_node_rx_from_neighbor(inst, first, second, &secondRxAtFirst) ||
	   !mesh_get_node_rx_from_neighbor(inst, second, first, &firstRxAtSecond))
	{
		return FALSE;
	}
	// ===================== ȡʱƫ CSR =====================
	// ȡڵ֮ʱƯƱQ16ʽ
//	if(!mesh_get_csr_q16_between(inst, first, second, &csrFirstOverSecondQ16))
//	{
//		return FALSE;
//	}

	// ===================== ʱ =====================
	// ڵfirstӷ  յظ ʱ
	dtAtFirst = get_dt64(firstTxcur, secondRxAtFirst);
	// ڵsecondյ  ظ ʱ
	dtAtSecond = get_dt64(firstRxAtSecond, secondTxCur);
	// ===================== ģCSRʱӲ =====================
	// Q16ʽCSRתΪ
	csrFirstOverSecond = mesh_q16_to_double(cache->csrQ16);
	dbg_cnt_anch_report = firstTxcur;
	dbg_cnt_anch_report1 = secondRxAtFirst;
	dbg_cnt_anch_report2 = firstRxAtSecond;
	dbg_cnt_anch_report3 = secondTxCur;
	// ===================== ˫๫ʽTWR =====================
	// TOF = 0.5 * (Tround - Treply * CSR)
	// ʱƯõ׼ʱ
	tofDtu = 0.5 * (((double)dtAtFirst) - (csrFirstOverSecond * (double)dtAtSecond));
	// ===================== λתDTU   =====================
	mm = tofDtu * MESH_LOC_MM_PER_DTU;

	// ƾںΧ쳣
	if(mm < MESH_LOC_MIN_DISTANCE_MM)
	{
		mm = MESH_LOC_MIN_DISTANCE_MM;
	}
	if(mm > MESH_LOC_MAX_DISTANCE_MM)
	{
		mm = MESH_LOC_MAX_DISTANCE_MM;
	}
	// سɹ
	*distanceMm = mm;
	return TRUE;
}
// ###########################################################################
// mesh_position_store_solution
// ܣ浽ӦĽڵ㻺
// 룺
//   inst    - 豸ʵṹ
//   index   - ҪĽڵ (0,1,2...)
//   solution - õx,y
// ###########################################################################
static void mesh_position_store_solution(instance_data_t *inst, int index, mesh_loc_solution_t *solution)
{
	mesh_node_cache_t *cache;

	if(index < 0 || index >= UWB_LIST_SIZE)
	{
		return;
	}

	cache = &inst->meshNodeCache[index];

	if(solution == NULL || solution->used != TRUE)
	{
		cache->positionValid = FALSE;
		inst->coordExpValid[index] = FALSE;
		return;
	}

	cache->positionValid = TRUE;
	mesh_store_coord_exp_smooth(inst, index, solution->x, solution->y, 0.0);
	cache->lastUpdateMs = portGetTickCnt();
}

/**
 * @brief ȡ Mesh Ĭϱ߳ƽࣩ
 * * ߼
 * 1. ǰ֪ھб
 * 2. ͳЧ 5 ׵ΪЧ
 * 3. Щƽֵ
 * 4. ûЧݣع̶Ĭֵ3 ף
 * * @param inst ʵָ
 * @return uint32 Ĭϱ߳λ (mm)
 */
static uint32 mesh_get_default_edge_mm(instance_data_t *inst)
{
	uint64 sumMm = 0;// ۼܾ루ף
	uint32 count = 0;// ¼ЧĴ
//  1 ʼھб 0 ͨԼ㣩
	for(int i = 1; i < inst->uwbListLen; i++)
	{
		// ˵Ƿľ루0.05 = 5ף
		// Ϊųû⵽򿿵̫µ
		if(inst->idistance[i] > 0.05)
		{
			// λӡסתΪסۼ
			sumMm += (uint64)(inst->idistance[i] * 1000.0);
			count++;
		}
	}
// ͳƵЧھӾ
	if(count > 0)
	{
		// ƽ
		uint32 avg = (uint32)(sumMm / count);
		// ȫƣƽСܵ 500 ף0.5ף
		// ֹڵһص
		if(avg < 500U)
		{
			avg = 500U;
		}
		return avg;
	}
// ߼ĿǰһھӶû⵽ĬΪڵΪ 3000 ף3
	return 3000U;
}

static __attribute__((unused)) uint32 mesh_get_edge_weight_mm(instance_data_t *inst, int fromIndex, int toIndex)
{
	if(fromIndex < 0 || toIndex < 0 || fromIndex >= UWB_LIST_SIZE || toIndex >= UWB_LIST_SIZE)
	{
		return mesh_get_default_edge_mm(inst);
	}

	if(fromIndex == toIndex)
	{
		return 0U;
	}

	if(fromIndex == 0 && toIndex < inst->uwbListLen && inst->idistance[toIndex] > 0.05)
	{
		return (uint32)(inst->idistance[toIndex] * 1000.0);
	}
	if(toIndex == 0 && fromIndex < inst->uwbListLen && inst->idistance[fromIndex] > 0.05)
	{
		return (uint32)(inst->idistance[fromIndex] * 1000.0);
	}

	return mesh_get_default_edge_mm(inst);
}

static uint8 mesh_nodes_are_adjacent(instance_data_t *inst, int fromIndex, int toIndex)
{
	if(fromIndex < 0 || toIndex < 0 || fromIndex >= UWB_LIST_SIZE || toIndex >= UWB_LIST_SIZE)
	{
		return FALSE;
	}

	if(fromIndex == toIndex)
	{
		return TRUE;
	}

	if(fromIndex == 0)
	{
		struct TDMAHandler *tdma = tdma_get_local_structure_ptr();
		if(toIndex < inst->uwbListLen)
		{
			uint8 type = tdma->uwbListTDMAInfo[toIndex].connectionType;
			if(type == UWB_LIST_NEIGHBOR || type == UWB_LIST_HIDDEN || type == UWB_LIST_TWICE_HIDDEN)
			{
				return TRUE;
			}
		}
	}
	if(toIndex == 0)
	{
		return mesh_nodes_are_adjacent(inst, toIndex, fromIndex);
	}

	if(inst->meshNodeCache[fromIndex].neighborValid[toIndex] == TRUE ||
	   inst->meshNodeCache[toIndex].neighborValid[fromIndex] == TRUE)
	{
		return TRUE;
	}

	return FALSE;
}
/**********************************************************************
 * ܣġ¼нڵ (X, Y)
 *           һֱҵģڵCSRͲֵĵط
 * 㷨ԭ߶λ + ƽ漸Ƶ (֪㣬)
 * ڵרã
 **********************************************************************/
static void mesh_recompute_relative_positions(instance_data_t *inst, uint64 currentTxTs, uint64 previousTxTs)
{
	mesh_loc_solution_t solution[UWB_LIST_SIZE];// 洢ÿڵ
	double distanceMm[UWB_LIST_SIZE][UWB_LIST_SIZE];// ڵ (λ)
	uint8 distanceValid[UWB_LIST_SIZE][UWB_LIST_SIZE];// ǷЧ־
	int activeIndex[UWB_LIST_SIZE];// Ծڵ㣨Чڵ㣩б
	int activeCount = 0;// Чڵ
	int anchorIndex = -1;// ڶ׼ê
	double d12 = 0.0;// ׼1  ׼2 ֮ľ
	int i = 0;
	int j = 0;
// ʼлΪ0
	memset(solution, 0, sizeof(solution));
	memset(distanceMm, 0, sizeof(distanceMm));
	memset(distanceValid, 0, sizeof(distanceValid));
	// ģ½պͷ͵ʱһ
	mesh_refresh_local_cache_from_runtime(inst,currentTxTs,previousTxTs);
// ===================== 1ɸѡЧڵ =====================
	for(i = 0; i < inst->uwbListLen && i < UWB_LIST_SIZE; i++)
	{
		// 0ڵ㣬ĬЧڵ뻺Ч
		if(i == 0 || inst->meshNodeCache[i].valid == TRUE)
		{
			activeIndex[activeCount++] = i;// Чб
		}
	}
	// ûЧڵ㣬ֱ˳
	if(activeCount <= 0)
	{
		return;
	}
// ===================== 2Чڵ֮ľ =====================
	//  mesh_compute_pairwise_distance_mm 
	// ڲʹ mesh_update_master_cache  CSR ʱӲ
	for(i = 0; i < activeCount; i++)
	{
		for(j = i + 1; j < activeCount; j++)
		{
			int idxI = activeIndex[i];
			int idxJ = activeIndex[j];
			// ڵ idxI  idxJ ֮ľ루CSRʱУ׼
			//ľ
			if(mesh_compute_pairwise_distance_mm(inst, idxI, idxJ, &distanceMm[idxI][idxJ],currentTxTs,previousTxTs))
			{
				// ˫ģԳƸֵ
				distanceMm[idxJ][idxI] = distanceMm[idxI][idxJ];
				distanceValid[idxI][idxJ] = TRUE;
				distanceValid[idxJ][idxI] = TRUE;
			}
		}
	}

// ===================== 3趨ϵԭ =====================
	// ̶0Ľڵ㣨ڵ㣩Ϊԭ (0, 0)
	solution[0].used = TRUE;
	solution[0].x = 0.0;
	solution[0].y = 0.0;
	// ԭ뻺
	mesh_position_store_solution(inst, 0, &solution[0]);
// ===================== 4ҵڶ׼㣬ȷX =====================
	// ҵһԭЧĽڵ㣬ΪXϵĵ
	for(i = 1; i < activeCount; i++)
	{
		int idx = activeIndex[i];
		if(distanceValid[0][idx])
		{
			anchorIndex = idx;// ڶ׼
			if(distanceMm[0][idx]<0)
			{
				distanceMm[0][idx] = -distanceMm[0][idx];
			}
			d12 = distanceMm[0][idx];// 
			break;
		}
	}
// ûҵڶ׼㣬޷λнڵЧ
	if(anchorIndex < 0 || d12 <= MESH_LOC_EPSILON)
	{
		for(i = 1; i < activeCount; i++)
		{
			inst->meshNodeCache[activeIndex[i]].positionValid = FALSE;
		}
		inst->meshResultPeriodFrames = (uint8)((activeCount > 0) ? activeCount : 1);
		return;
	}
// ڶ׼꣺(d12, 0)X
	solution[anchorIndex].used = TRUE;
	solution[anchorIndex].x = d12;
	solution[anchorIndex].y = 0.0;
	mesh_position_store_solution(inst, anchorIndex, &solution[anchorIndex]);
// ===================== 5㷨ڵ =====================
	// 㷨֪ + δ֪ľ  Ƶδ֪ (X,Y)
	for(i = 1; i < activeCount; i++)
	{
		int idx = activeIndex[i];
		double d1k = 0.0;// ԭ㵽ǰľ
		double d2k = 0.0;// ڶ׼㵽ǰľ
		double xk = 0.0;// X
		double ysq = 0.0;
		double yMag = 0.0;// Yֵ
		double bestY = 0.0;// ȷY
		double bestResidual = -1.0;
		int signLoop = 0;
		int hasConstraint = FALSE;
// ڶ׼㣨Ѿ
		if(idx == anchorIndex)
		{
			continue;
		}
		// ЧЧ
		if(!distanceValid[0][idx] || !distanceValid[anchorIndex][idx])
		{
			inst->meshNodeCache[idx].positionValid = FALSE;
			continue;
		}
// ȡ׼ľ
		d1k = distanceMm[0][idx];
		d2k = distanceMm[anchorIndex][idx];
		// ===================== μ㹫ʽ =====================
		// ֵ X 
		xk = ((d1k * d1k) - (d2k * d2k) + (d12 * d12)) / (2.0 * d12);
		// ɶ Y 
		ysq = (d1k * d1k) - (xk * xk);
		if(ysq < 0.0)
		{
			ysq = 0.0;// ֹ
		}
		yMag = mesh_sqrt_double(ysq);
		bestY = yMag;
//  Y ѡСģŻλȣ
		for(signLoop = 0; signLoop < 2; signLoop++)
		{
			double candidateY = (signLoop == 0) ? yMag : -yMag;
			double residual = 0.0;
			int constraintCount = 0;
			// ѶλڵУ飬
			for(j = 1; j < activeCount; j++)
			{
				int refIdx = activeIndex[j];
				if(refIdx == idx || refIdx == anchorIndex)
				{
					continue;
				}
				if(solution[refIdx].used != TRUE || distanceValid[refIdx][idx] != TRUE)
				{
					continue;
				}
				{
					// Ԥʵʲ
					double dx = xk - solution[refIdx].x;
					double dy = candidateY - solution[refIdx].y;
					double predicted = mesh_sqrt_double((dx * dx) + (dy * dy));
					double err = predicted - distanceMm[refIdx][idx];
					residual += mesh_abs_double(err);
				}
			}
			// ѡСY
			if(constraintCount > 0)
			{
				hasConstraint = TRUE;
				if(bestResidual < 0.0 || residual < bestResidual)
				{
					bestResidual = residual;
					bestY = candidateY;
				}
			}
		}
// ûԼĬȡY
		if(hasConstraint != TRUE)
		{
			bestY = yMag;
		}
// 
		solution[idx].used = TRUE;
		solution[idx].x = xk;
		solution[idx].y = bestY;
		// д meshNodeCache -> relPosMm
		mesh_position_store_solution(inst, idx, &solution[idx]);
	}
// Чڵ㣬ΪЧ
	for(i = 1; i < inst->uwbListLen && i < UWB_LIST_SIZE; i++)
	{
		if(inst->meshNodeCache[i].valid != TRUE)
		{
			inst->meshNodeCache[i].positionValid = FALSE;
		}
	}

	inst->meshResultPeriodFrames = (uint8)((activeCount > 0) ? activeCount : 1);
}
/**********************************************************************
 * ܣӽڵ -> ڵ㡿豸ϢϱϢINFO_UPLOAD
 * ݣʱھӽڵͨϢCSRʱƫơλϢ
 * ΣcurrentTxTs  - ηϢӲʱ
 *       previousTxTs - һηϢӲʱ
 * ֵUWB֡ܳȣڷͣ
 **********************************************************************/
static int mesh_build_info_upload_message(instance_data_t *inst, uint64 currentTxTs, uint64 previousTxTs)
{
	uint8 neighborIndex[UWB_LIST_SIZE] = {0};// ھӽڵڻе
	uint64 neighborTs[UWB_LIST_SIZE] = {0};// ھͨŶӦʱ
	uint8 neighborCount = 0;// Чھӽڵ
	uint8 payloadLength = INFO_PAYLOAD_HEADER_SIZE;// ЧݳȣʼΪͷȣ
	uint8 totalChunks = 1;// ϢܷƬھӹʱְ
	uint8 chunkIndex = 0;// ǰƬ
	uint8 packetSeq = inst->meshReportSequence++;// ݰкţȥأ
	uint8 flags = 0;// ־λλЧCSRЧ
	uint64 currentTxTs1 = currentTxTs;// ηʱڿϢ
	uint64 previousTxTs1 = previousTxTs;// һηʱ
	uint16 masterId = mesh_select_master_short_addr(inst);// ȡǰڵ̵ַ
	// ȡ桿ڵԼĻ棨0̶Ϊڵ
	mesh_node_cache_t *selfCache = &inst->meshNodeCache[0];
	uint8 includeSelfResult = FALSE;// ǷҪЯĶλ/ʱӽ// ݳ
	uint8 selfResultSize = 0;// ݳ
	uint8 maxEntriesPerFrame = 0;// ÿ֡ϢЯھĿ
	uint8 startEntry = 0;// ηʹӵڼھӿʼ
	uint8 entriesThisChunk = 0;// ηƬھ
// =========================================
	// 1жǷЧǷҪЯ
	// =========================================
	if(selfCache->valid == TRUE && selfCache->nodeShortAddr == inst->uwbShortAdd)
	{
		includeSelfResult = TRUE;// Ҫϱ
		selfResultSize = INFO_SELF_RESULT_SIZE;// ռֽ
		// ݻ״̬ñ־λ
		if(selfCache->csrValid)
		{
			flags |= REPORT_FLAG_CSR_VALID;// CSRʱƫЧ
		}
		if(selfCache->positionValid)
		{
			flags |= REPORT_FLAG_POSITION_VALID;// λϢЧ
		}
	}
// =========================================
	// 2һ֡װٸھĿְƣ
	// =========================================
	if(REPORT_MAX_PAYLOAD_BYTES > (INFO_PAYLOAD_HEADER_SIZE + selfResultSize))
	{
		maxEntriesPerFrame = (REPORT_MAX_PAYLOAD_BYTES - INFO_PAYLOAD_HEADER_SIZE - selfResultSize) / INFO_NEIGHBOR_ENTRY_SIZE;
	}
	if(maxEntriesPerFrame == 0)
	{
		maxEntriesPerFrame = 1;// Я1
	}
// =========================================
	// 3ռЧھӣ
	// =========================================
	mesh_collect_sorted_neighbors(inst, neighborIndex, neighborTs, &neighborCount);
// =========================================
	// 4ھӷְ߼αѭͣⵥ֡
	// =========================================
	if(neighborCount > 0)
	{
		// αԽ
		if(inst->meshInfoNeighborCursor >= neighborCount)
		{
			inst->meshInfoNeighborCursor = 0;
		}

		startEntry = inst->meshInfoNeighborCursor;// ʼھ
		totalChunks = (neighborCount + maxEntriesPerFrame - 1) / maxEntriesPerFrame;// ܷƬ
		chunkIndex = startEntry / maxEntriesPerFrame;// ǰƬ
		entriesThisChunk = neighborCount - startEntry;// ʣھ
		// ÿ֡
		if(entriesThisChunk > maxEntriesPerFrame)
		{
			entriesThisChunk = maxEntriesPerFrame;
		}
	}
// =========================================
	// 5дϢͷ͡ԴIDĿIDƬȣ
	// =========================================
	mesh_write_transport_header(&inst->report_msg.messageData[0],
						 RTLS_REPORT_TYPE_INFO_UPLOAD,// ϢͣϢϱ
						 inst->uwbShortAdd,// ԭʼͷID
						 masterId,// ĿIDڵ㣩
						 inst->uwbShortAdd,// ID
						 packetSeq,// 
						 REPORT_DEFAULT_HOPS,// ת
						 totalChunks,// ܷƬ
						 chunkIndex,// ǰƬ
						 flags,// Ч־
						 payloadLength);// Чݳ
// =========================================
	// 6дʱڵCSRʱͬ
	// =========================================
	memcpy(&inst->report_msg.messageData[REPORT_PAYLOAD_START + INFO_PAYLOAD_CUR_TX_TS], &currentTxTs1, 6);
	memcpy(&inst->report_msg.messageData[REPORT_PAYLOAD_START + INFO_PAYLOAD_PREV_TX_TS], &previousTxTs1, 6);
	// д뱾ϱھ
	inst->report_msg.messageData[REPORT_PAYLOAD_START + INFO_PAYLOAD_NUM_NEIGHBORS] = entriesThisChunk;
// =========================================
	// 7ѭд롾ھID + ͨʱ
	// =========================================
	int payloadIndex = REPORT_PAYLOAD_START + INFO_PAYLOAD_NEIGHBOR_ENTRY_START;
	for(int i = 0; i < entriesThisChunk; i++)
	{
		// ȡھID
		uint16 neighborId = mesh_get_short_addr_by_index(inst, neighborIndex[startEntry + i]);
		// дھID
		memcpy(&inst->report_msg.messageData[payloadIndex], &neighborId, sizeof(uint16));
		payloadIndex += INFO_NEIGHBOR_ID_SIZE;
		// дӦͨʱ
		memcpy(&inst->report_msg.messageData[payloadIndex], &neighborTs[startEntry + i], 6);
		payloadIndex += INFO_NEIGHBOR_TS_SIZE;
	}
// ۼھĿ
	payloadLength += (uint8)(entriesThisChunk * INFO_NEIGHBOR_ENTRY_SIZE);
	// =========================================
	// 8Ҫ׷CSR + λã
	// =========================================
	if(includeSelfResult == TRUE)
	{
		// д
		inst->report_msg.messageData[REPORT_PAYLOAD_START + payloadLength + RESULT_PAYLOAD_UPDATE_PERIOD] = inst->meshResultPeriodFrames;
		// дCSRʱƫƣQ16
		memcpy(&inst->report_msg.messageData[REPORT_PAYLOAD_START + payloadLength + RESULT_PAYLOAD_CSR_Q16], &selfCache->csrQ16, sizeof(int32));
		// д X/Y/Z
		memcpy(&inst->report_msg.messageData[REPORT_PAYLOAD_START + payloadLength + RESULT_PAYLOAD_X_MM], &selfCache->relPosMm[0], sizeof(int32));
		memcpy(&inst->report_msg.messageData[REPORT_PAYLOAD_START + payloadLength + RESULT_PAYLOAD_Y_MM], &selfCache->relPosMm[1], sizeof(int32));
		memcpy(&inst->report_msg.messageData[REPORT_PAYLOAD_START + payloadLength + RESULT_PAYLOAD_Z_MM], &selfCache->relPosMm[2], sizeof(int32));
		// ۼ
		payloadLength += selfResultSize;
	}
	// =========================================
	// 9ϢͷĳȺͱ־
	// =========================================
	inst->report_msg.messageData[REPORT_PAYLOAD_LENGTH] = payloadLength;
	inst->report_msg.messageData[REPORT_FLAGS] = flags;
// =========================================
	// 10淢ʱһηʹã
	// =========================================
	inst->infoMsgTxTimestampPrevious = inst->infoMsgTxTimestampCurrent;
	inst->infoMsgTxTimestampCurrent = currentTxTs;
// =========================================
	// 11ھӷα꣨ѭְ
	// =========================================
	if(neighborCount == 0 || (startEntry + entriesThisChunk) >= neighborCount)
	{
		inst->meshInfoNeighborCursor = 0; // ϣα
	}
	else
	{
		inst->meshInfoNeighborCursor = startEntry + entriesThisChunk; // һ
	}
// UWB֡ܳ
	return REPORT_TRANSPORT_HEADER_SIZE + payloadLength + FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC;
}
/**********************************************************************
 * ܣڵ㡾λ㲥Ϣ
 *           õꡢCSRھϢϢ㲥дӽڵ/ǩ
 * ʱڵ㶨ʱͶλ
 * 㣺 mesh_recompute_relative_positions(inst)  **ĺ**
 **********************************************************************/
static int mesh_build_result_message(instance_data_t *inst, uint64 currentTxTs, uint64 previousTxTs)
{
	uint8 neighborIndex[UWB_LIST_SIZE] = {0};// ھӽڵ
	
	uint64 neighborTs[UWB_LIST_SIZE] = {0};// ھʱ
	uint8 neighborCount = 0;// Чھ
	uint8 packetSeq = inst->meshReportSequence++;// ݰкţ
	uint8 flags = REPORT_FLAG_MASTER_FRAME;// ֡־ڵ㷢͵֡
	uint8 payloadLength = RESULT_PAYLOAD_MIN_SIZE;// ЧݳȣĬС
	uint8 totalChunks = 1;// ܷƬ
	uint8 chunkIndex = 0;// ǰƬ
	uint8 maxEntriesPerFrame = 0;// ÿ֡ھĿ
	uint8 startEntry = 0;// ʼĿ
	uint8 entriesThisChunk = 0;// Ƭھ
	int selectedIndex = -1;// ǰѡҪ㲥Ľڵ


	
// ѯѡһҪ㲥λϢĽڵ
	for(int attempt = 0; attempt < UWB_LIST_SIZE; attempt++)
	{
		// 1. 㵱ǰѡڵ
    // ϴμ¼αλÿʼ +1 
    // % UWB_LIST_SIZE ֤ѭԽ
		uint8 candidate = (uint8)((inst->meshResultCursor + attempt) % UWB_LIST_SIZE);
		// 2. Ч
    // candidate == 0           0ڵԼ㲥
    // candidate >= uwbListLen  ǰʵ豸
		if(candidate == 0 || candidate >= inst->uwbListLen)
		{
			continue;
		}
		// ڵ㻺Ч  ѡиýڵ
		// 3. жѡڵǷЧݡߡɹ㲥
		if(inst->meshNodeCache[candidate].valid)
		{
			// 4. ҵЧڵ㣡¼
			selectedIndex = candidate;
			// 5. α꣺´δӡһڵ㡿ʼңʵѯ
			inst->meshResultCursor = (uint8)((candidate + 1) % UWB_LIST_SIZE);
			break;
		}
	}
// δѡκνڵ  ĬʹڵԼ0
	if(selectedIndex < 0)
	{
		selectedIndex = 0;
		inst->meshNodeCache[0].valid = TRUE;
		inst->meshNodeCache[0].nodeShortAddr = inst->uwbShortAdd;
		inst->meshNodeCache[0].csrValid = FALSE;
		inst->meshNodeCache[0].positionValid = FALSE;
		inst->meshNodeCache[0].relPosMm[0] = 0;
		inst->meshNodeCache[0].relPosMm[1] = 0;
		inst->meshNodeCache[0].relPosMm[2] = 0;
	}
// ȡѡнڵĻ
	mesh_node_cache_t *cache = &inst->meshNodeCache[selectedIndex];
	inst->meshNodeCache[0].currentTxTs = currentTxTs;
		inst->meshNodeCache[0].previousTxTs = previousTxTs;
	// ݻ״̬ñ־λCSRЧ / λЧ
	if(cache->csrValid)
	{
		flags |= REPORT_FLAG_CSR_VALID;
	}
	if(cache->positionValid)
	{
		flags |= REPORT_FLAG_POSITION_VALID;
	}
// һ֡װٸھϢ
	if(REPORT_MAX_PAYLOAD_BYTES > (RESULT_PAYLOAD_HEADER_SIZE + RESULT_BODY_SIZE))
	{
		maxEntriesPerFrame = (REPORT_MAX_PAYLOAD_BYTES - RESULT_PAYLOAD_HEADER_SIZE - RESULT_BODY_SIZE) / RESULT_NEIGHBOR_ENTRY_SIZE;
	}
	if(maxEntriesPerFrame == 0)
	{
		maxEntriesPerFrame = 1;
	}
// ռھӽڵϢ
	mesh_collect_sorted_neighbors(inst, neighborIndex, neighborTs, &neighborCount);
	if(neighborCount > 0)
	{
		// αԽλ
		if(inst->meshInfoNeighborCursor >= neighborCount)
		{
			inst->meshInfoNeighborCursor = 0;
		}
// 1. η͵ġʼλá
		startEntry = inst->meshInfoNeighborCursor;
		// 2. 㡾ܷƬھһҪּ֡
		totalChunks = (neighborCount + maxEntriesPerFrame - 1) / maxEntriesPerFrame;
		// 3. 㵱ǰǡڼƬ
		chunkIndex = startEntry / maxEntriesPerFrame;
		// 4. 㡾һ֡Ҫٸھӡ
		entriesThisChunk = neighborCount - startEntry;
		// ÿƬĿ
		if(entriesThisChunk > maxEntriesPerFrame)
		{
			entriesThisChunk = maxEntriesPerFrame;
		}
	}
// Чݳ = ͷ + ھ + 
	payloadLength = (uint8)(RESULT_PAYLOAD_HEADER_SIZE + (entriesThisChunk * RESULT_NEIGHBOR_ENTRY_SIZE) + RESULT_BODY_SIZE);
// =========================================
	// дϢͷ͡ԴַĿַ־ȵȣ
	// =========================================
	mesh_write_transport_header(&inst->report_msg.messageData[0],
						 RTLS_REPORT_TYPE_RESULT,
						 inst->uwbShortAdd,
						 BROADCAST_ADDRESS,
						 cache->nodeShortAddr,
						 packetSeq,
						 REPORT_DEFAULT_HOPS,
						 totalChunks,
						 chunkIndex,
						 flags,
						 payloadLength);
// д뱾/ϴηʱ6ֽڣ
	memcpy(&inst->report_msg.messageData[REPORT_PAYLOAD_START + RESULT_PAYLOAD_CUR_TX_TS], &currentTxTs, 6);
	memcpy(&inst->report_msg.messageData[REPORT_PAYLOAD_START + RESULT_PAYLOAD_PREV_TX_TS], &previousTxTs, 6);
	// дھ
	inst->report_msg.messageData[REPORT_PAYLOAD_START + RESULT_PAYLOAD_NUM_NEIGHBORS] = entriesThisChunk;
// =========================================
	// ھӽڵݣID + ʱ
	// =========================================
	int payloadIndex = REPORT_PAYLOAD_START + RESULT_PAYLOAD_NEIGHBOR_ENTRY_START;
	for(int i = 0; i < entriesThisChunk; i++)
	{
		uint16 neighborId = mesh_get_short_addr_by_index(inst, neighborIndex[startEntry + i]);
		memcpy(&inst->report_msg.messageData[payloadIndex], &neighborId, sizeof(uint16));
		payloadIndex += RESULT_NEIGHBOR_ID_SIZE;
		memcpy(&inst->report_msg.messageData[payloadIndex], &neighborTs[startEntry + i], 6);
		payloadIndex += RESULT_NEIGHBOR_TS_SIZE;
	}
// =========================================
	// 䡾λݡ
	// ѻõģCSR + X/Y/Z  дϢ
	// =========================================
	payloadIndex = REPORT_PAYLOAD_START + RESULT_BODY_OFFSET(entriesThisChunk);
	inst->report_msg.messageData[payloadIndex + 0] = inst->meshResultPeriodFrames;
	memcpy(&inst->report_msg.messageData[payloadIndex + 1], &cache->csrQ16, sizeof(int32));// CSR
	memcpy(&inst->report_msg.messageData[payloadIndex + 5], &cache->relPosMm[0], sizeof(int32));// X
	memcpy(&inst->report_msg.messageData[payloadIndex + 9], &cache->relPosMm[1], sizeof(int32));// Y
	memcpy(&inst->report_msg.messageData[payloadIndex + 13], &cache->relPosMm[2], sizeof(int32));// Z
// Ϣܳȡ־λֵ
	inst->report_msg.messageData[REPORT_PAYLOAD_LENGTH] = payloadLength;
	inst->report_msg.messageData[REPORT_FLAGS] = flags;
// ·ʱ
	inst->infoMsgTxTimestampPrevious = inst->infoMsgTxTimestampCurrent;
	inst->infoMsgTxTimestampCurrent = currentTxTs;
// ھα
	if(neighborCount == 0 || (startEntry + entriesThisChunk) >= neighborCount)
	{
		inst->meshInfoNeighborCursor = 0;
	}
	else
	{
		inst->meshInfoNeighborCursor = startEntry + entriesThisChunk;
	}
// ֡
	return REPORT_TRANSPORT_HEADER_SIZE + payloadLength + FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC;
}

static int mesh_build_relay_message(instance_data_t *inst)
{
	int reportLength = 0;

	if(inst->meshPendingRelayValid == FALSE || inst->meshPendingRelayLength == 0)
	{
		return 0;
	}

	reportLength = inst->meshPendingRelayLength + FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC;
	memcpy(&inst->report_msg.messageData[0], &inst->meshPendingRelayPayload[0], inst->meshPendingRelayLength);
	if(inst->report_msg.messageData[REPORT_HOPS_LEFT] > 0)
	{
		inst->report_msg.messageData[REPORT_HOPS_LEFT] -= 1;
	}

	if(inst->meshPendingRelayRepeats > 1)
	{
		inst->meshPendingRelayRepeats--;
	}
	else
	{
		inst->meshPendingRelayValid = FALSE;
		inst->meshPendingRelayLength = 0;
		inst->meshPendingRelayRepeats = 0;
	}

	return reportLength;
}
/**********************************************************************
 * ܣ½ڵĶλ
 *           ãӽڵ/ǩġCSRֵ + (X,Y,Z)
 *           ڵӽڵԼλ
 * ˵
 *      inst        豸ʵָ
 *      subjectId   λĿڵIDǩ/ӽڵ㣩
 *      flags       Ϣ־λCSR/ǷЧ
 *      payload     λ
 *      payloadLength ݳ
 **********************************************************************/
static __attribute__((unused)) void mesh_update_result_cache(instance_data_t *inst, uint16 subjectId, uint8 flags, const uint8 *payload, uint8 payloadLength)
{
	// ĿڵIDڻе
	int cacheIndex = mesh_find_index_by_short_addr(inst, subjectId);
	// λpayloadеƫ
	int resultBodyOffset = 0;
	// ھӽڵ
	uint8 numNeighbors = 0;
// Чֱ˳
	if(cacheIndex < 0 || cacheIndex >= UWB_LIST_SIZE)
	{
		return;
	}
// ===================== ݽṹҵλƫ =====================
	// ݳ㡾ھϢĽʽ
	if(payloadLength >= RESULT_PAYLOAD_MIN_SIZE)
	{
		// ȡھӽڵ
		numNeighbors = payload[RESULT_PAYLOAD_NUM_NEIGHBORS];
		// +CSRеƫλ
		resultBodyOffset = (int)RESULT_BODY_OFFSET(numNeighbors);
		// ݳȲ㣬˳
		if(payloadLength < (uint8)(resultBodyOffset + RESULT_BODY_SIZE))
		{
			return;
		}
	}
	// ǡھӡľʽֱӴ0ƫƿʼ
	else if(payloadLength >= RESULT_BODY_SIZE)
	{
		resultBodyOffset = 0;
	}
	// ݳȲ˳
	else
	{
		return;
	}
// ===================== Ѷλдڵ㻺 =====================
	// ҵӦڵĻ
	mesh_node_cache_t *cache = &inst->meshNodeCache[cacheIndex];
	// ǻЧ
	cache->valid = TRUE;
	// ĿڵID
	cache->nodeShortAddr = subjectId;
	// flagsбǣCSRǷЧǷЧ
	cache->csrValid = (flags & REPORT_FLAG_CSR_VALID) ? TRUE : FALSE;
	cache->positionValid = (flags & REPORT_FLAG_POSITION_VALID) ? TRUE : FALSE;
	// нCSRʱƫֵ
	memcpy(&cache->csrQ16, &payload[resultBodyOffset + 1], sizeof(int32));
	// н X, Y, Zλ mm
	memcpy(&cache->relPosMm[0], &payload[resultBodyOffset + 5], sizeof(int32));
	memcpy(&cache->relPosMm[1], &payload[resultBodyOffset + 9], sizeof(int32));
	memcpy(&cache->relPosMm[2], &payload[resultBodyOffset + 13], sizeof(int32));
	// ˢʱ
	cache->lastUpdateMs = portGetTickCnt();
}
/**********************************************************************
 * ܣڵ(Master)´ӽڵ/ǩĻϢ
 *           豸ϢʱھϢCSRʱƫƼ
 * ˵
 *      inst        豸ʵָ
 *      originId    ϢͷIDӽڵ/ǩ
 *      payload     ϢЧ
 *      payloadLength Чݳ
 *      masterRxTs  ڵոϢʱ
 **********************************************************************/
static void mesh_update_master_cache(instance_data_t *inst, uint16 originId, const uint8 *payload, uint8 payloadLength, uint64 masterRxTs)
{
	// 豸̵ַҸýڵڻе
	int cacheIndex = mesh_find_index_by_short_addr(inst, originId);
	// ϷУ飺Ч  ݳȲͷСֱ˳
	if(cacheIndex < 0 || cacheIndex >= UWB_LIST_SIZE || payloadLength < INFO_PAYLOAD_HEADER_SIZE)
	{
		return;
	}
// ȡӦڵĻṹָ
	mesh_node_cache_t *cache = &inst->meshNodeCache[cacheIndex];
	mesh_node_cache_t *cache0 = &inst->meshNodeCache[0];
	// ǻЧ¼ڵ̵ַ
	cache->valid = TRUE;
	cache->nodeShortAddr = originId;
	// 桾һΡڵʱڼʱ
	cache->previousMasterRxTs = cache->masterRxTs;
	cache0->previousneighborRxTs[cacheIndex] = cache->previousMasterRxTs;
	// ھӽڵЧ־ʱ׼µھϢ
	memset(&cache->neighborValid[0], 0, sizeof(cache->neighborValid));
	memset(&cache->neighborRxTs[0], 0, sizeof(cache->neighborRxTs));
	// 桾Ρڵʱֻ42bitЧλ
	cache->masterRxTs = masterRxTs & MASK_42BIT;
	cache0->neighborRxTs[cacheIndex] = cache->masterRxTs;
	// Ϣпӽڵ㱾ηʱ6ֽڣ
	memcpy(&cache->currentTxTs, &payload[INFO_PAYLOAD_CUR_TX_TS], 6);
	// Ϣпӽڵһηʱ6ֽڣ
	memcpy(&cache->previousTxTs, &payload[INFO_PAYLOAD_PREV_TX_TS], 6);
	// »ˢʱ䣨ϵͳtick
	cache->lastUpdateMs = portGetTickCnt();
// Ϣнýڵھ豸
	uint8 numNeighbors = payload[INFO_PAYLOAD_NUM_NEIGHBORS];
	 // ھϢЧеʼƫ
	int payloadIndex = INFO_PAYLOAD_NEIGHBOR_ENTRY_START;
	// ѭھϢ
	for(int i = 0; i < numNeighbors && (payloadIndex + INFO_NEIGHBOR_ENTRY_SIZE) <= payloadLength; i++)
	{
		uint16 neighborId = 0;
		uint64 neighborTs = 0;
		// ھӽڵID
		memcpy(&neighborId, &payload[payloadIndex], sizeof(uint16));
		payloadIndex += INFO_NEIGHBOR_ID_SIZE;
				// ھͨʱ
		memcpy(&neighborTs, &payload[payloadIndex], 6);
		payloadIndex += INFO_NEIGHBOR_TS_SIZE;
// ھڻеЧ¼ھ״̬ʱ
		int neighborIndex = mesh_find_index_by_short_addr(inst, neighborId);
		if(neighborIndex >= 0 && neighborIndex < UWB_LIST_SIZE)
		{
			cache->neighborValid[neighborIndex] = TRUE;
			cache->neighborRxTs[neighborIndex] = neighborTs & MASK_42BIT;
		}
	}
// ===================== ģCSRʱƫƼ =====================
	// ȸλCSRϢ
	cache->csrValid = FALSE;
	cache->csrQ16 = 0;
	// һκͱεʱܼʱƫ
	if(cache->previousMasterRxTs != 0 && cache->previousTxTs != 0 && cache->currentTxTs != 0)
	{
		// 㣺ӽڵηϢʱԶʱ
		uint64 remoteDt = get_dt64(cache->previousTxTs, cache->currentTxTs);
		// 㣺ڵνϢʱʱ
		uint64 masterDt = get_dt64(cache->previousMasterRxTs, cache->masterRxTs);
		// ʱЧCSRʱƯ
		if(remoteDt > 0 && masterDt > 0)
		{
			// 16λתΪQ16ʱƫƱ
			cache->csrQ16 = (int32)((remoteDt << 16) / masterDt);
			// CSRЧ
			cache->csrValid = TRUE;
		}
	}
}

static __attribute__((unused)) uint8 mesh_should_accept_packet(instance_data_t *inst, uint8 reportType, uint16 originId, uint8 packetSeq)
{
	int originIndex = mesh_find_index_by_short_addr(inst, originId);
	if(originIndex < 0 || originIndex >= UWB_LIST_SIZE)
	{
		return FALSE;
	}

	if(reportType == RTLS_REPORT_TYPE_INFO_UPLOAD)
	{
		if(inst->meshLastSeenInfoValid[originIndex] && inst->meshLastSeenInfoSeq[originIndex] == packetSeq)
		{
			return FALSE;
		}
		inst->meshLastSeenInfoValid[originIndex] = TRUE;
		inst->meshLastSeenInfoSeq[originIndex] = packetSeq;
	}
	else if(reportType == RTLS_REPORT_TYPE_RESULT)
	{
		if(inst->meshLastSeenResultValid[originIndex] && inst->meshLastSeenResultSeq[originIndex] == packetSeq)
		{
			return FALSE;
		}
		inst->meshLastSeenResultValid[originIndex] = TRUE;
		inst->meshLastSeenResultSeq[originIndex] = packetSeq;
	}

	return TRUE;
}

static __attribute__((unused)) void mesh_schedule_relay(instance_data_t *inst, const uint8 *messageData, uint8 payloadLength)
{
	if(payloadLength > MAX_EXTENDED_USER_PAYLOAD_STRING_SS)
	{
		payloadLength = MAX_EXTENDED_USER_PAYLOAD_STRING_SS;
	}

	if(inst->meshPendingRelayValid == TRUE && inst->meshPendingRelayLength >= payloadLength)
	{
		if(memcmp(&inst->meshPendingRelayPayload[0], messageData, payloadLength) == 0)
		{
			inst->meshPendingRelayRepeats = 2;
			return;
		}
	}

	memcpy(&inst->meshPendingRelayPayload[0], messageData, payloadLength);
	inst->meshPendingRelayLength = payloadLength;
	inst->meshPendingRelayValid = TRUE;
	inst->meshPendingRelayRepeats = 2;
	memcpy(&inst->meshPendingRelayOrigin, &messageData[REPORT_ORIGIN_ID], sizeof(uint16));
	inst->meshPendingRelaySeq = messageData[REPORT_PACKET_SEQ];
	inst->meshPendingRelayType = messageData[REPORT_MSG_TYPE];
}
//Ƕ
static __attribute__((unused)) int build_info_report_message(instance_data_t *inst, uint64 currentTxTs, uint64 previousTxTs)
{
	// 1. ͳƣ Mesh ֡ͼ
    // ܼ⣬豸һ˶ٸ Mesh صҵ
	inst->meshFrameCounter++;
// 2. ǰĲͨڻʽӡڿ߲鿴
  //mesh_debug_report_results(inst);

// 3. ȼж 1ǷСתھϢ
    //  inst->meshPendingRelayValid Ϊ TRUE˵豸ոյƽڵ㷢Ϣ
    // ұ豸ΪмRelayҪϢվ
//	if(inst->meshPendingRelayValid == TRUE)
//	{
//		// мת֡ѱ˵´ͳȥ
//		return mesh_build_relay_message(inst);
//	}
// 4. ȼж 2ԼǷǡվ (Master/Gateway)
    // վͨ PC ıͨǻܺս
	if(mesh_is_master(inst) == TRUE)
	{
		// ս֡ͨȫнڵܾ롣
		return mesh_build_result_message(inst, currentTxTs, previousTxTs);
	}
// 5. ĬΪͨĴվ (Slave Anchor)
    // ȲҪת˵ģԼҲվǾϱԼݡ
    // Ϣϱ֡վԼھӾϢ
				
		return mesh_build_info_upload_message(inst, currentTxTs, previousTxTs);
}
// -------------------------------------------------------------------------------------------------------------------
//
// function to construct the message/frame header bytes
//
// -------------------------------------------------------------------------------------------------------------------
//
// -------------------------------------------------------------------------------------------------------------------
// Functions
// -------------------------------------------------------------------------------------------------------------------

// -------------------------------------------------------------------------------------------------------------------
//
// function to construct the message/frame header bytes
//
// -------------------------------------------------------------------------------------------------------------------
//

//  UWB ֡֡ͷ֡֡ͬ֡INF֡BLINK֡
void instanceconfigframeheader(instance_data_t *inst)
{
	// ===================== 1. ͨ֡ =====================
	//  PAN IDСģʽֽǰֽں
	inst->msg.panID[0] = (inst->panID) & 0xff;
	inst->msg.panID[1] = inst->panID >> 8;

	//set frame type (0-2), SEC (3), Pending (4), ACK (5), PanIDcomp(6)
	// frameCtrl[0]֡ + λ
	// 0x1 = ֡
	// 0x40 = PAN ID ѹһ£
	inst->msg.frameCtrl[0] = 0x1 /*frame type 0x1 == data*/ | 0x40 /*PID comp*/;
	// frameCtrl[1]ַģʽ
#if (USING_64BIT_ADDR==1)
		//source/dest addressing modes and frame version
	inst->msg.frameCtrl[1] = 0xC /*dest extended address (64bits)*/ | 0xC0 /*src extended address (64bits)*/;
#else
	// Ŀַ16λ(̵ַ) + Դַ16λ(̵ַ)
	inst->msg.frameCtrl[1] = 0x8 /*dest short address (16bits)*/ | 0x80 /*src short address (16bits)*/;
#endif


	//configure RNG_INIT message
	// ===================== 2. ʼ֡ RNG_INIT =====================
	// ֡ͣ֡0x41
    inst->rng_initmsg.frameCtrl[0] = 0x41;

#if (USING_64BIT_ADDR == 1)
    inst->rng_initmsg.frameCtrl[1] = 0xCC;
#else
    inst->rng_initmsg.frameCtrl[1] = 0x8C;
#endif
    inst->rng_initmsg.panID[0] = (inst->panID) & 0xff;
    inst->rng_initmsg.panID[1] = inst->panID >> 8;


	//configure INF message
	// ===================== 3. INF Ϣ֡ =====================
	inst->inf_msg.panID[0] = (inst->panID) & 0xff;
	inst->inf_msg.panID[1] = inst->panID >> 8;

	//set frame type (0-2), SEC (3), Pending (4), ACK (5), PanIDcomp(6)
	// ֡ + PAN ID ѹ
	inst->inf_msg.frameCtrl[0] = 0x1 /*frame type 0x1 == data*/ | 0x40 /*PID comp*/;
#if (USING_64BIT_ADDR==1)
// Ŀ꣺̵ַ  Դ64λַ
	//source/dest addressing modes and frame version
	inst->inf_msg.frameCtrl[1] = 0x8 /*dest short address (16bits)*/ | 0xC0 /*src extended address (64bits)*/;
#else
	inst->inf_msg.frameCtrl[1] = 0x8 /*dest short address (16bits)*/ | 0x80 /*src short address (16bits)*/;
#endif


	//configure RNG_REPORT
	// ===================== 4.  REPORT ֡ =====================
	inst->report_msg.panID[0] = (inst->panID) & 0xff;
	inst->report_msg.panID[1] = inst->panID >> 8;

	//set frame type (0-2), SEC (3), Pending (4), ACK (5), PanIDcomp(6)
	inst->report_msg.frameCtrl[0] = 0x1 /*frame type 0x1 == data*/ | 0x40 /*PID comp*/;
#if (USING_64BIT_ADDR==1)
	//source/dest addressing modes and frame version
	inst->report_msg.frameCtrl[1] = 0x8 /*dest short address (16bits)*/ | 0xC0 /*src extended address (64bits)*/;
#else
	inst->report_msg.frameCtrl[1] = 0x8 /*dest short address (16bits)*/ | 0x80 /*src short address (16bits)*/;
#endif


	//configure SYNC message
	// ===================== 5. SYNC ͬ֡ =====================
	inst->sync_msg.panID[0] = (inst->panID) & 0xff;
	inst->sync_msg.panID[1] = inst->panID >> 8;

	//set frame type (0-2), SEC (3), Pending (4), ACK (5), PanIDcomp(6)
	inst->sync_msg.frameCtrl[0] = 0x1 /*frame type 0x1 == data*/ | 0x40 /*PID comp*/;
#if (USING_64BIT_ADDR==1)
	//source/dest addressing modes and frame version
	inst->sync_msg.frameCtrl[1] = 0x8 /*dest short address (16bits)*/ | 0xC0 /*src extended address (64bits)*/;
#else
	inst->sync_msg.frameCtrl[1] = 0x8 /*dest short address (16bits)*/ | 0x80 /*src short address (16bits)*/;
#endif


	//configure BLINK
	//blink frames with IEEE EUI-64 tag ID
	// ===================== 6. BLINK ֡豸֡ =====================
	// BLINK ̶֡֡ͷ0xC5
	inst->blinkmsg.frameCtrl = 0xC5 ;

}


// -------------------------------------------------------------------------------------------------------------------
//
// function to construct the fixed portions of the message definitions
//
// -------------------------------------------------------------------------------------------------------------------
//
void instanceconfigmessages(instance_data_t *inst)
{
	//initialize ranging message
	//set source address into the message structure
	memcpy(&inst->msg.sourceAddr[0], &inst->eui64[0], inst->addrByteSize);

	//initialize RNG_INIT message
	//set source address into the message structure
	memcpy(&inst->rng_initmsg.sourceAddr[0], &inst->eui64[0], inst->addrByteSize);
	inst->rng_initmsg.messageData[FCODE] = RTLS_DEMO_MSG_RNG_INIT;

	//configure INF message
	uint16 broadcast_address = BROADCAST_ADDRESS;
	memcpy(&inst->inf_msg.sourceAddr[0], &inst->eui64[0], inst->addrByteSize);
	memcpy(&inst->inf_msg.destAddr[0], &broadcast_address, 2);
	inst->inf_msg.messageData[FCODE] = 0; //message function code (specifies if message is a poll, response or other...)

	//configure RNG_REPORT
	memcpy(&inst->report_msg.sourceAddr[0], &inst->eui64[0], inst->addrByteSize);
	memcpy(&inst->report_msg.destAddr[0], &broadcast_address, 2);
	inst->report_msg.messageData[FCODE] = RTLS_DEMO_MSG_RNG_REPORT; //message function code (specifies if message is a poll, response or other...)

	//configure SYNC message
	memcpy(&inst->sync_msg.sourceAddr[0], &inst->eui64[0], inst->addrByteSize);
	memcpy(&inst->sync_msg.destAddr[0], &broadcast_address, 2);
	inst->sync_msg.messageData[FCODE] = RTLS_DEMO_MSG_SYNC; //message function code (specifies if message is a poll, response or other...)

	//configure BLINK message
	memcpy(&inst->blinkmsg.tagID[0], &inst->eui64[0], ADDR_BYTE_SIZE_L);
}



// -------------------------------------------------------------------------------------------------------------------
//
// Turn on the receiver with/without delay
//
// -------------------------------------------------------------------------------------------------------------------
//
void instancerxon(instance_data_t *inst, int delayed, uint64 delayedReceiveTime)
{
    if (delayed)
    {
        uint32 dtime;
        dtime =  (uint32) (delayedReceiveTime>>8);
        dwt_setdelayedtrxtime(dtime) ;
    }

    int dwt_rx_enable_return = dwt_rxenable(delayed);
    inst->lateRX -= dwt_rx_enable_return;

} // end instancerxon()

/**
 * @brief  ִ UWB ݰͷװ
 * @param  length: Ҫ͵ݳ (PSDU Length)
 * @param  txmode: ģʽ (ӳٷ͡ͺյȱ־λ)
 * @param  dtime:  ӳٷ͵Ŀʱ (UWB 豸ʱ䵥λ32λЧ)
 * @return int:    0 ʾɹ; 1 ʾʧ (ͨΪ "ӳʱѹ")
 */
int instancesendpacket(uint16 length, uint8 txmode, uint32 dtime)
{
    int result = 0;
// 1.  TX ֡ƼĴ (TX Frame Control)
    // 1: length - ñη͵ PSDU ֡
    // 2: 0 - TX ƫ (ͨ 0 ʼ)
    // 3: 1 - λ Ranging Bit (־λ)оƬԶ¼ȷķ/ʱ
    dwt_writetxfctrl(length, 0, 1);
	// 2. ǷҪ "ӳٷ" ģʽ
    //  txmode а DWT_START_TX_DELAYED ־λ
    if(txmode & DWT_START_TX_DELAYED)
    {
			// õĿ귢ʱдоƬDX_TIME Ĵ
        // ʵ TDMA ʱ϶ͬ˫˫ (SDS-TWR) Э龫׼ʱƵĹؼ
        dwt_setdelayedtrxtime(dtime) ;
    }

		 // 3. 
    // õײ dwt_starttxúõ txmode
    // ע⣺ӳٷģʽоƬȴڲϵͳʱ䵽 dtime ſʼ
    // begin delayed TX of frame
    if (dwt_starttx(txmode))  //  1˵ "delayed start was too late" (趨ķʱѾȥ)
    {
			// ʧܣӳʱùоƬ޷ڹȥʱ
        result = 1; //late/error
    }

    return result;  // ״̬ϲݴֵ״̬л
}


//debug helper function to print the testAppState
const char* get_inst_states_string(enum inst_states state)
{
    switch (state)
    {
        case TA_INIT : return "TA_INIT";
        case TA_TXPOLL_WAIT_SEND : return "TA_TXPOLL_WAIT_SEND";       
        case TA_TXFINAL_WAIT_SEND : return "TA_TXFINAL_WAIT_SEND";  
        case TA_TXRESPONSE_WAIT_SEND : return "TA_TXRESPONSE_WAIT_SEND";
        case TA_TX_WAIT_CONF : return "TA_TX_WAIT_CONF";
        case TA_RXE_WAIT : return "TA_RXE_WAIT";
        case TA_RX_WAIT_DATA : return "TA_RX_WAIT_DATA";
        case TA_TXINF_WAIT_SEND : return "TA_TXINF_WAIT_SEND";
        case TA_TXBLINK_WAIT_SEND : return "TA_TXBLINK_WAIT_SEND";
        case TA_TXRANGINGINIT_WAIT_SEND : return "TA_TXRANGINGINIT_WAIT_SEND";
        case TA_TX_SELECT : return "TA_TX_SELECT";
        case TA_TXREPORT_WAIT_SEND : return "TA_TXREPORT_WAIT_SEND";
        case TA_TXSUG_WAIT_SEND : return "TA_TXSUG_WAIT_SEND";
        default: return "NONE";
    }
}

//debug helper function to print the mode
const char* get_instanceModes_string(enum instanceModes mode)
{
    switch (mode)
    {
    	case DISCOVERY : return "DISCOVERY";
        case TAG : return "TAG";       
        case ANCHOR : return "ANCHOR";
        case NUM_MODES : return "NUM_MODES";
        default: return "NONE";
    }
}

//debug helper function to print the mode
const char* get_discovery_modes_string(enum discovery_modes mode)
{
    switch (mode)
    {
    	case WAIT_INF_REG : return "WAIT_INF_REG";
    	case COLLECT_INF_REG : return "COLLECT_INF_REG";
        case WAIT_INF_INIT : return "WAIT_INF_INIT";
        case WAIT_RNG_INIT : return "WAIT_RNG_INIT";
        case WAIT_SEND_SUG : return "WAIT_SEND_SUG";
        case SEND_SUG : return "SEND_SUG";
        case EXIT : return "EXIT";
        default: return "NONE";
    }
}


char* get_msg_fcode_string(int fcode)
{
    if (fcode == (int)RTLS_DEMO_MSG_RNG_INIT)
    {
        return "RTLS_DEMO_MSG_RNG_INIT";
    }
    else if(fcode == (int)RTLS_DEMO_MSG_TAG_POLL)
    {
        return "RTLS_DEMO_MSG_TAG_POLL";
    }
    else if(fcode == (int)RTLS_DEMO_MSG_ANCH_RESP)
    {
        return "RTLS_DEMO_MSG_ANCH_RESP";
    }
    else if(fcode == (int)RTLS_DEMO_MSG_TAG_FINAL)
    {
        return "RTLS_DEMO_MSG_TAG_FINAL";
    }
    else if(fcode == (int)RTLS_DEMO_MSG_INF_REG)
    {
    	return "RTLS_DEMO_MSG_INF_REG";
    }
    else if(fcode == (int)RTLS_DEMO_MSG_INF_INIT)
	{
		return "RTLS_DEMO_MSG_INF_INIT";
	}
    else if(fcode == (int)RTLS_DEMO_MSG_INF_SUG)
	{
		return "RTLS_DEMO_MSG_INF_SUG";
	}
	else if(fcode == (int)RTLS_DEMO_MSG_INF_UPDATE)
	{
		return "RTLS_DEMO_MSG_INF_UPDATE";
	}
    else if(fcode == (int)RTLS_DEMO_MSG_RNG_REPORT)
	{
		return "RTLS_DEMO_MSG_RNG_REPORT";
	}
    else if(fcode == (int)RTLS_DEMO_MSG_SYNC)
    {
    	return "RTLS_DEMO_MSG_SYNC";
    }
    else
    {
        return "NONE";
    }
}




// -------------------------------------------------------------------------------------------------------------------
//
// the main instance state machine (all the instance modes Tag or Anchor use the same state machine)
//
// -------------------------------------------------------------------------------------------------------------------
//
int testapprun(instance_data_t *inst, struct TDMAHandler *tdma_handler, int message)
{
//	send_statetousb(inst, tdma_handler);
	// Ĭϱʾǰ״̬ûꡱ
    int done = INST_NOT_DONE_YET;

	// ִ TDMA ʱ϶л
    // лɹ˵ǰʱ϶Ѿȴһ¼ټ
    if(tdma_handler->slot_transition(tdma_handler))
    {
			//һʱ϶
    	done = INST_DONE_WAIT_FOR_NEXT_EVENT;
			 // յǰϢ¼
		message = 0;
    }

		// 顰ģʽdiscovery modeǷʱ
    // ʱڲ߼Զ˳ģʽ
    tdma_handler->check_discovery_mode_expiration(tdma_handler);

// Ѿյ TX_DONE жϣǰ״̬ǡȴȷϡ
    // ˵ TX_DONE ¼ѾڻҪֱ
    if(message ==  DWT_SIG_TX_DONE && inst->testAppState != TA_TX_WAIT_CONF)
	{
		// пжȰ״̬ TA_TX_WAIT_CONF ˣ
        // ʱһ DWT_SIG_TX_DONE ¼
		instance_getevent(11);
		done = INST_DONE_WAIT_FOR_NEXT_EVENT;
	}

	 // ݵǰӦ״̬д
    switch (inst->testAppState)
    {
			 // =========================================================
        // ʼ״̬
        // =========================================================
        case TA_INIT :
        {
					
            switch (inst->mode)
            {
							 // -------------------------------------------------
                // ģʽʼַӡUWB б
                // -------------------------------------------------
                case DISCOVERY:
                {
									// ǿƹرշ׼
                    dwt_forcetrxoff();
									 // ʹ֡ˣ
                    // DATAACK֡
                    dwt_enableframefilter(DWT_FF_DATA_EN | DWT_FF_ACK_EN | DWT_FF_RSVD_EN);
					inst->frameFilteringEnabled = 1 ;
									//  PAN ID ͱ EUI-64
					dwt_setpanid(inst->panID);
					dwt_seteui(inst->eui64);
					// ñ 64 λ EUI ַΪ
					//seed random number generator with our 64-bit address
				    uint64 seed = 0;
				    seed |= (uint64) inst->eui64[0];
				    seed |= (uint64) inst->eui64[1] << 8;
				    seed |= (uint64) inst->eui64[2] << 16;
				    seed |= (uint64) inst->eui64[3] << 24;
				    seed |= (uint64) inst->eui64[4] << 32;
				    seed |= (uint64) inst->eui64[5] << 40;
				    seed |= (uint64) inst->eui64[6] << 48;
				    seed |= (uint64) inst->eui64[7] << 56;
				    srand(seed);


          //  EUI ĵ 16 λһ̵ַ
          // ע˵ʵҲԻɹϣ㷨
					inst->uwbShortAdd = inst->eui64[0] + (inst->eui64[1] << 8);//NOTE a hashing algorithm could be used instead

#if (USING_64BIT_ADDR==0)
// ϵͳʹ 16 λַ DW1000 Ķ̵ַ
					dwt_setaddress16(inst->uwbShortAdd);
					// ԼĶ̵ַ uwbList[0]
					memcpy(&inst->uwbList[0][0], &inst->uwbShortAdd, inst->addrByteSize);
#else
// ϵͳʹ 64 λַԼ EUI  uwbList[0]
					memcpy(&inst->uwbList[0][0], &inst->eui64, inst->addrByteSize);
#endif
          // ǰԼһڵ
					inst->uwbListLen = 1;
					//  0 ڵԼ
					tdma_handler->uwbListTDMAInfo[0].connectionType = UWB_LIST_SELF;

                    //  IEEE ֡ͷҵϢģ
                    instanceconfigframeheader(inst);
                    instanceconfigmessages(inst);

					 // лյȴ״̬
					tdma_handler->discoveryStartTime = portGetTickCnt();
					tdma_handler->last_blink_time = portGetTickCnt();
					inst->testAppState = TA_RXE_WAIT ;

          // RX ʱΪ 0ʾƳʱ
					dwt_setrxtimeout(0);
					// ǰȴ ACK
					inst->wait4ack = 0;
					// ӡϢ
					inst->canPrintUSB = TRUE;
					inst->canPrintLCD = TRUE;
                }
                break;
                default:
                break;
            }
            break;
        }// end case TA_INIT
				// =========================================================
        // Ͷѡ״̬
        // =========================================================
        case TA_TX_SELECT :
        {
          	//  TDMA ǰ״̬ѡӦ÷ʲô͵Ϣ
            //  TRUE ʾѾѡòԽһ״̬
        	if(tdma_handler->tx_select(tdma_handler) == TRUE)
        	{
						 // ǿƹرշ׼뷢
        		dwt_forcetrxoff();

        	}
        	else
        	{
						// ǰûпɷͶȴһ¼
        		done = INST_DONE_WAIT_FOR_NEXT_EVENT;
        	}

            break;
        }// end case TA_TX_SELECT
				 // =========================================================
        //  BLINK ֡
        // =========================================================
        case TA_TXBLINK_WAIT_SEND :
		{
			int psduLength = BLINK_FRAME_LEN_BYTES;

             // Blink ֡ʹ EUI-64 ǩ ID
			inst->blinkmsg.seqNum = inst->frameSN++;
			inst->wait4ack = 0;// BLINK  ACK

			//  BLINK ֡д뷢ͻ
        	dwt_writetxdata(psduLength, (uint8 *)  (&inst->blinkmsg), 0) ; // write the frame data
			 // 
			if(instancesendpacket(psduLength, DWT_START_TX_IMMEDIATE | inst->wait4ack, 0))
			{
				// ʧܣָյȴ״̬
				inst->previousState = TA_INIT;
				inst->nextState = TA_INIT;
				inst->testAppState = TA_RXE_WAIT ;  // wait to receive a new blink or poll message
				inst->wait4ack = 0; //  ACK ־TRX ѹر
			}
			else
			{
				// ɹеȴ TX ȷ״̬
				inst->testAppState = TA_TX_WAIT_CONF ; // wait confirmation
				inst->previousState = TA_TXBLINK_WAIT_SEND ;
				done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set below)

				 // ¼ʱ䣬ڳʱ
				inst->timeofTx = portGetTickCnt();
				//  TX_DONE ʱʱ
				inst->txDoneTimeoutDuration = inst->durationBlinkTxDoneTimeout_ms;
				// һ blink ʱ
				tdma_handler->last_blink_time = portGetTickCnt();
				// һƫƣ豸ͬʱ blink ͻ
				tdma_handler->blinkPeriodRand = (uint32)rand()%BLINK_PERIOD_RAND_MS;
			}

			break ;
		}// end case TA_TXBLINK_WAIT_SEND
		// =========================================================
        // Ͳʼ֡ RNG_INIT
        // =========================================================
        case TA_TXRANGINGINIT_WAIT_SEND :
        {
        	int psduLength = RNG_INIT_FRAME_LEN_BYTES;
					// к
            inst->rng_initmsg.seqNum = inst->frameSN++;

            inst->wait4ack = 0;

             // ӳٷʱһײ
			uint8 sys_time_arr[5] = {0, 0, 0, 0, 0};
			dwt_readsystime(sys_time_arr);
			uint64 dwt_time_now = 0;
			dwt_time_now = (uint64)sys_time_arr[0] + ((uint64)sys_time_arr[1] << 8) + ((uint64)sys_time_arr[2] << 16) + ((uint64)sys_time_arr[3] << 24) + ((uint64)sys_time_arr[4] << 32);
			// delayedReplyTime  DW1000 ʹõӳٷʱ
            //  8 λΪĴʽҪ
			inst->delayedReplyTime = (dwt_time_now + inst->rnginitReplyDelay + convertmicrosectodevicetimeu(rand()%RANGE_INIT_RAND_US)) >> 8 ;  // time we should send the blink response

 // д뷢
            dwt_writetxdata(psduLength, (uint8 *)  &inst->rng_initmsg, 0) ; // write the frame data
			// ӳٷ
			if(instancesendpacket(psduLength, DWT_START_TX_DELAYED | inst->wait4ack, inst->delayedReplyTime))
			{
				// ʧܣʱ late TX
				inst->previousState = TA_INIT;
				inst->nextState = TA_INIT;
				inst->testAppState = TA_RXE_WAIT ;  // wait to receive a new blink or poll message
				inst->wait4ack = 0; //clear the flag as the TX has failed the TRX is off
				inst->lateTX++;
			}
			else
			{
				// ɹȴ״̬
				inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
				inst->previousState = TA_TXRANGINGINIT_WAIT_SEND ;
				done = INST_DONE_WAIT_FOR_NEXT_EVENT;  //no timeout

				uint32 time_now = portGetTickCnt();
				inst->timeofTx = time_now;

				// ÷ɳʱ
				inst->txDoneTimeoutDuration = inst->durationRngInitTxDoneTimeout_ms;
				//  discovery modeȴ INF_INIT
				tdma_handler->set_discovery_mode(tdma_handler, WAIT_INF_INIT, time_now);
			}

			break;
        }
				 // =========================================================
        //  INF ϢINF_SUG / INF_INIT / INF_UPDATE / INF_REG
        // =========================================================
        case TA_TXINF_WAIT_SEND :
		{
			// 1. ȡ֡ȣINF ֡ tdma_handlerTDMA ̬
			int psduLength = tdma_handler->infMessageLength;
// 2. ֡кţÿһ֡к 1ڽնȥغ
			inst->inf_msg.seqNum = inst->frameSN++;
			// 3. ʱͬģ TDMA ֡ڵġ֡ʼʱ䡱TSFS
      // TSFS (Time Since Frame Start) ڸ߽շ TDMA ڵĸȷʱ㷢
			tdma_handler->update_inf_tsfs(tdma_handler);
// INF ϢͨҪӲԶ ACK
			inst->wait4ack = 0;

			// 4. д룺ڴе inf_msg ݿ UWB оƬ DW1000ķͻ
			dwt_writetxdata(psduLength, (uint8 *)  &inst->inf_msg, 0) ; // write the frame data
			// 5. 䣺Ƶ
			if(instancesendpacket(psduLength, DWT_START_TX_IMMEDIATE | inst->wait4ack, 0))
			{
				 // ʧʱ INF_SUGҪָ WAIT_SEND_SUG
				uint8 fcode;
				memcpy(&fcode, &inst->inf_msg.messageData[FCODE], sizeof(uint8));
// ǡϢ (INF_SUG)ʧܣ÷ģʽ״̬Ա´
				if(fcode == RTLS_DEMO_MSG_INF_SUG)
				{
					tdma_handler->set_discovery_mode(tdma_handler, WAIT_SEND_SUG, portGetTickCnt());
				}
// ״̬˵ʼ/յȴ״̬
				inst->previousState = TA_INIT;
				inst->nextState = TA_INIT;
				inst->testAppState = TA_RXE_WAIT;
			}
			else
			{
				// ֧ Bͳɹָ´
        // л״̬롰ȴȷϡ״̬ (TX_WAIT_CONF)
				// ͳɹȴ TX_DONE
				inst->testAppState = TA_TX_WAIT_CONF ;
				inst->previousState = TA_TXINF_WAIT_SEND ;
				// ǵǰδɣȴײӲжϣ TX_DONE
				done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set below)
// ¼ʼϵͳʱδ
				inst->timeofTx = portGetTickCnt();
				 //  TX_DONE ʱʱ = ָͻصӳ + ֡ʱ + ȫԣ
				// 6. ʱ㣺 TX_DONE жӦ÷صʱ
                // ʱʱ = ָ´ӳ (150us) + ݰзʱ + 1000us ȫԣ
				uint64 margin_us = 1000;
				uint64 framelength_us = instance_getmessageduration_us(psduLength);
				// ʱ(us)תΪ(ms)ʱ
				inst->txDoneTimeoutDuration = CEIL_DIV(TX_CMD_TO_TX_CB_DLY_US + framelength_us + margin_us, 1000);			//tx cmd to tx cb

			}

			break;
		}
		// =========================================================
        //  TAG_POLL ѯ֡
        // =========================================================
        case TA_TXPOLL_WAIT_SEND :
        {
        	int psduLength = POLL_FRAME_LEN_BYTES;
					// к
            inst->msg.seqNum = inst->frameSN++;
					// ϢΪ TAG_POLL
			inst->msg.messageData[FCODE] = RTLS_DEMO_MSG_TAG_POLL; //message function code (specifies if message is a poll, response or other...)
					 // ĿĵַҪĿڵ
			memcpy(&inst->msg.destAddr[0], &inst->uwbList[inst->uwbToRangeWith], inst->addrByteSize);
					// nthOldest ѯͬڵ
			tdma_handler->nthOldest++;

            inst->wait4ack = 0;
					// д뷢ͻ
			dwt_writetxdata(psduLength, (uint8 *)  &inst->msg, 0) ; // write the frame data

            if(instancesendpacket(psduLength, DWT_START_TX_IMMEDIATE | inst->wait4ack, 0))
			{
            	// ʧ
            	inst->tx_poll = FALSE;

				inst->previousState = TA_INIT;
				inst->nextState = TA_INIT;
				inst->testAppState = TA_RXE_WAIT;

				inst->wait4ack = 0; //clear the flag as the TX has failed the TRX is off
			}
			else
			{
				  // ͳɹ

				inst->tx_poll = TRUE;
				inst->testAppState = TA_TX_WAIT_CONF ;
				inst->previousState = TA_TXPOLL_WAIT_SEND ;
				done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set below)
				// ѯʱȹرմӡٸ
				inst->canPrintUSB = FALSE;
				inst->canPrintLCD = FALSE;
				
				inst->timeofTx = portGetTickCnt();
				inst->timeofTxPoll = portGetTickCnt();
				//  poll  TX_DONE ʱ
				inst->txDoneTimeoutDuration = inst->durationPollTxDoneTimeout_ms;
			}

            break;
        }
// =========================================
// ״̬��TA_TXREPORT_WAIT_SEND
// ���ܣ�׼�����͡������ REPORT ֡��
// ���ã�������õ� TOF�����롢�ź�ǿ�ȡ�ʱ���������͸���ǩ/��λ��
// =========================================
        case TA_TXREPORT_WAIT_SEND :
		{
			// REPORT ֡�ܳ��ȣ��̶�֡����
			int psduLength = REPORT_FRAME_LEN_BYTES;

			// ===================== 1. ��� REPORT ֡���� =====================
    // �Ѽ���õ� 6�ֽ� ToF������ʱ�䣩������Ϣ
            int32 reportRangeMm = 0;
            int32 selfX = 0;
            int32 selfY = 0;
            int32 selfZ = 0;
           // ===================== 2. ȡ����������� �� ���ף� =====================
            // �����ǰ��������Ч�����Ҿ���>0
            if(inst->uwbToRangeWith < UWB_LIST_SIZE && inst->idistance[inst->uwbToRangeWith] > 0.0)
            {
							// ������ӡ��ס�ת���ɡ����ס������㴫��Ͷ�λ����
                reportRangeMm = (int32)(inst->idistance[inst->uwbToRangeWith] * 1000.0);
							 // ��¼���β�ൽ���ػ��棨��������λʹ��
                mesh_dloc_note_range_mm(inst, 0, inst->uwbToRangeWith, reportRangeMm);
            }
						// ===================== 3. ���ؼ������½����������� =====================
            // ���ͱ���ǰ���ȵ���������λ�����������Լ����µ�����
            // ��֤����ȥ�����������¡���׼��
            mesh_dloc_update_self_position(inst);
						// ===================== 4. ȡ�������������� =====================
            // �ӽڵ㻺�����õ��Լ���������� X/Y/Z�����ף�
            selfX = inst->meshNodeCache[0].relPosMm[0];
            selfY = inst->meshNodeCache[0].relPosMm[1];
            selfZ = inst->meshNodeCache[0].relPosMm[2];
            // ===================== 5. ��� REPORT ֡�������ݶ� =====================
            // 1. �������루mm��
            memcpy(&inst->report_msg.messageData[REPORT_DISTANCE_MM], &reportRangeMm, sizeof(int32));
            memcpy(&inst->report_msg.messageData[REPORT_RSL], &inst->rxPWR, sizeof(double));
            memcpy(&inst->report_msg.messageData[REPORT_ADDR], &inst->uwbList[inst->uwbToRangeWith], inst->addrByteSize);
            memcpy(&inst->report_msg.messageData[REPORT_POLL_TX_TS], &inst->lastReportTround1, REPORT_TSTAMP_FIELD_LEN);
            memcpy(&inst->report_msg.messageData[REPORT_POLL_RX_TS], &inst->lastReportTreply1, REPORT_TSTAMP_FIELD_LEN);
            memcpy(&inst->report_msg.messageData[REPORT_RESP_TX_TS], &inst->lastReportTround2, REPORT_TSTAMP_FIELD_LEN);
            memcpy(&inst->report_msg.messageData[REPORT_RESP_RX_TS], &inst->lastReportTreply2, REPORT_TSTAMP_FIELD_LEN);
            memcpy(&inst->report_msg.messageData[REPORT_LCC_Q26], &inst->lastReportLccQ26, sizeof(int32));
            memcpy(&inst->report_msg.messageData[REPORT_COORD_X_MM], &selfX, sizeof(int32));
            memcpy(&inst->report_msg.messageData[REPORT_COORD_Y_MM], &selfY, sizeof(int32));
            memcpy(&inst->report_msg.messageData[REPORT_COORD_Z_MM], &selfZ, sizeof(int32));

			 // ֡���к� +1��ÿһ֡��ŵ�������ֹ�ظ���
			inst->report_msg.seqNum = inst->frameSN++;
       // ����Ҫ�ȴ� ACK Ӧ��
			inst->wait4ack = 0;
      // ===================== 2. Ӳ���������� =====================
      // �������� REPORT ֡д�� DW1000 Ӳ�����ͻ�����
			dwt_writetxdata(psduLength, (uint8 *)  &inst->report_msg, 0) ; // write the frame data
			 // ���÷��ͺ�������������������ģʽ
			if(instancesendpacket(psduLength, DWT_START_RX_IMMEDIATE, 0))
			{
				// ���ͳɹ��������ص��ȴ�����״̬
				inst->previousState = TA_INIT;
				inst->nextState = TA_INIT;
				inst->testAppState = TA_RXE_WAIT;
				inst->wait4ack = 0;
			}
			else
			{
				// ����δ��ɣ��ȴ��������ȷ��
				inst->testAppState = TA_TX_WAIT_CONF;                                               // wait confirmation
				inst->previousState = TA_TXREPORT_WAIT_SEND;
				done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out  (set below)
        // ��¼���Ϳ�ʼʱ�䣬���ڳ�ʱ�ж�
				inst->timeofTx = portGetTickCnt();
       // ���÷��ͳ�ʱʱ��
				inst->txDoneTimeoutDuration = inst->durationReportTxDoneTimeout_ms;
				// �ر���Ļ��ӡ
				inst->canPrintLCD = FALSE;
			}

			break;
		}
		// =========================================================
        // ȴȷ
        // =========================================================
        case TA_TX_WAIT_CONF :
        {
					// ȡ TX ¼
            event_data_t* dw_event = instance_getevent(11); //get and clear this event

            // ע⣺
            // ʱ ACK ¼ TX_DONE 
            // ﲻһϾõ DWT_SIG_TX_DONE
            if(dw_event->type != DWT_SIG_TX_DONE) //wait for TX done confirmation
            {
							//  RX_TIMEOUT˵ûеȵӦ ACK
                if(dw_event->type == DWT_SIG_RX_TIMEOUT) //got RX timeout - i.e. did not get the response (e.g. ACK)
                {
                    inst->gotTO = 1;
                }

                // ʱ DW1000  TX ɻصᴥ
                // ֻʱ
                uint32 dt = get_dt32(inst->timeofTx, portGetTickCnt());
                if(dt > inst->txDoneTimeoutDuration) //duration set at time of tx
                {
                	inst->gotTO = 1;
                }

                done = INST_DONE_WAIT_FOR_NEXT_EVENT;
								// ûʱͼ
                if(inst->gotTO == 0)
                {
                	break;
                }
            }

            done = INST_NOT_DONE_YET;

						// --------------------------
            // ͳʱ
            // --------------------------
            if (inst->gotTO) //timeout
			{
            	inst_processtxrxtimeout(inst);
				inst->gotTO = 0;
				inst->wait4ack = 0 ; //clear this

				break;
			}
            else
            {
							 // ոշ͵ INF ܻ֡ҪһЩģʽ״̬
                if(inst->previousState == TA_TXINF_WAIT_SEND)
                {
					inst->canPrintUSB = TRUE;
					inst->canPrintLCD = TRUE;

        			// ȡǰ INF ֡
        			uint8 fcode;
        			memcpy(&fcode, &inst->inf_msg.messageData[FCODE], sizeof(uint8));

                	// ɹ INF_SUG˳ģʽлΪê
					if(fcode == RTLS_DEMO_MSG_INF_SUG)
					{
						tdma_handler->set_discovery_mode(tdma_handler, EXIT, portGetTickCnt());
						inst->mode = ANCHOR;
					}

					//  INF_INIT / INF_SUG / INF_UPDATE
          // ô֮Լĳ㲥л INF_REG
					if(fcode == RTLS_DEMO_MSG_INF_INIT ||
					   fcode == RTLS_DEMO_MSG_INF_SUG ||
					   fcode == RTLS_DEMO_MSG_INF_UPDATE)
					{
						fcode = RTLS_DEMO_MSG_INF_REG;
						memcpy(&inst->inf_msg.messageData[FCODE], &fcode, sizeof(uint8));
					}
                }

								// ͳɹͳһ׼״̬

                else if(inst->previousState == TA_TXREPORT_WAIT_SEND)
                {
                    tdma_handler->nthOldest = 1;
                    tdma_handler->firstPollComplete = TRUE;
                    inst->testAppState = TA_TX_SELECT;
                    inst->previousState = TA_INIT;
                    inst->nextState = TA_INIT;
                    inst->uwbToRangeWith = 255;
                    inst->canPrintUSB = TRUE;
                    inst->canPrintLCD = FALSE;
                    message = 0;
                    break;
                }
                inst->testAppState = TA_RXE_WAIT ;       // After sending, tag expects response/report, anchor waits to receive a final/new poll

                // µ TA_RXE_WAIT ״ֱ̬ӿ RX
                message = 0;
            }
        }// end case TA_TX_WAIT_CONF
				// =========================================================
        // 򿪽ջ׼
        // =========================================================
        case TA_RXE_WAIT :
        {
					// ǰһûáԶ ACKֶ RX
            if(inst->wait4ack == 0) //if this is set the RX will turn on automatically after TX
            {
                //turn RX on
                instancerxon(inst, 0, 0) ;   //  RX
            }
            else
            {
							 // ֮ǰ TX ѾԶ RXֻ־
                inst->wait4ack = 0 ; //clear the flag, the next time we want to turn the RX on it might not be auto
            }

			// ȴ RX ¼
			done = INST_DONE_WAIT_FOR_NEXT_EVENT; //using RX FWTO

						// еȴݡ״̬
            inst->testAppState = TA_RX_WAIT_DATA;   // let this state handle it
            inst->rxCheckOnTime = portGetTickCnt();


            // ǰûϢ˳ȴһ¼
            if(message == 0)
            {
                break;
            }
        }
				 // =========================================================
        // ȴ״̬
        // =========================================================
        case TA_RX_WAIT_DATA :
        {
            // Wait RX data
            switch (message)
            {
							// -------------------------------------------------
                // յ BLINK ֡,ҪUWBģ鷢͵֡
                // -------------------------------------------------
                case DWT_SIG_RX_BLINK :
                {
                    event_data_t* dw_event = instance_getevent(12); //get and clear this event

					if(inst->mode == DISCOVERY)
					{
                        // ڷģʽ£յ BLINK ׼Է RNG_INIT
                        // ȰѶԷַǵ rng_initmsg.destAddr 
                        memcpy(&inst->rng_initmsg.destAddr[0], &(dw_event->msgu.rxblinkmsg.tagID[0]), BLINK_FRAME_SOURCE_ADDRESS); //remember who to send the reply to


                        inst->testAppState = TA_TXRANGINGINIT_WAIT_SEND;
                    }
                    else //not initiating ranging - continue to receive
                    {
											 //  discovery ģʽ
                        inst->testAppState = TA_RXE_WAIT ;              // wait for next frame
                        done = INST_NOT_DONE_YET;
                    }

                    break;
                }
								// -------------------------------------------------
                // յIEEE֡
                // -------------------------------------------------
                case DWT_SIG_RX_OKAY :
                {
                    //if we have received a DWT_SIG_RX_OKAY event - this means that the message is IEEE data type - need to check frame control to know which addressing mode is used
									//֡ݴ浽dw_event
                    event_data_t* dw_event = instance_getevent(15); //get and clear this event
                    uint8  srcAddr[8] = {0,0,0,0,0,0,0,0};
                    int fcode = 0;
                    int fn_code = 0;
                    uint8 *messageData;

                    // ���� UWB ֡���ͣ�֡�����ֽڣ����жϵ�ַ��ʽ������ַ/�̵�ַ����������Դ��ַ�������롢����
                    switch(dw_event->msgu.frame[1])
                    {
                        case 0xCC:
													 // ֡���� 0xCC��˫����ַ֡��Ŀ��64λ + Դ64λ��
                          // ���� 64λ Դ��ַ����վ/��ǩ��ΨһMAC��ַ��
                            memcpy(&srcAddr[0], &(dw_event->msgu.rxmsg_ll.sourceAddr[0]), ADDR_BYTE_SIZE_L);
												 // ȡ�������루��Ϣ���ͣ�
                            fn_code = dw_event->msgu.rxmsg_ll.messageData[FCODE];
												// ָ����Ϣ������ʼλ��
                            messageData = &dw_event->msgu.rxmsg_ll.messageData[0];
                            break;
                        case 0xC8:
													 // ֡���� 0xC8��Ŀ�ĳ���ַ + Դ�̵�ַ
                          // ���� 64λ Դ��ַ
                            memcpy(&srcAddr[0], &(dw_event->msgu.rxmsg_sl.sourceAddr[0]), ADDR_BYTE_SIZE_L);
                            fn_code = dw_event->msgu.rxmsg_sl.messageData[FCODE];
                            messageData = &dw_event->msgu.rxmsg_sl.messageData[0];
                            break;
                        case 0x8C:
													 // ֡���� 0x8C��Ŀ�Ķ̵�ַ + Դ����ַ
                          // ���� 16λ Դ��ַ
                            memcpy(&srcAddr[0], &(dw_event->msgu.rxmsg_ls.sourceAddr[0]), ADDR_BYTE_SIZE_S);
                            fn_code = dw_event->msgu.rxmsg_ls.messageData[FCODE];
                            messageData = &dw_event->msgu.rxmsg_ls.messageData[0];
                            break;
                        case 0x88:
													// ֡���� 0x88��˫�̵�ַ֡��Ŀ��16λ + Դ16λ������ ��Ĺ������
                          // ���� 16λ Դ��ַ�����ʱ�Ļ�վID����ǩID��
                            memcpy(&srcAddr[0], &(dw_event->msgu.rxmsg_ss.sourceAddr[0]), ADDR_BYTE_SIZE_S);
												 // ȡ�������룺��ࡢ�ϱ�����ʼ��������
                            fn_code = dw_event->msgu.rxmsg_ss.messageData[FCODE];
												// ָ����Ϣ���������������� TOF�����롢�ź�ǿ�ȵȣ�
                            messageData = &dw_event->msgu.rxmsg_ss.messageData[0];
                            break;
                    }

                    fcode = fn_code;

										// ݹһҵ߼
                    switch(fcode)
                    {
											// =========================================
                        // յ RNG_INITһ
                        // =========================================
                        case RTLS_DEMO_MSG_RNG_INIT:
                        {
													
                        	//NOTE: WAIT_RNG_INIT checked in RX callback

							// WAIT_RNG_INIT ĺϷ RX callback Ѽ
							uint32 time_now = portGetTickCnt();
													// µ TDMA 
                            tdma_handler->build_new_network(tdma_handler);
													// ׼ INF_INIT
                            tdma_handler->populate_inf_msg(tdma_handler, RTLS_DEMO_MSG_INF_INIT);
													 // ˳ģʽ
							tdma_handler->set_discovery_mode(tdma_handler, EXIT, time_now);
													 // 뷢ѡ״̬
							inst->testAppState = TA_TX_SELECT;
							inst->mode = ANCHOR;

                            break;
                        } //RTLS_DEMO_MSG_RNG_INIT
												// =========================================
                        // յ SYNC TDMA ֡ͬ
                        // =========================================
                        case RTLS_DEMO_MSG_SYNC :
                        {
                        	uint8 srcIndex = instgetuwblistindex(inst, &srcAddr[0], inst->addrByteSize);
                        	uint8 framelength;
							uint64 timeSinceFrameStart_us = 0;

							memcpy(&framelength, &messageData[SYNC_FRAMELENGTH], sizeof(uint8));
							memcpy(&timeSinceFrameStart_us, &messageData[SYNC_TSFS], 6);

							if(inst->mode == ANCHOR || inst->mode == TAG)
							{
								 // յͬϢ֡ͬǷҪ
								tdma_handler->frame_sync(tdma_handler, dw_event, framelength, timeSinceFrameStart_us, srcIndex, FS_EVAL);
							}

                        	break;
                        }
												// =========================================
                        // յ INF_UPDATE / INF_SUG / INF_REG
                        // =========================================
                        case RTLS_DEMO_MSG_INF_UPDATE : // ÷
                        case RTLS_DEMO_MSG_INF_SUG :    // ½ڵı
                        case RTLS_DEMO_MSG_INF_REG : // ״̬㲥
                        {
                        	uint32 time_now = portGetTickCnt();// ȡǰصδʱ
													// ݷߵӲַڱ UWB 豸бҵ (ID)
							uint8 srcIndex = instgetuwblistindex(inst, &srcAddr[0], inst->addrByteSize);

							uint8 framelength;
							uint64 timeSinceFrameStart_us = 0;
													// ݰнǰ綨ġ֡ȡٸ Slot
							memcpy(&framelength, &messageData[TDMA_FRAMELENGTH], sizeof(uint8));
													// ݰнTSFSTime Since Frame StartԷһʱ
    //  TDMA ֡ʼѾȥ˶΢롣ʵȫʱĹؼ
							memcpy(&timeSinceFrameStart_us, &messageData[TDMA_TSFS], 6);

							// -----------------------------------------------------------
    // 쳣飺ΪǹģʽTag/AnchorڶԷϢ
    // ʱ϶Ϊ 0ζҿֻܱ߳ˣǿƽطģʽ
    // -----------------------------------------------------------
							if(inst->mode == ANCHOR || inst->mode == TAG)
							{
								if(tdma_handler->uwbListTDMAInfo[0].slotsLength == 0)
								{
									// ÷ģʽΪȴ INF_REG 㲥
									inst->mode = DISCOVERY;
									tdma_handler->set_discovery_mode(tdma_handler, WAIT_INF_REG, time_now);
								}
							}

							// -----------------------------------------------------------
    //  A豸 DISCOVERY/ģʽʱ
    // -----------------------------------------------------------
                        	if(inst->mode == DISCOVERY)
                        	{
                        		// 1. ڵȳʼ (WAIT_INF_INIT)ȴյ˳˵г
        //    ֱת롰ռϢ (COLLECT_INF_REG)׶Σȿ

                        		if(tdma_handler->discovery_mode == WAIT_INF_INIT)
                        		{
                        			//if we receive network traffic while waiting for INF_INIT, transition to collecting INF messages
                        			tdma_handler->set_discovery_mode(tdma_handler, COLLECT_INF_REG, time_now);
                        		}
														// 2. һ (WAIT_INF_REG)
                        		if(tdma_handler->discovery_mode == WAIT_INF_REG) //treat INF_UPDATE and INF_SUG the same
								{
                        			// [ִͬ]ֱӲ (FS_ADOPT) Էʱ׼ԼʱӶȥ
                        			tdma_handler->frame_sync(tdma_handler, dw_event, framelength, timeSinceFrameStart_us, srcIndex, FS_ADOPT);
                        			// [Ϣ]ձؾɵ TDMA ȫ (CLEAR_ALL_COPY) Է
                        			tdma_handler->process_inf_msg(tdma_handler, messageData, srcIndex, CLEAR_ALL_COPY);
                        			// ռ׶
                        			tdma_handler->set_discovery_mode(tdma_handler, COLLECT_INF_REG, time_now);
								}
								// 3. ռ (COLLECT_INF_REG)
                        		else if(tdma_handler->discovery_mode == COLLECT_INF_REG)
                        		{
                        			// [ִͬ]ͬ (FS_COLLECT)һ΢ʱ
									tdma_handler->frame_sync(tdma_handler, dw_event, framelength, timeSinceFrameStart_us, srcIndex, FS_COLLECT);
									// [Ϣ]Ϣ׷ (COPY) رУھʱ϶ͼ
                        			tdma_handler->process_inf_msg(tdma_handler, messageData, srcIndex, COPY);
                        		}
														// 4. ׼ (WAIT_SEND_SUG)
                        		else if(tdma_handler->discovery_mode == WAIT_SEND_SUG)
								{
									// Ѿ׼ SUG ûȥʱȻͬ
                        			//process frame sync while waiting to send sug so we maintain syn with selected (sub)network
                        			//also give ourselves the opportunity to detect the need to transmit frame sync rebase messages
									// ȻҪ׼˵ˣţȡƽֵ (FS_AVERAGE) άͬ
									tdma_handler->frame_sync(tdma_handler, dw_event, framelength, timeSinceFrameStart_us, srcIndex, FS_AVERAGE);
								}
                        	}
													// -----------------------------------------------------------
    //  B豸Ѿ ANCHOR  TAGʱ
    // -----------------------------------------------------------
                        	else if(inst->mode == ANCHOR || inst->mode == TAG)
                        	{
                        		//if we are a TAG or ANCHOR
								//1.) sync our frame start time to the local network
                        		//2.) check for and adopt any tdma changes, sending an INF_UPDATE or INF_REG accordingly

                        		//synchronize the frames
														// 1. [ʱά]ʹƽ㷨 (FS_AVERAGE) Ưƣȷͬ
								tdma_handler->frame_sync(tdma_handler, dw_event, framelength, timeSinceFrameStart_us, srcIndex, FS_AVERAGE);

								//collecting tdma info, append to previously stored info
								// 2. [ά]һݾɵбб (CLEAR_LISTED_COPY)
								uint8_t tdma_modified = tdma_handler->process_inf_msg(tdma_handler, messageData, srcIndex, CLEAR_LISTED_COPY);
														// 3. [ɢ]ֶԷ TDMA øԼĲһ¼ˣ
								if(tdma_modified)
								{
									// ׼Լһʱ϶±仯㲥ȥַͨʽʵȫͬ
									tdma_handler->populate_inf_msg(tdma_handler, RTLS_DEMO_MSG_INF_UPDATE);
								}
                        	}


                        	// INF Ϣͨǵǰʱ϶ (Slot) һ񣬴еԴӡ
                        	inst->canPrintUSB = TRUE;
							inst->canPrintLCD = TRUE;

													// ״̬ãصռ״̬׼ӭһݰһʱ϶
							inst->testAppState = TA_RXE_WAIT ;

                        	break;
                        }
												// =========================================================
// յ INF_INIT粢ֱӼ루ܿؼ룩
// 豸ڵȴʼ (WAIT_INF_INIT) ״̬ʱյ˰
// =========================================================
                        case RTLS_DEMO_MSG_INF_INIT :
						{
							// WAIT_INF_INIT ĺϷ RX callback 
							//NOTE: discovery mode WAIT_INF_INIT checked in RX callback

							//process the INF packet
							// 1. ȡϢ
							uint32 time_now = portGetTickCnt();// ȡǰϵͳδʱ
							// ݰԴַ (srcAddr)Ҹ豸ڱھбе
							uint8 srcIndex = instgetuwblistindex(inst, &srcAddr[0], inst->addrByteSize);

							uint8 framelength;
							uint64 timeSinceFrameStart_us = 0;
							// 2. ڹؼ TDMA 
    // ϢȡԷġ֡ȡɶٸʱ϶ɣ
							memcpy(&framelength, &messageData[TDMA_FRAMELENGTH], sizeof(uint8));
							// ȡ֡ʼƫʱ䡿(TSFS)Էһ̣һ֡ʼȥ˶
							memcpy(&timeSinceFrameStart_us, &messageData[TDMA_TSFS], 6);

							//synchronize the frames
							// -----------------------------------------------------
    // 3. ִ֡ͬ (Frame Sync)
    // ʹ FS_ADOPT ģʽʾȫɡԷʱ׼
    // صĶʱȷԼʱ϶߽豸
    // -----------------------------------------------------
							tdma_handler->frame_sync(tdma_handler, dw_event, framelength, timeSinceFrameStart_us, srcIndex, FS_ADOPT);
							// 4. 
    // Է TDMA ãʱ϶ȣֱӿ
    // CLEAR_ALL_COPY ʾԼ֮ǰľãȫͬΪԷİ汾
							tdma_handler->process_inf_msg(tdma_handler, messageData, srcIndex, CLEAR_ALL_COPY);
							// 5. ׼㲥
    // ݸѧã䱾豸 INF Ϣģ壬Ϊ INF_UPDATE
    // ֵ豸˵ʱԶ豸㲥״̬
							tdma_handler->populate_inf_msg(tdma_handler, RTLS_DEMO_MSG_INF_UPDATE);
							// 6. ת䣺ʽ
    // رաģʽDiscovery Mode -> EXIT
							tdma_handler->set_discovery_mode(tdma_handler, EXIT, time_now);

 // ݴӡѰߡתΪê (ANCHOR)
    // ʱ豸ʽΪһ֣ʼлվְӦתݣ
							inst->mode = ANCHOR;

							// 7. ״̬
    // ״̬Ϊ TA_RXE_WAIT׼һʱ϶ܴ
							inst->testAppState = TA_RXE_WAIT ;              // wait for next frame

							break;
						}//RTLS_DEMO_MSG_INF
						 // ������Ϣ���ͣ���ǩ���͵� POLL ̽��֡ (0x21)
             // ���ã�Tag �����࣬���� Poll ֡����վ/���ն��ڴ˴���
                        case RTLS_DEMO_MSG_TAG_POLL:
                        {
													// �жϣ�UWB �Ƿ����ڷ������ݣ�TX æ��
                            if(dw_event->typePend == DWT_SIG_TX_PENDING)
                            {
															 // UWB Ӳ������æ��������δ��ɣ�
                              // ״̬���л����ȴ��������ȷ��
                                inst->testAppState = TA_TX_WAIT_CONF;              // wait confirmation
															// ��¼��һ��״̬���ȴ����� RESP ��Ӧ֡
                                inst->previousState = TA_TXRESPONSE_WAIT_SEND ;
                            }
                            else
                            {
															 // UWB ������� / ����
                              // ���л����ͣ����ֽ���״̬���ȴ���һ֡����
                                inst->testAppState = TA_RXE_WAIT ;              // wait for next frame
                            }

                            break;
														
                        }//RTLS_DEMO_MSG_TAG_POLL
												// ������Ϣ���ͣ���վ�ظ��� RESP ��Ӧ֡ (0x10)
                        // ���ã�Tag �յ���վ�� Poll ֡��Ӧ��׼������ Final ֡
                        case RTLS_DEMO_MSG_ANCH_RESP:
                        {
                            uint8 rangeIndex = inst->uwbToRangeWith;
                            uint64 pollTxTime = 0;
                            uint64 pollRxTime = 0;
                            uint64 respTxTime = 0;
                            uint64 respRxTime = 0;
                            uint64 roundDtu = 0;
                            uint64 replyDtu = 0;
                            uint64 tagDt = 0;
                            uint64 anchorDt = 0;
                            int32 anchorCfrQ26 = (int32)SS_LCC_Q26_SCALE;
                            double measurements[4] = {0.0, 0.0, 0.0, 0.0};
                            double variances[4] = {0.0, 0.0, 0.0, 0.0};
                            uint8 measCount = 0;
                            double dtSeconds = SS_LCC_DEFAULT_DT_SEC;
                            double lcc = 1.0;
                            double cfrTagOverAnchor;
                            double cfrAnchorOverTag;
                            double tofDtu;

                            if(dw_event->typePend == DWT_SIG_TX_PENDING)
                            {
                                inst->testAppState = TA_TX_WAIT_CONF;
                                inst->previousState = TA_TXREPORT_WAIT_SEND;
                                break;
                            }

                            if(rangeIndex >= UWB_LIST_SIZE)
                            {
                                inst->testAppState = TA_RXE_WAIT;
                                break;
                            }

                            memcpy(&pollTxTime, &(inst->msg.messageData[PTXT]), 5);
                            respRxTime = dw_event->timeStamp & MASK_40BIT;
                            memcpy(&pollRxTime, &messageData[ANCH_RESP_POLL_RX_TS], 5);
                            memcpy(&respTxTime, &messageData[ANCH_RESP_TX_TS], 5);
                            memcpy(&anchorCfrQ26, &messageData[ANCH_RESP_CFR_Q26], sizeof(int32));

                            cfrTagOverAnchor = 1.0 - dw_event->clockOffsetRatio;
                            if(cfrTagOverAnchor > SS_LCC_MIN && cfrTagOverAnchor < SS_LCC_MAX)
                            {
                                measurements[measCount] = cfrTagOverAnchor;
                                variances[measCount] = SS_LCC_CFR_R;
                                measCount++;
                            }

                            cfrAnchorOverTag = ss_q26_to_double(anchorCfrQ26);
                            if(cfrAnchorOverTag > SS_LCC_MIN && cfrAnchorOverTag < SS_LCC_MAX)
                            {
                                measurements[measCount] = 1.0 / cfrAnchorOverTag;
                                variances[measCount] = SS_LCC_CFR_R;
                                measCount++;
                            }

                            if(inst->ssPrevPollTxTime[rangeIndex] != 0 && inst->ssPrevPollRxTime[rangeIndex] != 0)
                            {
                                tagDt = get_dt64(inst->ssPrevPollTxTime[rangeIndex], pollTxTime);
                                anchorDt = get_dt64(inst->ssPrevPollRxTime[rangeIndex], pollRxTime);
                                if(tagDt > 0 && anchorDt > 0)
                                {
                                    double csr = ((double)tagDt) / ((double)anchorDt);
                                    if(csr > SS_LCC_MIN && csr < SS_LCC_MAX && measCount < 4)
                                    {
                                        measurements[measCount] = csr;
                                        variances[measCount] = SS_LCC_CSR_R;
                                        measCount++;
                                    }
                                    dtSeconds = ss_dt_to_sec(tagDt);
                                }
                            }

                            if(inst->ssPrevRespRxTime[rangeIndex] != 0 && inst->ssPrevRespTxTime[rangeIndex] != 0)
                            {
                                tagDt = get_dt64(inst->ssPrevRespRxTime[rangeIndex], respRxTime);
                                anchorDt = get_dt64(inst->ssPrevRespTxTime[rangeIndex], respTxTime);
                                if(tagDt > 0 && anchorDt > 0 && measCount < 4)
                                {
                                    double csr = ((double)tagDt) / ((double)anchorDt);
                                    if(csr > SS_LCC_MIN && csr < SS_LCC_MAX)
                                    {
                                        measurements[measCount] = csr;
                                        variances[measCount] = SS_LCC_CSR_R;
                                        measCount++;
                                    }
                                }
                            }

                            lcc = ss_lcc_kf_update(inst, rangeIndex, dtSeconds, measurements, variances, measCount);

                            roundDtu = get_dt64(pollTxTime, respRxTime);
                            replyDtu = get_dt64(pollRxTime, respTxTime);
                            tofDtu = 0.5 * (((double)roundDtu) - (lcc * ((double)replyDtu)));
                            if(tofDtu < 0.0)
                            {
                                tofDtu = 0.0;
                            }

                            inst->tof[rangeIndex] = (int64)(tofDtu + 0.5);
                            inst->clockOffset = lcc - 1.0;
                            inst->ssPollTxTime = pollTxTime;
                            inst->ssPollRxTime = pollRxTime;
                            inst->ssRespTxTime = respTxTime;
                            inst->ssRespRxTime = respRxTime;
                            inst->lastReportTround1 = pollTxTime;
                            inst->lastReportTreply1 = pollRxTime;
                            inst->lastReportTround2 = respTxTime;
                            inst->lastReportTreply2 = respRxTime;
                            inst->lastReportLccQ26 = ss_double_to_q26(lcc);

                            inst->ssPrevPollTxTime[rangeIndex] = pollTxTime;
                            inst->ssPrevPollRxTime[rangeIndex] = pollRxTime;
                            inst->ssPrevRespRxTime[rangeIndex] = respRxTime;
                            inst->ssPrevRespTxTime[rangeIndex] = respTxTime;

                            inst->newRangeUWBIndex = rangeIndex;
                            if(reportTOF(inst, inst->newRangeUWBIndex, inst->rxPWR) == 0)
                            {
                                inst->newRange = 1;
                            }

                            tdma_handler->uwbListTDMAInfo[rangeIndex].lastRange = portGetTickCnt();
                            inst->newRangeTagAddress = instance_get_addr();
                            inst->newRangeAncAddress = instance_get_uwbaddr(rangeIndex);
                            inst->testAppState = TA_TXREPORT_WAIT_SEND;
                            inst->delayedReplyTime = 0;

                            break;
                        }  //RTLS_DEMO_MSG_ANCH_RESP SS-TWR/LCC

                        case RTLS_DEMO_MSG_TAG_FINAL :
                        {
													// ���� DS-TWR ��������ʱ�����
                            int64 Rb, Da, Ra, Db ;
                            uint64 tagFinalTxTime  = 0;// Tag ���� Final ֡��ʱ��
                            uint64 tagFinalRxTime  = 0;// Anchor ���� Final ֡��ʱ��
                            uint64 tagPollTxTime  = 0;// Tag ���� Poll ֡��ʱ��
                            uint64 anchorRespRxTime  = 0; // Tag ���� Response ֡��ʱ��
                            // DS-TWR ���㹫ʽ�м����
                            double RaRbxDaDb = 0;
                            double RbyDb = 0;
                            double RayDa = 0;

                             // ===================== 1. ��ȡʱ��� =====================
                             // Anchor ����Ӳ����¼���յ� Final ֡��ʱ��
                            tagFinalRxTime = inst->dwt_final_rx;

                            // �� TAG ������ Final ��Ϣ�����У���ȡ 3 ���ؼ�ʱ�����5�ֽ� = 40bit��
                           // ��Щ�� Tag �˼�¼��ʱ�䣬ͨ�����߷��� Anchor
                            memcpy(&tagPollTxTime, &(messageData[PTXT]), 5); // Tag ���� Poll ��ʱ��
                            memcpy(&anchorRespRxTime, &(messageData[RRXT]), 5);// Tag ���� Resp ��ʱ��
                            memcpy(&tagFinalTxTime, &(messageData[FTXT]), 5);// Tag ���� Final ��ʱ��

                            // ===================== 2. ���� DS-TWR �Ķ�ʱ�� =====================
                            // ����һ��ʱ�䡿��Tag �� Poll -> Resp ��ʱ���
                            Ra = (int64)((anchorRespRxTime - tagPollTxTime) & MASK_40BIT);
														// ���ڶ���ʱ�䡿��Anchor �� Poll -> Resp ��ʱ���
                            Db = (int64)((inst->anchorRespTxTime - inst->tagPollRxTime) & MASK_40BIT);
														 // �������ڵ���/�ϱ�
                            inst->lastReportTround1 = (uint64)Ra;
                            inst->lastReportTreply1 = (uint64)Db;

                            // ��������ʱ�䡿��Anchor �� Resp -> Final ��ʱ���
                            Rb = (int64)((tagFinalRxTime - inst->anchorRespTxTime) & MASK_40BIT);
														 // �����Ķ�ʱ�䡿��Tag �� Resp -> Final ��ʱ���
							Da = (int64)((tagFinalTxTime - anchorRespRxTime) & MASK_40BIT);
							 // �������ڵ���/�ϱ�
                            inst->lastReportTround2 = (uint64)Rb;
                            inst->lastReportTreply2 = (uint64)Da;
							  // ===================== 3. DS-TWR ���Ĺ�ʽ������ ToF������ʱ�䣩 =====================
                              // ��ʽ��ToF = (Ra*Rb - Da*Db) / (Ra + Rb + Da + Db)
                            RaRbxDaDb = (((double)Ra))*(((double)Rb)) - (((double)Da))*(((double)Db));
                            RbyDb = ((double)Rb + (double)Db);
                            RayDa = ((double)Ra + (double)Da);

                            // �������շ���ʱ�� ToF��UWB �����Ľ����
                            inst->tof[inst->uwbToRangeWith] = (int64) ( RaRbxDaDb/(RbyDb + RayDa) );
														// ===================== 4. ��ǲ����� =====================
                           // ��¼��ǰ���Ļ�վ����
                            inst->newRangeUWBIndex = inst->uwbToRangeWith;
														 // �����ϱ��������� ToF ת���ɾ��룬��Я���ź�ǿ��(rxPWR)
							if(reportTOF(inst, inst->newRangeUWBIndex, inst->rxPWR)==0)
							{
								 // ��ǣ��µ���Ч�����������
								inst->newRange = 1;
							}
							// ���� TDMA ���ȣ���¼���β�����ʱ��
                            tdma_handler->uwbListTDMAInfo[inst->uwbToRangeWith].lastRange = portGetTickCnt();
							// ��¼���β��� TAG �� ANCHOR ��ַ
                            inst->newRangeTagAddress = instance_get_uwbaddr(inst->uwbToRangeWith);
                            inst->newRangeAncAddress = instance_get_addr();
							 // ״̬���л���׼������ RNG_REPORT ������ϱ�֡�
                            inst->testAppState = TA_TXREPORT_WAIT_SEND;
                            inst->delayedReplyTime = 0 ;

                            break;
                        } //RTLS_DEMO_MSG_TAG_FINAL ��������
												// =========================================
                       //  UWB ౨ϢRNG_REPORT
                       // =========================================
                                                case RTLS_DEMO_MSG_RNG_REPORT :
                        {
													 // ������������
                           // tag_index������Ϣ�л�ȡ ��ǩ����������
                            uint8 tag_index = instgetuwblistindex(inst, &srcAddr[0], inst->addrByteSize);
													// anchor_index����ȡ���͸���Ϣ��**��վ**���б��е�����
                            uint8 anchor_index = instgetuwblistindex(inst, &messageData[REPORT_ADDR], inst->addrByteSize);
													 // ����������洢����Ϣ�н��������� ���롢������Ϣ
                            int32 reportRangeMm = 0;// ��վ�ϱ��Ĳ��ֵ����λ��mm��
                            int32 srcX = 0; // ��վ�������� X
                            int32 srcY = 0;// ��վ�������� Y
                            int32 srcZ = 0;
                            int32 reportLccQ26 = (int32)SS_LCC_Q26_SCALE; // ��վ�������� Z
                            // ���Դ�ӡ��USB����յ��Ĳ�౨����Ϣ����־�ã�
                            //debug_usb_print_received_report(inst, &srcAddr[0], messageData);
                            // ��ȫУ�飺�����վ/��ǩ���������б����ֵ��ֱ���˳�����ֹԽ��
                            if(anchor_index >= UWB_LIST_SIZE || tag_index >= UWB_LIST_SIZE)
                            {
                                inst->testAppState = TA_RXE_WAIT;// �ص��ȴ�����״̬
                                break;
                            }
                            // ===================== ���������ݽ����� =====================
                            // 1. ����Ϣ�и��ƣ���վ -> ��ǩ �Ĳ���������ף�
                            memcpy(&reportRangeMm, &messageData[REPORT_DISTANCE_MM], sizeof(int32));
														// 2. �����ź�ǿ��RSSI
                            memcpy(&inst->rxPWR, &messageData[REPORT_RSL], sizeof(double));
                            memcpy(&reportLccQ26, &messageData[REPORT_LCC_Q26], sizeof(int32));
														 // 3. ���ƻ�վ����������������꣨X/Y/Z�����ף�
                            memcpy(&srcX, &messageData[REPORT_COORD_X_MM], sizeof(int32));
                            memcpy(&srcY, &messageData[REPORT_COORD_Y_MM], sizeof(int32));
                            memcpy(&srcZ, &messageData[REPORT_COORD_Z_MM], sizeof(int32));
                            // ===================== �����±������ݡ� =====================
                             // ����Զ�˻�վ�����굽���ػ��棨��ǩ֪�������վ�����ˣ�
                            mesh_dloc_update_remote_coord(inst, tag_index, srcX, srcY, srcZ);
														// ��¼��վ���ǩ֮��Ĳ���������ף�
                            mesh_dloc_note_range_mm(inst, anchor_index, tag_index, reportRangeMm);
                            inst->meshNodeCache[tag_index].lccQ26 = reportLccQ26;
                            inst->meshNodeCache[tag_index].lccValid = TRUE;
														// ===================== ������ǩ��0�ű�ǩ�����¾��롿 =====================
                           // ����� 0�ű�ǩ������ǩ�������Ҳ����Ч��>0��
                            if(tag_index == 0 && reportRangeMm > 0)
                            {
															// �Ѻ���תΪ�ף������ǩ�ľ���� idistance[]
                                inst->idistance[anchor_index] = ((double)reportRangeMm) / 1000.0;
                                inst->idistanceraw_mm[anchor_index] = reportRangeMm;
                                inst->idistancersl[anchor_index] = inst->idistance[anchor_index];
                                inst->tof[anchor_index] = 0;
                                  // ��¼������Ч���ģ���վ��ַ����ǩ��ַ����վ����
                                inst->newRangeAncAddress = instance_get_uwbaddr(anchor_index);
                                inst->newRangeTagAddress = instance_get_uwbaddr(tag_index);
                                inst->newRangeUWBIndex = anchor_index;
                                inst->newRange = 1;
                            }
														// ===================== ���ؼ���������ǩ������λ���㡿 =====================
                          // ���ú�����ʹ���ѻ�ȡ�ġ������վ���� + ������롿�����ǩ����λ��
                          // ��������ڲ��ͻ������֮ǰ���ģ����㶨λ�����㶨λ��α���Զ�λ
                            mesh_dloc_update_self_position(inst);
                          // ===================== ��״̬���л��� =====================
                          // ����� 0�ű�ǩ�����һ�ֲ�࣬׼����ʼ��һ��
                            if(tag_index == 0)
                            {
                                tdma_handler->nthOldest = 1;
                                tdma_handler->uwbListTDMAInfo[inst->uwbToRangeWith].lastRange = portGetTickCnt();
                                tdma_handler->firstPollComplete = TRUE;
															// ״̬�ص�ѡ����ģʽ��׼����һ�β��
                                inst->testAppState = TA_TX_SELECT;
                                inst->previousState = TA_INIT;
                                inst->nextState = TA_INIT;
                                inst->uwbToRangeWith = 255;
                            }
                            else
                            {
															// ������ǩ���ص��ȴ�����ģʽ
                                inst->testAppState = TA_RXE_WAIT;
                                inst->previousState = TA_INIT;
                                inst->nextState = TA_INIT;
                                inst->uwbToRangeWith = 255;
                            }
                             // ����USB��ӡ���أ�ֻ��0�ű�ǩ����Ч�����������
                            inst->canPrintUSB = (tag_index == 0 && reportRangeMm > 0) ? TRUE : FALSE;
                            inst->canPrintLCD = FALSE;

                            break;
                        } //RTLS_DEMO_MSG_RNG_REPORT

						// =========================================
                        // δʶĹ
                        // =========================================
                        default:
                        {
													// ԣһ֡
                            inst->testAppState = TA_RXE_WAIT ;              // wait for next frame

                            break;
                        }
                    } //end switch (fcode)


                    break ;
                } //end of DWT_SIG_RX_OKAY
								 // -------------------------------------------------
                // ճʱ
                // -------------------------------------------------
                case DWT_SIG_RX_TIMEOUT :
                {
									// ڵȴ RNG_INIT / INF_INIT ʱʱ
                    // תΪȴ INF_REG
                	if(tdma_handler->discovery_mode == WAIT_RNG_INIT || tdma_handler->discovery_mode == WAIT_INF_INIT)
					{
                		uint32 time_now = portGetTickCnt();
						tdma_handler->set_discovery_mode(tdma_handler, WAIT_INF_REG, time_now);
					}

					// ¼ͳһ߳ʱ
                    instance_getevent(17); //get and clear this event
                    inst_processtxrxtimeout(inst);
                    message = 0; //clear the message as we have processed the event

                    break;
                }
								// -------------------------------------------------
                //  AA_DONE Ϣ˳Լ
                // -------------------------------------------------
                case DWT_SIG_TX_AA_DONE: //ignore this event - just process the rx frame that was received before the ACK response
                case 0:
                default:
                {
									// ǰ TAG poll/final Ƿʱ
                	if(inst->mode == TAG){		
                		//get the message FCODE
						uint8 fcode;
						memcpy(&fcode, &inst->msg.messageData[FCODE], sizeof(uint8));

						if(fcode == RTLS_DEMO_MSG_TAG_POLL)
						{
							uint32 dt = get_dt32(inst->timeofTxPoll, portGetTickCnt());
							if(dt > inst->durationPollTimeout_ms)
							{
								inst_processtxrxtimeout(inst);
							}
						}
						else if(fcode == RTLS_DEMO_MSG_TAG_FINAL)
						{
							uint32 dt = get_dt32(inst->timeofTxFinal, portGetTickCnt());
							if(dt > inst->durationFinalTimeout_ms)
							{
								inst_processtxrxtimeout(inst);
							}
						}
                	}

                	// ڼ RX ǷĿ
                	uint32 time_now = portGetTickCnt();
					uint32 timeSinceRxCheck = get_dt32(inst->rxCheckOnTime, time_now);
					if(timeSinceRxCheck >= RX_CHECK_ON_PERIOD_MS)
					{
						inst->rxCheckOnTime = time_now;

						//read SYS_STATE, getting second byte
						// ȡ SYS_STATE ڶֽ
						uint8 regval = dwt_read8bitoffsetreg(SYS_STATE_ID,1);
						//get the first 5 bytes
						// ȡ 5 λж״̬
						regval &= 0x1F;
						//  RX IDLE
						if(regval == 0){//RX IDLE	
							dwt_forcetrxoff();
							instancerxon(inst, 0, 0);
						}
					}

					//check if it's time to BLINK
					// Ƿ񵽴´ BLINK ʱ
					if(tdma_handler->check_blink(tdma_handler) == TRUE)
					{
						inst->testAppState = TA_TX_SELECT;
					}

                    if(done == INST_NOT_DONE_YET)
                    {
                        done = INST_DONE_WAIT_FOR_NEXT_EVENT;
                    }

                    break;
                }
            } // end of switch on message

            break;
        } // end case TA_RX_WAIT_DATA
				// =========================================================
        // ĬϷ֧
        // =========================================================
        default:
        {
            break;
        }
    } // end switch on testAppState

    return done;
} // end testapprun()








// -------------------------------------------------------------------------------------------------------------------
#if NUM_INST != 1
#error These functions assume one instance only
#else


// -------------------------------------------------------------------------------------------------------------------
// function to initialise instance structures
//
// Returns 0 on success and -1 on error
int instance_init_s(void)
{
    instance_data_t* inst = instance_get_local_structure_ptr(0);

    inst->mode = DISCOVERY;
    inst->testAppState = TA_INIT;

    // if using auto CRC check (DWT_INT_RFCG and DWT_INT_RFCE) are used instead of DWT_INT_RDFR flag
    // other errors which need to be checked (as they disable receiver) are
    dwt_setinterrupt(SYS_MASK_VAL, 1);

    //this is platform dependent - only program if DW EVK/EVB
    dwt_setleds(3) ; //configure the GPIOs which control the LEDs on EVBs

    dwt_setcallbacks(instance_txcallback, instance_rxgoodcallback, instance_rxtimeoutcallback, instance_rxerrorcallback, instance_irqstuckcallback);

#if (USING_64BIT_ADDR==0)
    inst->addrByteSize = ADDR_BYTE_SIZE_S;
#else
    inst->addrByteSize = ADDR_BYTE_SIZE_L;
#endif

    inst->uwbToRangeWith = 255;

    return 0 ;
}


extern uint8 dwnsSFDlen[];

// Pre-compute frame lengths, timeouts and delays needed in ranging process.
// /!\ This function assumes that there is no user payload in the frame.
void instance_init_timings(void)
{
    instance_data_t* inst = instance_get_local_structure_ptr(0);
    uint32 pre_len;
    int sfd_len;

	static const int data_len_bytes[FRAME_TYPE_NB] = {
            BLINK_FRAME_LEN_BYTES, RNG_INIT_FRAME_LEN_BYTES, POLL_FRAME_LEN_BYTES,
            RESP_FRAME_LEN_BYTES, FINAL_FRAME_LEN_BYTES, REPORT_FRAME_LEN_BYTES, SYNC_FRAME_LEN_BYTES, INF_FRAME_LEN_BYTES_MAX};


    // Margin used for timeouts computation.
    uint64 margin_us = 200;

    // All internal computations are done in tens of picoseconds before
    // conversion into microseconds in order to ensure that we keep the needed
    // precision while not having to use 64 bits variables.

    // Compute frame lengths.
    // First step is preamble plus SFD length.
    sfd_len = dwnsSFDlen[inst->configData.dataRate];
    switch (inst->configData.txPreambLength)
    {
    case DWT_PLEN_4096:
        pre_len = 4096;
        break;
    case DWT_PLEN_2048:
        pre_len = 2048;
        break;
    case DWT_PLEN_1536:
        pre_len = 1536;
        break;
    case DWT_PLEN_1024:
        pre_len = 1024;
        break;
    case DWT_PLEN_512:
        pre_len = 512;
        break;
    case DWT_PLEN_256:
        pre_len = 256;
        break;
    case DWT_PLEN_128:
        pre_len = 128;
        break;
    case DWT_PLEN_64:
    default:
        pre_len = 64;
        break;
    }
    pre_len += sfd_len;
    // Convert preamble length from symbols to time. Length of symbol is defined
    // in IEEE 802.15.4 standard.
    if (inst->configData.prf == DWT_PRF_16M)
        pre_len *= 99359;
    else
        pre_len *= 101763;

    inst->storedPreLen = pre_len; //store to be used later with inf messages and frame_sync
    inst->storedPreLen_us = CEIL_DIV(pre_len, 100000);

    // Second step is data length for all frame types.
    for (int i = 0; i < FRAME_TYPE_NB; i++)
    {
    	inst->frameLengths_us[i] = instance_getmessageduration_us(data_len_bytes[i]);
    }

    //delayed tx durations
    uint8 reply_margin_us = 25;
    uint64 duration = 0;
	duration += inst->frameLengths_us[POLL] - inst->storedPreLen_us + RX_TO_CB_DLY_US;		//poll rx timestamp to poll rx cb
	duration += RX_CB_TO_TX_CMD_DLY_US + MIN_DELAYED_TX_DLY_US + inst->storedPreLen_us;		//poll rx cb to resp tx timestamp
	uint64 respDelay_us = duration + reply_margin_us;
	uint64 respDelay = convertmicrosectodevicetimeu(respDelay_us);

	duration = 0;
	duration += inst->frameLengths_us[RESP] - inst->storedPreLen_us + RX_TO_CB_DLY_US;		//resp rx timestamp to resp rx cb
	duration += RX_CB_TO_TX_CMD_DLY_US + MIN_DELAYED_TX_DLY_US + inst->storedPreLen_us;		//resp rx cb to final tx timestamp
	uint64 finalDelay_us = duration + reply_margin_us;
	uint64 finalDelay = convertmicrosectodevicetimeu(finalDelay_us);

	//make reply times the same to minimize clock drift error. See Application Note APS011 for more information
	inst->respReplyDelay = inst->finalReplyDelay = MAX(respDelay, finalDelay);
	uint64 replyDelay_us = MAX(respDelay_us, finalDelay_us);


	//POLL TX TS TO FINAL TX TS
	duration = 0;
	duration += respDelay_us + finalDelay_us;												//poll tx ts to final tx ts
	uint64 pollTxToFinalTx = duration;

    // Delay between blink reception and ranging init message transmission.
	inst->rnginitReplyDelay = convertmicrosectodevicetimeu(MIN_DELAYED_TX_DLY_US + inst->storedPreLen_us); //rng_init tx cmd to rng_init tx ts

	margin_us = 1000;
    //rx timeout durations (_nus units are 1.0256us)
    duration = 0;
    duration +=	TX_CMD_TO_TX_CB_DLY_US + replyDelay_us;						//poll tx cmd to resp tx ts
    duration +=	inst->frameLengths_us[RESP] - inst->storedPreLen_us;		//resp tx ts to resp tx cb
    duration += RX_TO_CB_DLY_US + RX_CB_TO_TX_CMD_DLY_US;					//resp tx cb to final tx cmd
    duration += margin_us;
    inst->durationPollTimeout_nus = (uint16)(duration/1.0256) + 1;
	inst->durationPollTimeout_ms = (uint16)CEIL_DIV(duration, 1000);

	duration = 0;
	duration += TX_CMD_TO_TX_CB_DLY_US + inst->frameLengths_us[FINAL]; 	                                           //final tx cmd to final tx cb
	duration += RX_TO_CB_DLY_US + RX_CB_TO_TX_CMD_DLY_US;			  	                                           //final tx cb to place final
	duration += (uint64)MEASURED_SLOT_DURATIONS_US/2;                                   						   //place final to report tx cmd
	duration += TX_CMD_TO_TX_CB_DLY_US + inst->frameLengths_us[REPORT] + RX_TO_CB_DLY_US + RX_CB_TO_TX_CMD_DLY_US; //report tx cmd to place report
	duration += margin_us;
	inst->durationFinalTimeout_ms = (uint16)CEIL_DIV(duration, 1000);

	margin_us = 1000;
    //tx conf timeout durations
    inst->durationBlinkTxDoneTimeout_ms = CEIL_DIV(TX_CMD_TO_TX_CB_DLY_US + inst->frameLengths_us[BLINK] + margin_us, 1000);			//tx cmd to tx cb
    inst->durationRngInitTxDoneTimeout_ms = CEIL_DIV(TX_CMD_TO_TX_CB_DLY_US + inst->frameLengths_us[RNG_INIT] + margin_us, 1000);		//tx cmd to tx cb
    inst->durationPollTxDoneTimeout_ms = CEIL_DIV(TX_CMD_TO_TX_CB_DLY_US + inst->frameLengths_us[POLL] + margin_us, 1000);				//tx cmd to tx cb
    inst->durationReportTxDoneTimeout_ms = CEIL_DIV(TX_CMD_TO_TX_CB_DLY_US + inst->frameLengths_us[REPORT] + margin_us, 1000);			//tx cmd to tx cb
    inst->durationSyncTxDoneTimeout_ms = CEIL_DIV(TX_CMD_TO_TX_CB_DLY_US + inst->frameLengths_us[SYNC] + margin_us, 1000);				//tx cmd to tx cb

    uint32 fl = 0;
    if(inst->frameLengths_us[RESP] < inst->frameLengths_us[FINAL])
    {
    	fl = inst->frameLengths_us[RESP] - inst->storedPreLen_us;
    }
    else
    {
    	fl = inst->frameLengths_us[FINAL] - inst->storedPreLen_us;
    }
    duration = 0;
    duration += replyDelay_us - fl;
    duration -= RX_TO_CB_DLY_US + RX_CB_TO_TX_CMD_DLY_US;
    inst->durationRespTxDoneTimeout_ms = CEIL_DIV(duration + inst->frameLengths_us[RESP] - inst->storedPreLen_us + margin_us, 1000);	//tx cmd to tx cb
    inst->durationFinalTxDoneTimeout_ms = CEIL_DIV(duration + inst->frameLengths_us[FINAL] - inst->storedPreLen_us + margin_us, 1000);	//tx cmd to tx cb

    //figure maximum duration of a TDMA slot in microseconds
    duration = 0;
    duration += SLOT_START_BUFFER_US;	//frame start buffer
    duration += SLOT_BUFFER_EXP_TO_POLL_CMD_US; //buffer expiration to cmd poll
    duration += TX_CMD_TO_TX_CB_DLY_US + pollTxToFinalTx + inst->frameLengths_us[FINAL] + RX_TO_CB_DLY_US + RX_CB_TO_TX_CMD_DLY_US;//poll cmd to place final
    //duration += B //place final to cmd report
    duration += TX_CMD_TO_TX_CB_DLY_US + inst->frameLengths_us[REPORT] + RX_TO_CB_DLY_US + RX_CB_TO_TX_CMD_DLY_US; //cmd report to place report
    //duration += C //place report to cmd inf
    duration += TX_CMD_TO_TX_CB_DLY_US + inst->frameLengths_us[INF_MAX] + RX_TO_CB_DLY_US + RX_CB_TO_TX_CMD_DLY_US; //cmd INF to place INF
    //duration += D place inf to process inf

    //MEASURED_SLOT_DURATIONS_US is experimentally found value found for B+C+D described above
    duration += (uint64)MEASURED_SLOT_DURATIONS_US;

    //add some time to account for possibly timing out on first poll
    duration += SLOT_BUFFER_EXP_TO_POLL_CMD_US; //assume this is the same amount of time go get from timeout to poll command
    duration += TX_CMD_TO_TX_CB_DLY_US + inst->frameLengths_us[POLL] - inst->storedPreLen_us + (uint64)(inst->durationPollTimeout_nus*1.0256) + 200; //add small margin of 200


    //if LCD is on, add time to allow for Sleep calls in the LCD display logic
    uint8_t enableLCD = FALSE;
    if(port_is_switch_on(TA_SW1_4) == S1_SWITCH_ON)
	{
    	enableLCD = TRUE;
		duration += LCD_ENABLE_BUFFER_US;
	}

    duration += SLOT_END_BUFFER_US;

    inst->durationSlotMax_us = duration;

    duration = 0;
    //from set discovery to cmd tx blink, to rx blink cb to cmd resp to rx resp ts
    duration += TX_CMD_TO_TX_CB_DLY_US + inst->frameLengths_us[BLINK] + RX_TO_CB_DLY_US + BLINK_RX_CB_TO_RESP_TX_CMD_DLY_US + (uint64)(convertdevicetimetosec(inst->rnginitReplyDelay)*1000000.0)  + RANGE_INIT_RAND_US + margin_us;
    if(enableLCD == TRUE)
    {
    	duration += LCD_ENABLE_BUFFER_US*2;
    }
    inst->durationWaitRangeInit_ms = CEIL_DIV(duration, 1000);


    // Smart Power is automatically applied by DW chip for frame of which length
	// is < 1 ms. Let the application know if it will be used depending on the
	// length of the longest frame.
	if (inst->frameLengths_us[FINAL] <= 1000)
	{
		inst->smartPowerEn = 1;
	}
	else
	{
		inst->smartPowerEn = 0;
	}
}

uint32 instance_getmessageduration_us(int data_length_bytes)
{
	instance_data_t* inst = instance_get_local_structure_ptr(0);

	// Compute the number of symbols for the given length.
	uint32 framelength_us = data_length_bytes * 8
				 + CEIL_DIV(data_length_bytes * 8, 330) * 48;
	// Convert from symbols to time and add PHY header length.
	if(inst->configData.dataRate == DWT_BR_110K)
	{
		framelength_us *= 820513;
		framelength_us += 17230800;
	}
	else if (inst->configData.dataRate == DWT_BR_850K)
	{
		framelength_us *= 102564;
		framelength_us += 2153900;
	}
	else
	{
		framelength_us *= 12821;
		framelength_us += 2153900;
	}
	// Last step: add preamble and SFD length and convert to microseconds.
	framelength_us += inst->storedPreLen;
	framelength_us = CEIL_DIV(framelength_us, 100000);

	return framelength_us;
}

uint64 instance_get_addr(void) //get own address
{
    return instance_get_uwbaddr(0);
}

uint64 instance_get_uwbaddr(uint8 uwb_index) //get uwb address by index
{
    instance_data_t* inst = instance_get_local_structure_ptr(0);
    uint64 x = 0;
    x |= (uint64) inst->uwbList[uwb_index][0];
    x |= (uint64) inst->uwbList[uwb_index][1] << 8;
#if (USING_64BIT_ADDR == 1)
    x |= (uint64) inst->uwbList[uwb_index][2] << 16;
    x |= (uint64) inst->uwbList[uwb_index][3] << 24;
    x |= (uint64) inst->uwbList[uwb_index][4] << 32;
    x |= (uint64) inst->uwbList[uwb_index][5] << 40;
    x |= (uint64) inst->uwbList[uwb_index][6] << 48;
    x |= (uint64) inst->uwbList[uwb_index][7] << 56;
#endif

    return (x);
}

void instance_readaccumulatordata(void)
{
#if DECA_SUPPORT_SOUNDING==1
    instance_data_t* inst = instance_get_local_structure_ptr(0);
    uint16 len = 992 ; //default (16M prf)

    if (inst->configData.prf == DWT_PRF_64M)  // Figure out length to read
        len = 1016 ;

    inst->buff.accumLength = len ;                                       // remember Length, then read the accumulator data

    len = len*4+1 ;   // extra 1 as first byte is dummy due to internal memory access delay

    dwt_readaccdata((uint8*)&(inst->buff.accumData->dummy), len, 0);
#endif  // support_sounding
}

//get the time difference between two between two 32-bit unsigned timestamps
//t1 is the first timestamp
//t2 is the second timetamp that occured after t1 
uint32 get_dt32(uint32 t1, uint32 t2)
{
    if(t2 >= t1)
    {
        return t2 - t1;
    }
    else
    {
        //handle timestamp roleover
        return 4294967295 - t1 + t2;
    }
}

//add a duration to a 32 bit timestamp. This function handles number wrapping
uint32 timestamp_add32(uint32 timestamp, uint32 duration)
{
	uint32 to_wrap = 4294967295 - timestamp;
	if(duration > to_wrap)
	{
		return to_wrap + duration;
	}
	else
	{
		return timestamp + duration;
	}
}

//subtract a duration from a 32 bit timestamp. This function handles number wrapping
uint32 timestamp_subtract32(uint32 timestamp, uint32 duration)
{
	if(duration > timestamp)
	{
		return 4294967295 - (duration - timestamp);
	}
	else
	{
		return timestamp - duration;
	}
}

//get the time difference between two between two 64-bit unsigned timestamps
//t1 is the first timestamp
//t2 is the second timetamp that occured after t1
uint64 get_dt64(uint64 t1, uint64 t2)
{
    if(t2 >= t1)
    {
        return t2 - t1;
    }
    else
    {
        //handle timestamp rollover
        return 4294967295999 - t1 + t2;
    }
}

//add a duration to a 64 bit timestamp. This function handles number wrapping
uint64 timestamp_add64(uint64 timestamp, uint64 duration)
{
	uint64 to_wrap = (uint64)4294967295999 - timestamp;
	if(duration > to_wrap)
	{
		// ʱ㣬ҪƵ0
		return  duration-to_wrap;
	}
	else
	{
		// ֱӼ
		return timestamp + duration;
	}
}

//subtract a duration from a 64 bit timestamp. This function handles number wrapping
uint64 timestamp_subtract64(uint64 timestamp, uint64 duration)
{
	if(duration > timestamp)
	{
		return (uint64)4294967295999 - (duration - timestamp);
	}
	else
	{
		return timestamp - duration;
	}
}

//NOTE could implement a hashing function to reduce chance of collisions among UWB addresses in network
//https://stackoverflow.com/questions/31710074/how-to-generate-smaller-unique-number-from-larger-11-bytes-unique-number-gene
//https://en.m.wikipedia.org/wiki/Pearson_hashing
uint16 address64to16(uint8 *address)
{
	return address[0] + (address[1] << 8);
}


#endif
