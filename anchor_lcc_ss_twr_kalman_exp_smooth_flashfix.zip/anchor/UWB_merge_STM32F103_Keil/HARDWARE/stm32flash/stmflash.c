#include "stmflash.h"
#include "stm32f10x_flash.h"


//ȡַָİ(16λ)
//faddr:ַ(˵ַΪ2ı!!)
//ֵ:Ӧ.
u16 STMFLASH_ReadHalfWord(u32 faddr)
{
	return *(vu16*)faddr; 
}
#if STM32_FLASH_WREN	//ʹд   
//д
//WriteAddr:ʼַ
//pBuffer:ָ
//NumToWrite:(16λ)   
void STMFLASH_Write_NoCheck(u32 WriteAddr,u16 *pBuffer,u16 NumToWrite)   
{ 			 		 
	u16 i;
	for(i=0;i<NumToWrite;i++)
	{
		FLASH_ProgramHalfWord(WriteAddr,pBuffer[i]);
	    WriteAddr+=2;//ַ2.
	}  
} 
//ַָʼдָȵ
//WriteAddr:ʼַ(˵ַΪ2ı!!)
//pBuffer:ָ
//NumToWrite:(16λ)(Ҫд16λݵĸ.)
 
void STMFLASH_Write(u32 WriteAddr,u16 *pBuffer,u16 NumToWrite)
{
	u16 i;
	if(WriteAddr<STM32_FLASH_BASE||(WriteAddr>=(STM32_FLASH_BASE+1024*STM32_FLASH_SIZE)))return;
	if(NumToWrite == 0 || pBuffer == 0)return;
	FLASH_Unlock();
	FLASH_ErasePage(WriteAddr);
	for(i = 0; i < NumToWrite; i++)
	{
		FLASH_ProgramHalfWord(WriteAddr, pBuffer[i]);
		WriteAddr += 2;
	}
	FLASH_Lock();
}
#endif

//ַָʼָȵ
//ReadAddr:ʼַ
//pBuffer:ָ
//NumToWrite:(16λ)
void STMFLASH_Read(u32 ReadAddr,u16 *pBuffer,u16 NumToRead)   	
{
	u16 i;
	for(i=0;i<NumToRead;i++)
	{
		pBuffer[i]=STMFLASH_ReadHalfWord(ReadAddr);//ȡ2ֽ.
		ReadAddr+=2;//ƫ2ֽ.	
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
//WriteAddr:ʼַ
//WriteData:Ҫд
void Test_Write(u32 WriteAddr,u16 WriteData)   	
{
	STMFLASH_Write(WriteAddr,&WriteData,1);//дһ 
}
















