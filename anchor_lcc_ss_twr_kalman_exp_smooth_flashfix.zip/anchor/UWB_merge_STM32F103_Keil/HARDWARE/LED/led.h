#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define BQ_PGOOD 		GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1)
#define BQ_CHG   		GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2)


#define Buzzer_H		GPIO_SetBits(GPIOB, GPIO_Pin_2)
#define Buzzer_L		GPIO_ResetBits(GPIOB, GPIO_Pin_2)

extern u8 LED0;
typedef enum
{
    LED_PC6,
    LED_PC7,
    LED_PC8,
    LED_PC9,
    LED_ALL,
    LEDn
} led_t;
void GPIO_Configuration(void);
void PB4_Configuration(u8 num);
void led_off (led_t led);
void led_on  (led_t led);

void led0_dw(u8 m);
void led1_dw(u8 m);	
void Buzzer_speak(void);
#endif
