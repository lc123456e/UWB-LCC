#ifndef PORT_H_
#define PORT_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f10x.h"
#include "compiler.h"
#include "led.h"

#define DMA_ENABLE (0)

#if (DMA_ENABLE == 1)
#define writetospi writetospi_dma
#define readfromspi readfromspi_dma
void dma_init(void);
#else
#define writetospi writetospi_serial
#define readfromspi readfromspi_serial
int writetospi_serial(uint16_t headerLength, const uint8_t *headerBuffer, uint32_t bodylength, const uint8_t *bodyBuffer);
int readfromspi_serial(uint16_t headerLength, const uint8_t *headerBuffer, uint32_t readlength, uint8_t *readBuffer);
#endif

int SPI_Configuration(void);
void SPI_ChangeRate(uint16_t scalingfactor);
void SPI_ConfigFastRate(uint16_t scalingfactor);

#define SPIx_PRESCALER       SPI_BaudRatePrescaler_8
#define SPIx                 SPI1
#define SPIx_GPIO            GPIOA
#define SPIx_CS              GPIO_Pin_4
#define SPIx_CS_GPIO         GPIOA
#define SPIx_SCK             GPIO_Pin_5
#define SPIx_MISO            GPIO_Pin_6
#define SPIx_MOSI            GPIO_Pin_7

#define DW1000_RSTn          GPIO_Pin_0
#define DW1000_RSTn_GPIO     GPIOA

#define DECARSTIRQ           GPIO_Pin_0
#define DECARSTIRQ_GPIO      GPIOA
#define DECARSTIRQ_EXTI      EXTI_Line0
#define DECARSTIRQ_EXTI_PORT GPIO_PortSourceGPIOA
#define DECARSTIRQ_EXTI_PIN  GPIO_PinSource0
#define DECARSTIRQ_EXTI_IRQn EXTI0_IRQn

#define DECAIRQ              GPIO_Pin_5
#define DECAIRQ_GPIO         GPIOB
#define DECAIRQ_EXTI         EXTI_Line5
#define DECAIRQ_EXTI_PORT    GPIO_PortSourceGPIOB
#define DECAIRQ_EXTI_PIN     GPIO_PinSource5
#define DECAIRQ_EXTI_IRQn    EXTI9_5_IRQn
#define DECAIRQ_EXTI_USEIRQ  ENABLE
#define DECAIRQ_EXTI_NOIRQ   DISABLE

#define TA_SW1_3             GPIO_Pin_0
#define TA_SW1_4             GPIO_Pin_1
#define TA_SW1_5             GPIO_Pin_2
#define TA_SW1_6             GPIO_Pin_3
#define TA_SW1_7             GPIO_Pin_4
#define TA_SW1_8             GPIO_Pin_5
#define TA_SW1_GPIO          GPIOC

#define S1_SWITCH_ON  (1)
#define S1_SWITCH_OFF (0)

#define port_SPIx_busy_sending()        (SPI_I2S_GetFlagStatus((SPIx),(SPI_I2S_FLAG_TXE))==(RESET))
#define port_SPIx_no_data()             (SPI_I2S_GetFlagStatus((SPIx),(SPI_I2S_FLAG_RXNE))==(RESET))
#define port_SPIx_send_data(x)          SPI_I2S_SendData((SPIx),(x))
#define port_SPIx_receive_data()        SPI_I2S_ReceiveData(SPIx)
#define port_SPIx_disable()             SPI_Cmd(SPIx,DISABLE)
#define port_SPIx_enable()              SPI_Cmd(SPIx,ENABLE)
#define port_SPIx_set_chip_select()     GPIO_SetBits(SPIx_CS_GPIO,SPIx_CS)
#define port_SPIx_clear_chip_select()   GPIO_ResetBits(SPIx_CS_GPIO,SPIx_CS)

#define port_GetEXT_IRQStatus()         EXTI_GetITEnStatus(DECAIRQ_EXTI)
#define port_DisableEXT_IRQ()           NVIC_DisableIRQ(DECAIRQ_EXTI_IRQn)
#define port_EnableEXT_IRQ()            NVIC_EnableIRQ(DECAIRQ_EXTI_IRQn)
#define port_CheckEXT_IRQ()             GPIO_ReadInputDataBit(DECAIRQ_GPIO, DECAIRQ)

ITStatus EXTI_GetITEnStatus(uint32_t x);
int NVIC_DisableDECAIRQ(void);

void __weak process_dwRSTn_irq(void);
void __weak process_deca_irq(void);
void __weak button_callback(void);
int is_IRQ_enabled(void);

int peripherals_init(void);
void spi_peripheral_init(uint8_t using_lcd);

unsigned long portGetTickCnt(void);
unsigned long long portGetTickCntMicro(void);
#define portGetTickCount() portGetTickCnt()

void Sleep(uint32_t Delay);
void reset_DW1000(void);
void setup_DW1000RSTnIRQ(int enable);
void port_wakeup_dw1000(void);
void port_wakeup_dw1000_fast(void);
void port_set_dw1000_slowrate(void);
void port_set_dw1000_fastrate(void);
void deca_sleep(unsigned int time_ms);

int port_is_boot1_on(uint16_t x);
int port_is_boot1_low(void);
int port_is_switch_on(uint16_t GPIOpin);
int is_switch_on(uint16_t GPIOpin);
int is_button_low(uint16_t GPIOpin);

#ifdef __cplusplus
}
#endif

#endif /* PORT_H_ */
