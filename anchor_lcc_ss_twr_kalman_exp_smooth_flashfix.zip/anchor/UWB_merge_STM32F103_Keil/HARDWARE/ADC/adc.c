 #include "adc.h"
 #include "delay.h"
 
		   
//ʼADC
//ǽԹͨΪ
//ĬϽͨ0~3																	   
void  Adc_Init(void)
{ 	
	ADC_InitTypeDef ADC_InitStructure; 
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB |RCC_APB2Periph_ADC1	, ENABLE );	  //ʹADC1ͨʱ
 

	RCC_ADCCLKConfig(RCC_PCLK2_Div6);   //ADCƵ6 72M/6=12,ADCʱ䲻ܳ14M

	//PA1 Ϊģͨ                         
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;		//ģ
	GPIO_Init(GPIOB, &GPIO_InitStructure);	

	ADC_DeInit(ADC1);  //λADC1, ADC1 ȫĴΪȱʡֵ

	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;	//ADCģʽ:ADC1ADC2ڶģʽ
	ADC_InitStructure.ADC_ScanConvMode = DISABLE;	//ģתڵͨģʽ
	ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;	//ģתڵתģʽ
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;	//תⲿ
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;	//ADCҶ
	ADC_InitStructure.ADC_NbrOfChannel = 1;	//˳йתADCͨĿ
	ADC_Init(ADC1, &ADC_InitStructure);	//ADC_InitStructָĲʼADCxļĴ   

  
	ADC_Cmd(ADC1, ENABLE);	//ʹָADC1
	
	ADC_ResetCalibration(ADC1);	//ʹܸλУ׼  
	 
	while(ADC_GetResetCalibrationStatus(ADC1));	//ȴλУ׼
	
	ADC_StartCalibration(ADC1);	 //ADУ׼
 
	while(ADC_GetCalibrationStatus(ADC1));	 //ȴУ׼
 
//	ADC_SoftwareStartConvCmd(ADC1, ENABLE);		//ʹָADC1ת

}				  
//ADCֵ
//ch:ֵͨ 0~3
u16 Get_Adc(u8 ch)   
{
  	//ָADCĹͨһУʱ
	ADC_RegularChannelConfig(ADC1, ch, 1, ADC_SampleTime_239Cycles5 );	//ADC1,ADCͨ,ʱΪ239.5	  			    
  
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);		//ʹָADC1ת	
	 
	while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC ));//ȴת

	return ADC_GetConversionValue(ADC1);	//һADC1ת
}

u16 Get_Adc_Average(u8 ch,u8 times)
{
	u32 temp_val=0;
	u8 t;
	for(t=0;t<times;t++)
	{
		temp_val+=Get_Adc(ch);
//		Sleep(10);
		//delay_ms(5);
	}
	return temp_val/times;
} 	 

float Get_Battery_Voltage(void)
{
	u16 adcx;
	float volt=0.0;
	adcx = Get_Adc_Average(ADC_Channel_9,1);		
	volt = (float) adcx*(6.6/4096);
	
	return volt;
}

float Get_Battery_Percent(float Volt)
{
	float percent =0.0;
	percent = (Volt-3.40) / (4.2-3.40)*100.0;
	
	if(percent<=0)
		percent = 0.0;
	
	return percent;
}

























unsigned int Get_Battery_mV(void)
{
	u16 adcx = Get_Adc_Average(ADC_Channel_9,1);
	return (unsigned int)((adcx * 6600UL + 2048UL) / 4096UL);
}

unsigned int Get_Battery_Percent_Int(unsigned int mv)
{
	if(mv <= 3400U)
	{
		return 0U;
	}
	if(mv >= 4200U)
	{
		return 100U;
	}
	return (unsigned int)(((mv - 3400U) * 100U + 400U) / 800U);
}
