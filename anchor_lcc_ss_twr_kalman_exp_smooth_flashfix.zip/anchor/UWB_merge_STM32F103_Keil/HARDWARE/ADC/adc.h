#ifndef __ADC_H
#define __ADC_H	
#include "sys.h"
//ֻѧϰʹãδɣκ;
//ALIENTEKӢSTM32
//ADC 	   
//ԭ@ALIENTEK
//̳:www.openedv.com
//޸:2012/9/7
//汾V1.0
//ȨУؾ
//Copyright(C) ӿƼ޹˾ 2009-2019
//All rights reserved									  
////////////////////////////////////////////////////////////////////////////////// 

void Adc_Init(void);
u16  Get_Adc(u8 ch); 
u16 Get_Adc_Average(u8 ch,u8 times); 
float Get_Battery_Voltage(void);
float Get_Battery_Percent(float Volt);
unsigned int Get_Battery_mV(void);
unsigned int Get_Battery_Percent_Int(unsigned int mv);
#endif 
